# Video Wallpaper (v5.12.0)

An Android app that lets you pick a video, compress it once (quality/filter/
trim/bitrate), and set it as a live wallpaper -- with a watchdog that
recovers automatically from stalls or memory pressure, a diagnostic log you
can export, and a 4-tab UI (Start / Bewerken / Bibliotheek / Meer).

This file is updated with every version: what's new, what changed, what was
removed. The in-app changelog (Meer -> Instellingen -> Versiegeschiedenis)
shows the same history in a shorter, user-facing form -- build-tooling-only
fixes are documented here instead, since they have no user-visible effect.

## v5.12.0
**Changed -- reworked based on direct feedback that the small
conditional chip from v5.11.1 wasn't what was actually wanted**

- `saveToLibraryButton` moved out of the info card entirely and
  rebuilt as a genuine third full-width `Button`, same style and
  weight as `setWallpaperButton`/`pickAndEditButton`, sitting right
  below them in the same button stack.
- No longer conditionally hidden -- it's a permanent safety button,
  always present regardless of whether the current video is already
  saved. Tapping it now handles all three real states explicitly
  rather than assuming: nothing active yet ("Nog geen achtergrond
  ingesteld om op te slaan"), already saved ("Al opgeslagen in
  bibliotheek"), or genuinely not yet saved (saves it for real,
  "Opgeslagen in bibliotheek"). `PresetStore.activeVideoMeta()`/
  `isActiveVideoSavedToLibrary()`/`saveActiveVideoToLibrary()` from
  v5.11.1 are unchanged -- only how the button surfaces and reacts to
  them changed.

## v5.11.2
**Fixed -- the actual reason "Opslaan in bibliotheek" appeared to have
no effect and the save button never showed**

- `BewerkenFragment`'s "reuse identical compression" shortcut
  (`PresetStore.findByConfigSignature()`) is a completely separate code
  path from the one v5.11.0/v5.11.1 touched -- if the same
  quality/filter/trim/bitrate settings had been used before, it would
  reactivate the already-saved result directly, without ever checking
  `BewerkenPrefs.getSaveToLibrary()` at all. There was nothing new
  being compressed, so the toggle was never consulted -- for anyone
  testing repeatedly with the same video and settings (a very natural
  way to test a toggle like this), that shortcut fires every time and
  the toggle would appear to do nothing.
- Fixed by gating the shortcut lookup itself: `findByConfigSignature()`
  is now only even called when `getSaveToLibrary()` is true. When the
  toggle is off, the lookup is skipped entirely (`existingMatch` stays
  null) and execution falls through to a genuine fresh compression,
  which already correctly respects the toggle's save/don't-save
  decision. Reusing an old saved file while the person has explicitly
  said "don't save this" would have directly contradicted their choice
  -- skipping the shortcut is the only version of this that actually
  respects what was asked for.

## v5.11.1
**Fixed -- a real side effect of v5.11.0's "Opslaan in bibliotheek"
toggle, caught from a screenshot of the real running app rather than
found in review**

- `setActive()` previously only ever wrote `KEY_VIDEO_URI` and
  `KEY_ACTIVE_PRESET_ID` -- Start's entire preview (thumbnail, name,
  quality summary) was built entirely on `PresetStore.activePreset()`
  finding a matching *saved* Preset. Once v5.11.0 made saving optional,
  applying a video with that toggle off meant Start could no longer
  show anything about it at all -- not just missing a save button, the
  whole preview would have broken.
- `setActive()` now also writes `PresetStore.ActiveVideoMeta`
  (thumbnail path, summary, name, created-at, file path, config
  signature) unconditionally, regardless of whether the video is also
  a saved library entry. `StartFragment.refreshPreview()` now reads
  from `PresetStore.activeVideoMeta()` instead of `activePreset()`, so
  the preview always works either way.
- New `saveToLibraryButton` on Start itself -- shown only when the
  active video genuinely isn't in the library yet
  (`PresetStore.isActiveVideoSavedToLibrary()`), hidden otherwise.
  Tapping it (`PresetStore.saveActiveVideoToLibrary()`) reconstructs a
  real `Preset` from the cached metadata, adds it to the library, and
  updates the tracked active-preset ID so the button correctly
  disappears afterward rather than looking like it did nothing.
- The other two `setActive()` callers (Bibliotheek's "Gebruiken",
  Bewerken's "reuse identical compression") are unaffected --  they
  already pass a real, already-saved `Preset` object, so the extra
  metadata written is simply correct and consistent for them too.

## v5.11.0
**New**
- `saveToLibrarySwitch` added to Bewerken, defaulting to on (matching
  the app's behavior before this existed) -- turning it off means
  compressing and applying a video without it being registered as a
  reusable Preset in Bibliotheek. `PresetStore.setActive()` only ever
  needed a `Preset` object in memory, not a saved library entry, so
  the branch is clean: the compressed file still gets created and
  still gets applied as the wallpaper either way (both are required
  for it to actually work) -- what's conditional is only the
  `PresetStore.add()` call that registers it in the library list. A
  video applied this way naturally won't show up in Bibliotheek and
  won't be found later by the "reuse identical compression" check,
  which is the correct behavior for a one-off/temporary apply.
- `BewerkenPrefs.getSaveToLibrary()`/`setSaveToLibrary()` follow the
  exact same `SharedPreferences` pattern as every other Bewerken
  setting (quality, filter, trim, etc.) -- meaning it's remembered
  between sessions and, like all of it, survives app updates. Only an
  actual uninstall would clear it, same as everything else Bewerken
  remembers. Included in `resetToDefaults()`, resetting back to on.

## v5.10.1
**New -- makes v5.10.0's raw logging actually visible, so it's checkable
without needing to read log lines.**

- `DiagnosticLog.nativeHeapTrend()`: parses every "Player released:
  native heap XMB -> YMB" line, takes the most recent 8 "after"
  readings and the 8 before that, and compares the two batch averages.
  Deliberately averages batches rather than comparing single readings
  or a naive oldest-vs-newest split -- native heap fluctuates
  meaningfully more moment-to-moment than something like battery
  drain, so a single-point comparison risked mistaking ordinary noise
  for a real trend. Requires 16 total readings before returning
  anything, and growth has to clear a 15MB threshold to be reported as
  growing rather than stable -- same "never fabricate an answer from
  insufficient data" rule the battery drain-rate figure already
  follows.
- Shown as a new plain-language line in Diagnostiek's battery card,
  right next to thermal status: "Native geheugen: stabiel (N metingen)"
  or "Native geheugen: toenemend (+XMB over N metingen)", or a clear
  "not enough rebuilds measured yet" message rather than nothing at
  all.

## v5.10.0
**New -- step 1 of investigating a reported "laggy after ~1 month, fixed
by a full phone restart but not by re-applying the wallpaper" report.
This version is observation only; no watchdog behavior changes.**

- `releasePlayer()` now measures `Debug.getNativeHeapAllocatedSize()`
  immediately before and after releasing the player, logging one
  consistent line ("Player released: native heap XMB -> YMB") every
  time -- centralized inside the one function all 8 release call sites
  (stall/heap/error recovery, proactive refresh, video<->photo swaps)
  funnel through, rather than duplicated at each site individually,
  specifically to guarantee complete, consistent coverage with minimal
  surface area for a mistake.
- Guarded to skip measuring/logging on the several call sites that can
  invoke this when there's no player to release, avoiding meaningless
  "before equals after, nothing happened" log noise.
- Deliberately does not attempt a trend calculation or alert yet (an
  earlier proposal to compare "recent vs older readings" the same way
  battery drain-rate works was reconsidered as unreliable -- native
  heap fluctuates much more moment-to-moment than battery drain does,
  so that method could produce false positives from ordinary noise).
  The plan instead is to compare readings specifically at the same
  kind of checkpoint (right after a proactive refresh) across many
  cycles once there's real data to look at, not to guess at a
  methodology now.
- JVM heap (`checkHeapPressure()`) has been checked since early on;
  native heap never has been until this version -- a leak there would
  have been completely invisible to every diagnostic this app already
  had.

## v5.9.2
**Fixed**
- Real bug, independent of any build/caching issue: `VideoWallpaperApp
  .clearActiveWallpaperOnVersionChange()` writes the version marker
  using multi-word strings ("code 70" / "code 73"), but
  `DiagnosticLog.statsSinceLastUpdate()`'s regex used `(\S+)`
  (non-whitespace only), which stops matching at the first space --
  meaning the whole pattern silently failed to match the line at all,
  every single time, on every version. `sinceUpdateCard` was working
  exactly as coded: correctly showing nothing, because
  `statsSinceLastUpdate()` was correctly (from its own broken premise)
  always returning null. Fixed the regex to `(.+?)` so it matches
  multi-word version strings.
- While in there: the marker only ever stored *version codes*, not
  readable names -- the mockup's example read "5.8.0 → 5.9.1" but a
  real marker would have shown "code 70 → code 73." Added
  `KEY_LAST_SEEN_VERSION_NAME` alongside the existing version-code
  tracking, so future markers show `BuildConfig.VERSION_NAME` instead.
  Falls back to the version code for anyone whose stored data predates
  this fix, since there's no name recorded for that specific prior
  version to look back at.

## v5.9.1
**Fixed**
- Real build error from v5.9.0: `ThemePrefs.MODE_LIGHT`/`MODE_SYSTEM`/
  `MODE_DARK` are `String` constants ("light"/"system"/"dark"), and
  `getThemeMode()`/`setThemeMode()` both use `String` -- the new
  segmented theme control's `applySelection()` and
  `updateThemeSegmentStyles()` were incorrectly typed as taking `Int`.
  Fixed to match `ThemePrefs`' actual, already-established `String`
  type throughout, rather than the mismatched type I'd assumed.

## v5.9.0
**New -- Instellingen genuinely rebuilt from scratch, not just restyled.
Confirmed it had never gotten past the original v5.4.0 color pass; the
structure was still 100% the pre-overhaul screen (stacked RadioGroups,
section-header cards).**

- Language: collapsed to a single row (flag + current name + ▾,
  `languageRow`), tapping opens `dialog_language_picker.xml` -- a real
  custom bottom sheet (same pattern as `ReapplyNeededDialog`/
  `PresetActionsDialog`) containing the actual `RadioGroup` picker,
  rather than showing all options stacked on the main screen.
- Theme: replaced the 3 stacked `RadioButton`s with a real segmented
  ☀️/Systeem/🌙 control (`themeLightSegment`/`themeSystemSegment`/
  `themeDarkSegment`), selected state styled via
  `chip_filter_selected.xml`.
- Two genuinely new toggles, `SettingsPrefs.kt`: Wi-Fi-only downloads
  and reduce-motion, both real persisted preferences now -- explicitly
  **not** including the enforcement logic (checking network type
  before a cloud fetch; threading a motion-reduction flag through
  every animated transition), which is real, separate follow-up work,
  not silently pretended to be done here.
- Permissions row: real check via
  `PowerManager.isIgnoringBatteryOptimizations()` +
  `NotificationManagerCompat.getEnabledListenerPackages()` (the same
  pattern already proven in `MoreFragment.kt`), tapping shows a simple
  dialog with both statuses. Deliberately "X van 2" rather than the
  mockup's "X van 3" -- no third permission in this app actually maps
  to a real grantable/checkable state, so the count reflects reality
  rather than forcing a fake third item to match the mockup's exact
  wording.
- Clear cache: genuinely computes and clears `cacheDir` size, not a
  placeholder.
- Caught one real bug before it shipped: `SettingsPrefs.kt` initially
  imported `androidx.preference.PreferenceManager`, which no other file
  in this project uses -- every existing screen uses the older
  `android.preference.PreferenceManager` instead. Fixed to match the
  already-proven pattern rather than risk an unverified dependency path.

## v5.8.0
**New -- closing a real gap discovered while reviewing this screen: the
confirmed "more features" round for Diagnostiek (since-last-update card,
thermal stat, live pulse indicator, log search/filter, long-press-copy)
had been designed and agreed on across several rounds but was never
actually built -- v5.4.0/v5.4.2 only ever restyled the original v5.2.0
baseline.**

- `DiagnosticLog.kt`: new `latestThermalStatus()` (parses the last
  "thermal X" fragment already present in every heartbeat/rebuild log
  line) and `statsSinceLastUpdate()` (finds the most recent
  `appendVersionMarker()` line and counts stall-rebuild/proactive-refresh
  events logged after it, returning null if no update has ever been
  logged).
- New `sinceUpdateCard` (amber glass card, only shown when there's an
  actual update marker to report against), thermal stat shown alongside
  the drain rate, and a small green `live_pulse_dot.xml` next to the
  title.
- Real search (`logSearchInput`, live-filters as you type) and category
  filter chips (Alle/App/Herstarts/Fouten,
  `chip_filter_selected.xml`/reusing Bewerken's `chip_unselected_glass.xml`)
  above the log list -- `applyLogFilter()` combines both against the
  untouched `allLogLines` source list, so switching filters or clearing
  search never loses data.
- Long-press a log line to copy it to the clipboard
  (`LogLineAdapter.kt`), matching exactly how log lines have actually
  been shared in this conversation (as individual screenshots) rather
  than needing the full share/export flow every time.

## v5.7.0
**Changed -- Stijl's RGB controls genuinely redesigned, not just
recolored**
- Traced exactly why Stijl still read as "reskinned, not overhauled"
  despite its sections already being properly separated into
  individual glass cards: the 6 RGB `SeekBar`s (`redSeekBar`/
  `greenSeekBar`/`blueSeekBar` for accent, plus the same 3 for
  background) had zero styling attributes at all -- completely default
  Android Material appearance, with no connection to the app's glass
  aesthetic or its own accent color.
- New `slider_progress.xml` (a layer-list: thin 3dp translucent
  background track + thin 3dp white progress fill, `android:progressTint
  ="?attr/colorAccent"` tinting the fill to match whatever accent color
  is currently active) and `slider_thumb.xml` (small 14dp white
  circle), replacing the default thick Material track/thumb.
  `android:splitTrack="false"` removes the default gap-line around the
  thumb.
- The 8 numeric input fields (`customColorHexInput`,
  `redValueInput`/`greenValueInput`/`blueValueInput` and their
  background-color equivalents) had the same gap -- no background at
  all, relying on the default underline text-field style. New
  `input_box_background.xml` (small rounded, subtly bordered box)
  applied to all 8, matching the mockup's numeric input treatment
  instead of the underline look.

## v5.6.1
**Fixed**
- Meer's four navigation rows (Stijl, Slideshow, Diagnostiek,
  Instellingen) were still wrapped in one single `card_glass_background`
  container with thin divider `View`s between them -- v5.4.0's restyle
  pass recolored this existing structure without questioning it, but
  every design mockup throughout the whole overhaul consistently showed
  each option as its own separate card. Split into 4 independent cards
  (`styleRow`/`slideshowRow`/`diagnosticsRow`/`settingsRow`), each with
  its own `card_glass_background`, 14dp padding (up from 10dp), and 9dp
  margin between cards. Also reported as making the screen feel smaller
  than intended -- the extra breathing room from real separation
  between cards addresses that too, not just the visual match to the
  mockup. All 14 IDs `MoreFragment.kt` references confirmed unchanged.

## v5.6.0
**Changed**
- `bottom_nav_bar.xml`'s 4 label `TextView`s (`navStartLabel`,
  `navBewerkenLabel`, `navBibliotheekLabel`, `navMeerLabel`) removed --
  every design mockup throughout the whole overhaul consistently showed
  an icon-only nav bar, but the actual built version had kept both icon
  and label since v5.4.0's restyle pass never questioned the existing
  structure. `BottomNav.kt`'s `updateActiveTab()` simplified to match
  (tints icons only, no more label lookups). `nav_start`/`nav_bewerken`
  string resources still in use elsewhere (as the Start/Bewerken
  screens' own title text) and untouched; `library_button`/
  `more_button` are now genuinely unused but left in place -- harmless,
  not worth touching 5 locale files for a purely cosmetic cleanup.

## v5.5.2
**Fixed -- closing real gaps between Meer and the confirmed mockup that
v5.4.1 hadn't fully closed**
- Storage stat added: sums every preset's actual file size
  (`File(videoFilePath).length()`, same pattern `LibraryFragment`
  already used for its "largest" sort) and shows it in the health card
  as "💾 X MB in Bibliotheek" -- present in the original mockup, never
  built until now.
- What's-new banner now shows the *actual* latest changelog entry
  instead of a generic "check the version history" message.
  `InfoActivity`'s changelog list is exposed via a new companion object
  (`LATEST_CHANGELOG_ITEMS_RES`), so there's exactly one place that
  needs updating each release (the `sections` list, already updated
  every version) rather than two places that could drift out of sync.
  `whatsNewText` given `maxLines="2"` + ellipsize, since real changelog
  entries run longer than the mockup's short placeholder text.
- Not changed: the health card still shows a lifetime freeze *count*
  rather than the mockup's "X dagen zonder bevriezing" streak framing,
  and there's still no session-uptime figure -- both would need
  additional log-parsing work beyond this pass. The diagnose-share
  shortcut and total-playback-time stat remain deferred, as before.

## v5.5.1
**Fixed**
- Real build error from v5.5.0: `androidx.cardview.widget.CardView`'s
  `app:cardCornerRadius`/`cardElevation`/`cardBackgroundColor`
  attributes failed to resolve at resource-linking time
  (`attribute res-auto:cardElevation not found`), meaning the
  `androidx.cardview:cardview:1.0.0` dependency wasn't being picked up
  correctly. Rather than assume this was just a one-time Gradle sync
  issue and ask for a retry, removed the CardView dependency entirely
  -- `item_preset_grid.xml` now uses a plain `card_grid_background.xml`
  shape drawable for the rounded/tinted card look, with
  `android:clipToOutline="true"` + `android:outlineProvider="background"`
  (standard View properties, no library needed) to replicate
  CardView's automatic corner-clipping of the thumbnail, and
  `android:elevation` directly on the view for the shadow. Same visual
  result, one fewer dependency, and no more reliance on that specific
  library resolving correctly. All 7 IDs `PresetGridAdapter.kt`
  expects (`gridCardRoot`, `presetThumbnail`, `activeBadge`,
  `activeRing`, `favoriteToggle`, `presetDate`, `presetSummary`)
  confirmed unchanged.

## v5.5.0
**New -- Bibliotheek's actual grid conversion, deferred in v5.4.0's
restyle pass; further real content for Meer**

- Bibliotheek converted from its list (`presetListContainer`, manual
  `LinearLayout.addView()` per preset) to a genuine 2-column grid:
  `RecyclerView` + `GridLayoutManager`, new `PresetGridAdapter.kt`, new
  `item_preset_grid.xml` (thumbnail-dominant card, gradient overlay for
  text legibility, favorite star, active-state ring via
  `card_active_ring.xml`). New `androidx.cardview:cardview:1.0.0`
  dependency. The old `item_preset.xml` row layout is now unused and
  was removed.
- Since a dense grid has no room for always-visible action buttons the
  way the list did, tapping a card now opens `PresetActionsDialog.kt`
  (Gebruiken/Hernoemen/Verwijderen, matching the existing custom
  bottom-sheet pattern) -- the favorite star stays directly on the
  card since it's a single tap either way. All existing search/sort
  (newest/largest/favorites-first)/favorites-only filtering logic in
  `LibraryFragment.kt` is unchanged, only how results get displayed
  changed.
- Meer: added a live accent-color swatch next to the Stijl row
  (`StylePrefs.resolveAccentColor()`, tinting `swatch_circle.xml`
  programmatically) and a real notification-access status next to the
  Slideshow row, using `NotificationManagerCompat.getEnabledListenerPackages()`
  -- there was previously no code anywhere that actually checked
  whether that permission was granted, only a button to open the
  settings screen for it.
- Deliberately not built: a true one-tap "share diagnostics" shortcut
  directly from Meer. The existing share logic in `DiagnosticsActivity`
  is tightly coupled to that Activity (private functions, several
  dependencies) -- duplicating or refactoring it felt riskier than it
  was worth for this pass, so the what's-new banner links to the
  version history instead, and Diagnostiek's own row is still the way
  to actually share a report.

## v5.4.2
**Changed**
- Stijl and Diagnostiek switched from the separate, calmer flat
  `bg_gradient_calm.xml` background back to the same
  `bg_gradient_immersive.xml` gradient every other screen uses. That
  calmer background was a deliberate call made during the mockup phase
  (to avoid a busy backdrop competing with judging colors/reading
  data), but felt inconsistent once actually experienced as part of
  the app's real navigation flow rather than in isolation -- a design
  choice that worked in a single static mockup didn't hold up moving
  between screens in the real app. `bg_gradient_calm.xml` removed
  entirely, no longer referenced anywhere.

## v5.4.1
**Fixed**
- Meer's background *did* restyle correctly in v5.4.0 -- what was
  actually missing was the content itself. Meer's mockup design added
  substantial new material (greeting, health summary, what's-new
  banner) that v5.4.0 never built; it only recolored the pre-existing
  4-row navigation list. That gap was more visible on Meer than any
  other screen, since its mockup differed the most from its
  then-current real structure.
- Added for real, using only data the app can already compute: a
  time-of-day greeting (`greetingForCurrentTime()`, no new tracking --
  just the device clock), a health card (☀️/⚠️ mood icon +
  `DiagnosticLog.stallRebuildCount()` for a lifetime freeze count +
  the existing `estimatedDrainRatePerHour()` for measured battery use),
  and a what's-new banner linking to `InfoActivity` (the version
  history), showing the current version via `BuildConfig.VERSION_NAME`.
- **A separate, real issue found along the way, not yet fixed**:
  `StylePrefs.applyBackgroundPattern()` is called by nearly every
  screen (`BewerkenFragment`, `DiagnosticsActivity`, `LibraryFragment`,
  `MoreFragment`, `SettingsActivity`, `SlideshowActivity`,
  `StartFragment`, `StyleActivity`) and directly overwrites the root
  view's background at runtime whenever a custom Stijl background
  color or pattern is set -- which would silently undo the new
  gradient/glass look on any of those screens. Confirmed this wasn't
  the cause of the Meer report specifically (its background was
  already applying correctly), but it's a real latent risk for anyone
  with a custom Stijl background configured, worth resolving
  deliberately rather than leaving as a surprise.

## v5.4.0
**Changed -- the remaining 7 screens of the visual overhaul, all in one
version per explicit request. Given the scale, this was done as a safe
programmatic color/background restyle (preserving every existing ID and
piece of functionality) rather than attempting full layout rewrites with
every speculative new feature from the design mockups -- see below for
exactly what's real and what's deferred.**

- New shared drawables: `bg_gradient_immersive.xml` (the main gradient,
  used by Bewerken/Bibliotheek/Meer/Slideshow/the host activity/nav bar),
  `bg_gradient_calm.xml` (a calmer solid dark background used only for
  Stijl and Diagnostiek specifically, preserving the earlier design
  decision that a busy backdrop competes with judging colors/reading
  data), `card_glass_background.xml`, `card_glass_amber.xml`,
  `chip_unselected_glass.xml`.
- All 9 remaining layout files restyled via a script that only touched
  background/color attribute *values*, never structure -- confirmed
  zero IDs lost across every file (`fragment_bewerken.xml`,
  `fragment_library.xml`, `fragment_more.xml`, `activity_style.xml`,
  `activity_slideshow.xml`, `activity_diagnostics.xml`,
  `activity_settings.xml`, `item_log_line.xml`, `item_photo.xml`,
  `item_preset.xml`), plus `activity_host.xml` and `bottom_nav_bar.xml`
  for consistency.
- **Found and fixed real bugs the XML-only restyle couldn't catch**:
  several screens set colors *programmatically* in Kotlin for
  dynamically-created views, which a layout-file restyle has no way to
  touch. Every one found would have been genuinely illegible (dark text
  on the new dark backgrounds) had it shipped as-is: the bottom nav
  bar's inactive-tab color (`BottomNav.kt`, affects every screen),
  Bewerken's unselected quality/filter/bitrate chips (`BewerkenFragment.kt`,
  both text color and background drawable), Bibliotheek's empty-state
  text (`LibraryFragment.kt`), Stijl's selected-swatch ring indicator
  (`StyleActivity.kt`), and Instellingen's language picker radio buttons
  (`SettingsActivity.kt`). New shared color `nav_inactive_on_dark`
  (`#99FFFFFF`) added for this class of fix.
- Deliberately scoped down from the full mockups, to avoid rushing
  complex new logic into an already-large single change:
  - **Bibliotheek stays a list, not the designed 2-column grid.** The
    grid was a genuine layout change (new RecyclerView, new adapter,
    rewriting the existing search/sort/favorites-filter logic to work
    against it) rather than a restyle -- worth its own dedicated pass.
  - **Bibliotheek's badges** (battery impact, last-used, Slideshow-rotation
    indicator, streak, achievement) and **Meer's total-playback-time
    stat** aren't built -- most need new data tracking that doesn't
    exist anywhere in the app yet (e.g. no per-preset uptime history,
    no cumulative playback counter).
  - **Instellingen's Wi-Fi-only downloads and reduce-motion toggles**
    aren't built -- both are genuinely new features (network-type
    checking before cloud fetches; threading a motion-reduction flag
    through every animated transition), not restyles of anything that
    exists today.
  - **The two dialogs** (`EditVideoPromptDialog`,
    `ReapplyNeededDialog`) and the onboarding screen were left
    untouched -- neither was part of the confirmed 8-screen design
    scope from the mockup phase.

## v5.3.0
**New -- first real screen of the planned visual overhaul (design phase
was mockups only; this is the actual implementation, screen 1 of 8)**
- Start screen restyled: `bg_gradient_immersive.xml` (a rich gradient
  approximating the "immersive" look from the mockups -- a literal live
  video background behind the UI wasn't pursued, same class of
  complexity/risk as what was ruled out for the freeze investigation),
  `card_glass_background.xml` and `card_glass_amber.xml` (semi-transparent
  card drawables approximating a frosted-glass look without requiring
  true backdrop blur, which isn't available below API 31 -- our minSdk
  is 26).
- The active preset's name and quality summary (`Preset.customName` /
  the date, and `Preset.summary`, e.g. "1080p · Geen · 6 Mbps") now
  shown directly on Start, using data that already existed on every
  Preset but was never surfaced here before.
- A new live mute toggle (`muteToggle`) -- genuinely new functionality,
  not just a restyle. `KEY_MUTED` was previously only ever read once, at
  player-build time, so toggling it anywhere had no effect on an
  already-running player until the next full rebuild happened to occur.
  Added `ACTION_MUTE_CHANGED` (mirroring the existing
  `ACTION_ACTIVE_VIDEO_CHANGED`/`ACTION_PULSE` broadcast pattern) so the
  wallpaper Engine can set `player.volume` directly and immediately,
  with no rebuild needed.
- The primary/secondary button hierarchy was swapped to match the
  confirmed design: "Instellen als achtergrond" is now the prominent
  solid button, "Video kiezen en bewerken" the glass secondary one --
  previously the reverse.
- Deliberately *not* included: a "Batterijbesparing" quick toggle from
  the original mockups. That setting only ever affected compression
  settings at Bewerken time -- there's no live equivalent to toggle
  post-compression without redesigning what the setting even means, so
  it was left out rather than built as something that wouldn't
  actually do anything.

Seven more screens/sub-sections to go: Bewerken, Bibliotheek, Meer,
Stijl, Slideshow, Diagnostiek, Instellingen -- each will get the same
real-implementation treatment in turn.

## v5.2.1
**Fixed**
- Real report from the log: `Photo import failed: could not open stream
  (mime type: image/jpeg)` -- meaning v4.9.1's `openTypedAssetFileDescriptor`
  fallback *also* failed, on a completely standard JPEG, not some
  obscure format. Two real gaps found: (1) that fallback was passing a
  wildcard `"image/*"` mime type -- some content providers strictly
  validate the requested type against what they can actually serve and
  refuse a wildcard even when they'd happily serve the exact type; now
  tries the URI's own reported type first, falling back to the wildcard
  only if that's unavailable. (2) The fallback's exception was being
  swallowed silently (`catch (e: Exception) { null }`) -- meaning this
  exact failure gave no way to know *why* it happened. `openImageStream()`
  now returns the actual exception details alongside the stream (or
  lack of one), surfaced in both the `Log.e()` call and the
  `DiagnosticLog` entry, so any future failure of this kind is fully
  diagnosable instead of just "didn't work."

## v5.2.0
**Changed**
- Diagnostiek's watchdog log converted from one flat, ever-growing
  `TextView` (embedded in the page's own outer `ScrollView`, so scrolling
  the log also scrolled past every other card on the screen) to a proper
  `RecyclerView` -- new `LogLineAdapter.kt`, new `item_log_line.xml` row
  layout, new `androidx.recyclerview:recyclerview:1.3.2` dependency.
  Given a bounded height (400dp) so it scrolls independently within its
  own card instead of dominating the whole page. Shown newest-first
  (the underlying log file itself stays oldest-first, unaffected --
  CSV export and `shareDiagnostics()` still read it chronologically);
  whoever's checking this cares about the most recent events first, not
  scrolling all the way down through old history to find them. Empty
  state now toggles a separate "no events yet" view instead of just
  showing that text inside what used to be the same TextView.

## v5.1.9
**Fixed**
- `resolveSourceUri()`'s `retrieveDurationMs()` call (`MediaMetadataRetriever
  .setDataSource(context, uri)`) ran directly on the main thread, called
  straight from `onViewCreated()` every time Bewerken opens with a
  freshly-picked video. For a cloud-backed picker source (OneDrive,
  Google Drive, Google Photos items not cached locally -- the same
  class of issue diagnosed for photo imports in v4.9.1), opening the
  data source triggers an on-demand network download right there, and
  videos are large enough that a slow connection makes this take a
  genuinely long time. Two real problems from this: no loading feedback
  at all (looked identical to a frozen app), and since this blocked the
  main thread, a slow enough fetch could trigger Android's own "app not
  responding" dialog. Now runs on a background thread, with the
  existing busy indicator (progress bar + "Video laden…" status,
  reusing `setBusy()` already built for compression) shown for the
  duration. The apply button stays disabled the whole time, so
  `startTranscode()` can never run before the duration read completes
  -- confirmed safe by tracing both the manual-tap and auto-apply paths.

## v5.1.8
**Changed**
- `ReapplyNeededDialog` restyled as a custom bottom sheet
  (`dialog_reapply_needed.xml`), replacing the plain default system
  `AlertDialog` -- mirrors `EditVideoPromptDialog`'s existing pattern
  (rounded top, drag handle, accent-colored primary button) so it reads
  as part of the app rather than a stock Android popup dropped on top
  of it. Goes a step further than that precedent, too: explicitly wires
  in `StylePrefs.applyCustomAccentToViewTree()`,
  `applyCornerStyleToViewTree()`, and `applyTypefaceToViewTree()`, so
  custom RGB accent colors and corner style are respected -- a theme
  overlay alone can't represent an arbitrary custom color, which is why
  `EditVideoPromptDialog` itself doesn't fully support custom accent
  either. No functional change -- same two buttons, same trigger
  conditions, same four call sites.

## v5.1.7
**Restored**
- `ReapplyNeededDialog` and its four call sites (both Bewerken apply
  paths, Bibliotheek "Gebruiken," Slideshow photo "Gebruiken") --
  removed in v5.1.4 as too intrusive, replaced with a passive
  Start-screen banner in v5.1.5, but the banner alone wasn't resolving
  the reported problem in practice. Both now coexist rather than one
  replacing the other: this dialog fires immediately at the moment of
  applying (hard to miss, right when it matters), while the v5.1.5
  Start banner remains as a backup for whenever the connection is
  stale for any other reason and Start happens to be checked
  afterward. `PresetStore.isThisAppTheSystemWallpaper()` (already
  restored in v5.1.5 for the banner) is unchanged, just consumed from
  more places again.

## v5.1.6
**Fixed**
- `onVisibilityChanged()`'s v4.6.0 safety net (re-verifies the active
  video against `ActiveVideoFile` every time the wallpaper becomes
  visible, independent of the cross-process broadcast) was the one
  player-touching code path that never checked the `isRebuilding` guard
  added during the v5.1.x merge -- every other rebuild-triggering
  function (`checkForStall()`, `checkHeapPressure()`,
  `checkProactiveRefresh()`, `recoverFromPlayerError()`) already did.
  Now guarded the same way: if a rebuild is already in flight when
  visibility changes, this path is skipped entirely and left to the
  in-progress rebuild, which already re-reads `ActiveVideoFile` fresh
  and will land on the correct video once it finishes on its own.
  Found while investigating a report that a video still wasn't
  re-applying correctly -- flagged honestly as a genuine, real
  inconsistency worth fixing regardless, but not confirmed as the
  specific cause of that report without further testing.

## v5.1.5
**New**
- A small, non-blocking banner on Start (`reapplyBanner`), shown only
  when there's an active preset *and* Android isn't currently pointing
  at this app as the wallpaper -- checked passively in `onResume()`
  alongside the existing preview/battery refresh, never interrupting an
  apply action. Tapping the banner's action opens the system wallpaper
  picker directly (reusing `StartFragment.openSystemWallpaperPicker()`,
  already built for the "Instellen als achtergrond" button).
  `PresetStore.isThisAppTheSystemWallpaper()`, removed in v5.1.4 as
  part of stripping the old dialog-on-apply, is back -- same detection,
  different presentation. This is the deliberate middle ground between
  v4.4.0's original approach (a dialog interrupting every apply action,
  found too intrusive) and v5.1.4's silent removal (which traded away
  the interruption but also traded away the only signal that something
  needed attention at all -- confirmed as a real problem once actually
  hit in practice, not just a theoretical downside).

## v5.1.4
**Removed**
- `ReapplyNeededDialog` (added v4.4.0) and every call site that could
  trigger it -- Bewerken's two apply paths, Bibliotheek's "Gebruiken,"
  and Slideshow's photo "Gebruiken." All four now always show the
  normal success toast and return to Start, regardless of what
  `PresetStore.isThisAppTheSystemWallpaper()` returns. Explicit product
  decision: confirmed via a byte-for-byte diff that the trigger code
  hadn't changed across v5.0.0-5.1.3, and the specific trigger (Android
  not yet recognizing this app as the live wallpaper) only happens
  after the app itself has been uninstalled -- an OS-level state no app
  code can prevent or detect any differently. Rather than keep
  surfacing a message about a state that can't be fixed, the app now
  just silently returns to Start either way; on the rare case Android
  genuinely isn't pointing at this app yet, re-tapping "Instellen als
  achtergrond" from Start (which opens the system picker directly)
  resolves it same as always. `PresetStore.isThisAppTheSystemWallpaper()`
  had zero remaining callers after this change and was removed too, for
  cleanliness -- `StartFragment`'s own "Instellen als achtergrond" flow
  (which opens the system picker directly) never used this function and
  is completely unaffected.

## v5.1.3
**Removed**
- `ExoPlayer.Builder.setWakeMode(C.WAKE_MODE_LOCAL)` and the `WAKE_LOCK`
  manifest permission (added in v5.1.0). Explicit decision given the
  real-world confirmation the long-uptime freeze no longer occurs with
  the other v5.0.0->v5.1.1 changes alone (async decoder mode, the
  split/faster watchdog, Media3 1.10.1's own native memory leak fix) --
  the wake lock's own real-but-modest battery cost is no longer worth
  carrying for a problem that appears independently resolved, and
  battery life is the higher priority.

## v5.1.2
**Fixed** (found while reviewing v5.1.1, brought into this project's
working copy from a separate session)
- **`isRebuilding` permanent-stuck-state bug.** Root cause:
  `swapMediaItem()`'s photo branch, when called while the wallpaper
  wasn't currently visible (`currentHolder == null`), only set
  `isShowingPhoto = false` -- it never released the existing video
  `player`. That left `player` non-null while `ActiveVideoFile`'s
  on-disk type marker already said "photo," a state mismatch. If a
  later heap/proactive-refresh check (neither requires visibility) then
  fired on that stale video player, set `isRebuilding = true`, released
  it, and called `preparePlayerIfNeeded()`, that function would read the
  type marker, take the photo branch, and return -- without ever
  resetting `isRebuilding`. Once stuck, every future stall/heap/
  proactive/error-recovery check silently no-oped forever for that
  Engine's lifetime, the entire watchdog gone dark with zero indication
  anything was wrong. Fixed at both levels: the photo branch of
  `swapMediaItem()` now calls `releasePlayer()` when there's an existing
  player, so the state mismatch that enabled this can't occur in the
  first place; and every exit point of `preparePlayerIfNeeded()`'s photo
  branch now resets `isRebuilding = false` too, as defense in depth
  independent of whether the root-cause fix is airtight.
- **Locale parity**: `changelog_v5_1_0_*` and `changelog_v5_1_1_*`
  existed only in `values/` (Dutch) -- missing from `values-en/de/fr/es`
  entirely. Not build-breaking (Android falls back to the default
  locale), but meant anyone on English/German/French/Spanish would see
  those two changelog entries in Dutch. Translated and added to all
  four locales.

## v5.1.1
**Fixed**
- Build failure introduced by v5.1.0's Media3 1.10.1 upgrade: the AAR
  metadata check failed with "requires libraries and applications that
  depend on it to compile against version 36 or later of the Android
  APIs" for all ten `androidx.media3:*:1.10.1` artifacts, since `:app`
  was still compiling against `android-35`. `compileSdk` bumped 35 -> 36
  to satisfy this. `com.android.application` (AGP) bumped to 8.9.1 and
  the Gradle wrapper to 8.11.1, since AGP 8.5.2's max recommended
  compileSdk was only 34 -- nowhere near enough to build against 36 --
  and AGP versions before 8.9.x don't support compileSdk 36 at all.
  Deliberately does *not* touch `targetSdk` (still 35) -- compileSdk
  controls which APIs are available to compile against, targetSdk
  controls which runtime behavior changes the app opts into, and those
  are independent knobs. Keeping targetSdk at 35 for now keeps this a
  pure build-unblocking fix, with the Android 16 behavior-change
  evaluation (edge-to-edge, background quotas, etc.) still deliberately
  deferred as its own separate, isolated step. Not yet build-verified in
  this environment (no network access to resolve the new AGP/Gradle
  versions) -- needs a local `./gradlew assembleDebug` before release.

## v5.1.0
**Fixed**
- Build failure discovered after the Media3 bump below: `media3-*:1.10.1`
  requires `compileSdk = 36`, which AGP 8.5.2 doesn't support (max 34).
  Missed in the earlier isolation plan, which assumed the Media3 upgrade
  and the AGP/compileSdk/targetSdk upgrade (originally planned for a
  later, separate version) could stay fully independent -- they can't,
  since a library's own minimum compileSdk isn't optional. Resolved with
  the smallest possible change: AGP bumped to 8.9.1 (the earliest version
  supporting compileSdk 36, avoiding the much larger AGP 9.x/Gradle 9.1
  jump) and Gradle wrapper to 8.11.1, `compileSdk` raised to 36.
  **`targetSdk` deliberately left at 35** -- compileSdk only affects which
  APIs are available at compile time, it does not opt the app into any
  Android 16 runtime behavior changes (edge-to-edge, background job
  quotas, etc.), so this does not pull forward the separately-planned
  targetSdk 36 step or its testing burden. Kotlin version left unchanged
  at 1.9.24.
- Stall detection split off from the slower heap/heartbeat/proactive-refresh
  loop (`checkForStall()` now runs on its own `stallCheckRunnable`, every
  `STALL_CHECK_INTERVAL_MS` = 2s, instead of sharing the old combined 10s
  `watchdogRunnable`). Reading `player.currentPosition` is a cheap in-process
  getter with no IPC or decoder call involved, so this costs effectively
  nothing extra. Worst-case detection time drops from ~13-20s to
  ~`STALL_CHECK_INTERVAL_MS * STALL_THRESHOLD_CHECKS` (~4s) plus rebuild
  time. The old one-shot `FAST_RECHECK_MS` hack (a workaround for the
  previous slow shared cycle) is removed as no longer needed.
- Added an `isRebuilding` guard checked and set across all four rebuild
  paths (stall, heap pressure, proactive refresh, error recovery), reset
  once `preparePlayerIfNeeded()` finishes in a `finally` block. Closes a
  race where the old fast-recheck path and the regular watchdog cycle
  could both decide to rebuild the player within the same window.
- Nuanced the code comment on `forceEnableMediaCodecAsynchronousQueueing()`:
  previously stated it "matches an open, unresolved report" on the Media3
  tracker for Pixel 10 freezes. On closer reading, that tracker issue
  describes freezing within seconds on DRM'd live DASH streams -- a
  different symptom profile than our confirmed issue (local file, freezes
  after hours). The comment now reflects this as plausible, not verified.

**New**
- `ExoPlayer.Builder.setWakeMode(C.WAKE_MODE_LOCAL)` on the wallpaper's
  player. Media3 1.9+ enables equivalent wake-lock handling by default,
  specifically to fix "issues with buffering during background playback"
  where progress can be delayed without one. Set explicitly here so this
  takes effect immediately rather than waiting on the dependency upgrade
  below. Holds a partial wake lock only while actively playing (paused
  wallpaper costs nothing extra); requires the new `WAKE_LOCK` permission.
  Not expected to be free -- flagged for verification against
  `DiagnosticLog`'s existing drain-rate figures rather than assumed
  neutral.
- Resolution/codec/bitrate/fps logging on player init
  (`playerErrorListener.onTracksChanged()`, guarded by `formatLogged` so
  it only logs once per player instance, not on every subsequent track
  change). Previously a stall/heap rebuild log line had no way to show
  what quality was actually decoding at the time -- this closes that gap
  for future freeze analysis.
- Media3 dependencies (`media3-exoplayer`, `media3-common`,
  `media3-transformer`, `media3-effect`) bumped from 1.4.1 to 1.10.1 --
  about 1.5 years of upstream fixes, including built-in stuck-player
  detection (`StuckPlayerException`, unavailable on 1.4.1) and a
  previously-confirmed memory leak fix in `MergingMediaSource` (#2338),
  which may explain freezes seen despite low measured JVM heap usage
  (native/graphics memory isn't visible to `checkHeapPressure()`).
  Verified against the app's actual Media3 API surface for breaking
  changes (`Muxer` relocation, `FrameExtractor` removal, mandatory
  `setImageDuration()` for image items) -- none apply, since none of
  those classes/paths are used here. Not yet build-verified in this
  environment (no network access to resolve the new dependency
  versions) -- needs a local `./gradlew assembleDebug` before release.

## v5.0.0
**New**
- Battery usage made visible in two places, deliberately built as one
  real number where real data exists and one relative estimate where
  it doesn't -- never a fabricated precise figure presented as fact:
  - **Start**: shows the actual measured drain rate
    (`DiagnosticLog.estimatedDrainRatePerHour()`, the exact same
    calculation Diagnostiek's battery analysis already used since
    v4.9.0) directly on the screen you look at day to day, instead of
    only in Diagnostiek where it's easy to forget to check. The
    calculation itself was refactored out of `DiagnosticsActivity` into
    `DiagnosticLog.kt` so there's exactly one source of truth for this
    figure, shared by both screens.
  - **Bewerken**: shows a relative estimated battery impact
    (Laag/Gemiddeld/Hoog), computed from the chosen resolution and
    framerate cap -- *not* bitrate, since bitrate affects file
    size/detail-per-frame, not how much continuous work the decoder
    actually does reconstructing each frame. Weighted by height² (roughly
    proportional to pixel count, the dominant factor) with framerate cap
    as a secondary multiplier. Deliberately a directional comparison
    (there's no way to know the impact precisely before compression,
    and presenting a made-up number as fact would be actively
    misleading), updates live as quality/framerate selections change,
    piggybacking on the existing `updateEstimatedSize()` trigger points
    rather than adding new call sites.

## v4.9.3
**New**
- Proactive decoder refresh (`checkProactiveRefresh()`): a defensive
  layer alongside v4.9.2's async-decoder fix, not a substitute for it.
  Every 2 hours (`PROACTIVE_REFRESH_INTERVAL_MS`) -- comfortable margin
  ahead of both confirmed freeze onsets (~3h07m, ~11h11m) -- the decoder
  is proactively rebuilt before whatever internal state causes the
  known Pixel 10 stall has a chance to accumulate that far. Deliberately
  a *full* rebuild (fresh `ExoPlayer` instance), not a hot-swap via
  `setMediaItem()` on the same player -- a hot-swap can end up reusing
  the same underlying `MediaCodec` session if the format hasn't
  changed, which wouldn't actually reset the state this is trying to
  avoid. The current playback position is captured before release and
  restored via `seekTo()` after the rebuild, so this is invisible to
  the person watching -- without that, every refresh would visibly jump
  the video back to 0:00 mid-playback. Logged and counted separately
  from stall/heap rebuilds (`DiagnosticLog.incrementProactiveRefreshes()`)
  -- a healthy, scheduled rebuild isn't a problem event, and mixing it
  into those counts would skew the battery-correlation analysis meant
  to track real failures. Skipped entirely while a photo is active
  (no decoder session to refresh for a static image).
- Also considered and explicitly parked as a last-resort future option
  (not built): caching a short decoded loop and replaying it more like
  an animated texture than a continuously-driven live decode session --
  a genuine architectural rework, not a small patch.

## v4.9.2
**New / Fixed**
- Real attempted root-cause fix for the confirmed long-uptime decoder
  stall (two data points so far: ~3h07m and ~11h11m of continuous
  playback before freezing, both with heap at only 2% and thermal
  normal, ruling out memory pressure and overheating). Google's own
  Media3 issue tracker has an open, unresolved report specifically for
  **Pixel 10 series devices freezing during playback** -- confirming
  this device generation has a documented decoder quirk, not something
  unique to this app. `ExoPlayer` is now built with a
  `DefaultRenderersFactory.forceEnableMediaCodecAsynchronousQueueing()`
  renderers factory, which changes how ExoPlayer talks to the hardware
  decoder at the threading level (asynchronous MediaCodec callbacks
  instead of ExoPlayer's default synchronous polling) -- a real attempt
  at the underlying issue, not a workaround. Explicitly *not* paired
  with a proactive scheduled player rebuild (considered and rejected --
  the ask was for a real fix attempt, not papering over the symptom).
- As a faster safety net in case async mode doesn't fully resolve it:
  the stall watchdog now fires a one-shot follow-up recheck
  (`FAST_RECHECK_MS = 3_000L`) just 3 seconds after the *first*
  suspicious check, instead of waiting for the next full 10-second
  cycle to confirm. Worst-case detection time drops from ~20s to ~13s.
  Deliberately implemented as an extra one-shot check triggered only
  when something looks wrong, not by lowering `WATCHDOG_INTERVAL_MS`
  itself -- normal-state polling frequency (and therefore normal-state
  battery cost) is unchanged; only a suspected stall gets the closer
  look. `stallSuspectedAtMs` now tracks real elapsed time for the
  "frozen ~Xs" log figure too, since the old `checks * interval` math
  would have been wrong once checks stopped happening at a uniform
  interval.
- Battery impact assessed: async decoder mode should be negligible to
  none (changes callback threading, not how much decoding work
  happens). The faster recheck has a small, real cost from the extra
  wake-up when a stall is suspected, but doesn't touch the normal
  10-second cadence.

## v4.9.1
**Fixed**
- Photo import failing with "could not open input stream" for photos
  from cloud-backed galleries (Google Photos being the common case).
  The v4.8.1 diagnostics logging (added specifically so failures like
  this would be traceable) pinpointed the exact cause on the first real
  report: `ContentResolver.openInputStream()` returning `null` *without
  throwing* -- a documented Android behavior for provider-exposed
  "virtual documents" (items not fully cached locally, or requiring
  explicit MIME-type negotiation to export). Added
  `PhotoStore.openImageStream()`: tries `openInputStream()` first (cheap
  for the common local-file case), and falls back to
  `openTypedAssetFileDescriptor(uri, "image/*", null)` when that
  specifically returns null rather than throwing (a thrown exception
  means something more fundamental -- permission revoked, invalid URI --
  that a different open method wouldn't fix either). Used for both the
  bounds-only decode pass and the full decode pass.

## v4.9.0
**New**
- Battery drain-rate estimate (`DiagnosticsActivity.computeDrainRateLine()`):
  turns the battery readings already embedded in every heartbeat/rebuild/
  error log line into one concrete %/hour number, averaged across
  consecutive not-charging readings 1 minute to 3 hours apart (filters
  out same-instant duplicates and multi-day gaps where the phone was
  used normally in between). Known limitation: log timestamps have no
  year, so this would compute nonsense across a year boundary --
  acceptable given how recently the app has been in use.
- Preset/photo activation now logged from the main app side too
  (`PresetStore.setActive()` / `PhotoStore.setActive()`, via
  `DiagnosticLog.appendAppEvent()`), not just the wallpaper service's
  own "Player initialized" line -- gives visibility into *why* a switch
  happened (Bibliotheek tap vs. Slideshow rotation vs. a fresh Bewerken
  compress), not just that one did.
- Visibility transitions logged, but only meaningful ones: if the
  wallpaper was hidden for 60+ seconds (screen off for a while, phone
  untouched) before becoming visible again, that's now logged with the
  hidden duration. Deliberately *not* logged for brief app-switch
  flickers -- those happen dozens of times a day and would flood the
  200-line log for no diagnostic benefit, the same reasoning already
  applied to loop detection.

**Removed**
- Music sync dropped from the wishlist entirely (previously deferred,
  now confirmed not needed for this app).

## v4.8.1
**Fixed**
- `PhotoStore.importPhoto()` caught every failure silently and just
  returned `null` -- there was no way to tell "couldn't open the file"
  apart from "opened fine but couldn't decode the format" apart from
  "decoded fine but failed to save," so a report of "can't add a photo"
  had nothing to go on. Now every failure path logs the specific stage
  and reason via `Log.e()` and `DiagnosticLog.appendAppEvent()`.
- Along the way this surfaced a real, concrete gap: `BitmapFactory` only
  decodes HEIC/HEIF via a raw stream on API 28+, but this app's
  `minSdk` is 26 -- on Android 8/8.1 specifically, a HEIC photo (a very
  common format on modern phone cameras) would fail to decode with no
  indication why. `bounds.outWidth`/`outHeight` coming back `<= 0` after
  the bounds-only decode pass is the signal BitmapFactory didn't
  recognize the format at all (vs. a merely small/corrupt image), and
  is now caught and logged specifically as that, including the picked
  file's actual MIME type for context.
- `photo_import_failed` toast now points at Diagnostiek for the specific
  reason, instead of only saying something failed.

## v4.8.0
**New**
- Battery-use investigation (Diagnostiek): a new "Batterij-analyse" card
  parses the log and directly answers the open question -- how many
  rebuilds happened while charging vs. not charging -- instead of
  leaving raw counters for the person to eyeball across 200 log lines.
  Included in the shared plain-text report too.
- Loop detection: `Player.Listener.onPositionDiscontinuity` with
  `DISCONTINUITY_REASON_AUTO_TRANSITION` now tracks video loop timing.
  Deliberately *not* logged as its own line -- a short video can loop
  hundreds of times an hour, which would dominate the log within
  minutes. Instead surfaced only where it's diagnostically useful: in
  stall-rebuild log lines, as "last loop Xs ago," to test whether
  stalls cluster around a video's loop boundary (a plausible trigger --
  the brief re-seek a loop involves -- that hadn't been checked before).
  `DiagnosticLog.incrementLoopCount()` also feeds a lifetime counter.
- Notification pulse (`NotificationPulseListenerService`, `PulsePrefs`):
  the wallpaper briefly flashes an accent-colored overlay when a
  notification arrives. Scoped to photo mode only -- ExoPlayer owns the
  wallpaper's one Surface exclusively while playing video, and there's
  no safe way to draw an overlay on top of it without a much larger
  rework (custom OpenGL compositing, essentially a new rendering
  architecture). `drawPhotoToSurface()` gained an `overlayAlpha`
  parameter for this. Requires manually granting "Notification access"
  in system settings (`Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS`)
  -- Android doesn't allow that permission to be requested via a normal
  runtime dialog. New UI card in Slideshow (toggle + access button).
  Music sync was considered for the same "point 4" wishlist item but
  deliberately not built -- same Surface-compositing limitation applies
  to video, plus it would need audio-session permissions on top; not
  worth building a half-working version now.

**Fixed**
- A missing closing brace in `DiagnosticsActivity.kt`'s new
  `buildBatteryAnalysis()` (would have failed to compile) and another
  double-hyphen-in-an-XML-comment instance in the manifest -- both
  caught by validation before packaging.

## v4.7.0
**New**
- Slideshow photo support -- a real second rendering mode in the
  wallpaper Engine, not a workaround:
  - `Photo.kt` / `PhotoStore.kt`: much simpler than `Preset`/`PresetStore`
    since photos need no transcoding, bitrate, or config-signature --
    a picked image is just downsampled (`BitmapFactory.Options
    .inSampleSize`, capped at the same 2160px the video pipeline uses)
    and copied into the app's own storage.
  - `ActiveVideoFile` gained `writeType()`/`readType()` (`TYPE_VIDEO` /
    `TYPE_PHOTO`), stored as a small plain file alongside the existing
    URI file. Missing entirely (any install predating this) defaults to
    video, since every write before this feature existed was always a
    video. `PresetStore.setActive()` and `PhotoStore.setActive()` each
    write their own type and clear the other's "active" marker, keeping
    a photo and a video preset mutually exclusive.
  - `VideoWallpaperService`'s Engine now branches on that type at every
    entry point that used to assume ExoPlayer (`preparePlayerIfNeeded()`,
    `swapMediaItem()`, `onSurfaceChanged()`). For a photo, no ExoPlayer
    is ever built at all -- `showPhoto()` decodes the (already-downsampled)
    bitmap and `drawPhotoToSurface()` draws it directly to the surface's
    `Canvas` via `lockCanvas()`/`unlockCanvasAndPost()`, center-crop
    filled the same way the video pipeline fills the screen. The
    watchdog's stall/heap/heartbeat checks all guard on `player != null`
    already, so they're naturally no-ops while a photo is showing --
    no separate "skip while photo" logic needed there.
  - `SlideshowReceiver` now builds one combined rotation pool (videos
    then photos, filtered by the same favorites-only setting) instead
    of only ever rotating `Preset`s.
  - Slideshow screen gained a Foto's card: add via the system document
    picker (`OpenDocument`, same permission-free approach the video
    picker already uses), rename/favorite/delete/use, mirroring
    Bibliotheek's preset-row pattern via a new `item_photo.xml`.
- Slideshow custom interval: a 4th radio option alongside the fixed
  15/30/60 minute choices, revealing a numeric minutes input
  (`SlideshowPrefs.CUSTOM_INTERVAL_SENTINEL`, stored as -1 in the normal
  interval key with the real value in a separate custom-minutes key).

## v4.6.0
**Fixed**
- The real cause of "tapped Gebruiken on a Library preset, the app shows
  Actief, but the wallpaper on screen never actually changes." This was
  a different bug than the one v4.4.0 fixed: `isThisAppTheSystemWallpaper()`
  correctly returns true (Android does still consider this app's service
  the configured wallpaper), so the `ReapplyNeededDialog` never even
  fires -- the problem is one level deeper. `onVisibilityChanged()`
  previously just called `p.play()` on whatever player already existed
  whenever the wallpaper became visible again, without ever re-checking
  if the active video had changed. The *only* thing that ever told a
  running Engine about a new active video was `activeVideoChangedReceiver`
  -- if that broadcast is ever missed for any reason (a timing edge case
  around an app update, the receiver not being registered at the right
  moment, etc.), the player would just keep resuming the same stale
  video indefinitely, with no way to notice or self-correct.
  `onVisibilityChanged()` now re-reads `ActiveVideoFile` and compares it
  against `currentVideoUri` every time the wallpaper becomes visible
  again (returning to the home screen, unlocking, etc.), calling
  `swapMediaItem()` if they differ -- a safety net that doesn't depend
  on the broadcast having successfully arrived. Logged via
  `logEvent("Active video changed while not visible -- catching up on
  resume")` when it fires, so it's visible in Diagnostiek if this path
  is what actually resolves a future case.

## v4.5.0
**New**
- Watchdog log lines made more specific across every rebuild-adjacent
  event (stall, heap, player error, lightweight recovery):
  - **Thermal status** (`PowerManager.getCurrentThermalStatus()`, API
    29+, "n/a" on older devices) -- the confirmed freeze so far had heap
    at just 2%, ruling out memory pressure but leaving device overheating
    as an untested candidate. Now directly checkable from the log.
  - **Playback state at the exact moment of detection**
    (`ExoPlayer.playbackState`, mapped to idle/buffering/ready/ended) --
    distinguishes "it was playing smoothly and then froze" from "it was
    stuck rebuffering," which point at different causes and were
    previously indistinguishable from the log alone.
  - **Time since the previous rebuild** (`lastRebuildAtMs`, tracked
    across stall/heap/error-recovery events uniformly) -- reveals
    clustering/frequency that a single timestamp per event can't show
    on its own.
  - The heartbeat line also gained thermal status, so there's a normal
    baseline to compare rebuild-time readings against.

## v4.4.0
**Fixed**
- The post-update "active wallpaper" bug, for real this time.
  `KEY_LAST_SEEN_VERSION_CODE` was introduced in v3.6.7 and never existed
  in any earlier version, so reading it back as `-1` was being used as
  "genuinely fresh install" -- but that's indistinguishable from
  "upgrading from any pre-3.6.7 version," and the earlier fix always
  took the fresh-install branch, silently skipping the reset on exactly
  the upgrade path it existed to handle. Now the real signal is whether
  an active preset is actually recorded (`PresetStore.activePreset()`),
  not whether the tracking key happens to exist.

**New**
- Detects when Android itself isn't pointing at this app as the live
  wallpaper anymore (`PresetStore.isThisAppTheSystemWallpaper()`, via
  `WallpaperManager.getInstance(context).wallpaperInfo`), which can
  happen independently of the app's own state after an update -- the
  app's internal "active" bookkeeping can be perfectly correct while the
  OS-level connection is stale, and no broadcast the app sends reaches
  anything in that case. Checked at every `PresetStore.setActive()` call
  site (Bibliotheek's "Gebruiken", both of Bewerken's apply paths).
  When detected, `ReapplyNeededDialog` (new shared dialog, matching the
  existing `EditVideoPromptDialog`/`PreviewDialog` pattern) explains why
  nothing visibly changed and offers a direct button into Android's own
  wallpaper picker -- the only thing that actually re-establishes that
  connection.
- Diagnostic logging overhaul (`DiagnosticLog.kt`):
  - Line cap raised from 40 to 200. What was reasonable for one or two
    event types early on gets crowded out fast once five or six
    different kinds of events (stalls, heap rebuilds, error recoveries,
    hot-swaps, app-lifecycle events) share the same rolling window.
  - Every timestamp now includes the date, not just the time -- a
    200-line log can legitimately span many days now.
  - New `appendAppEvent()` entry point for events that happen in the
    main app process rather than inside a specific wallpaper Engine
    instance (no engine instanceId to tag them with, so they get a flat
    `[APP]` tag instead).
  - New `appendVersionMarker()`: a visually distinct divider line logged
    on every version change (skipped on a genuinely first-ever install),
    so a long exported log makes version boundaries obvious -- directly
    useful for "did this start after an update" questions, which both
    the post-update and battery-use investigations depend on.
  - The new stale-wallpaper-connection detection above logs every
    occurrence via `appendAppEvent()`, so patterns (does it always
    follow an update, is it device-specific, etc.) become visible in
    exports over time instead of only being observed anecdotally.
  - Battery level and charging state now included in every watchdog
    rebuild log line (`BatteryManager.BATTERY_PROPERTY_CAPACITY` +
    `isCharging`), directly feeding the battery-use investigation.
  - New hourly heartbeat line (uptime, heap%, battery) while the
    wallpaper is active, logged regardless of whether anything went
    wrong -- without it there was no way to tell "quiet period" apart
    from "wallpaper wasn't running," and no baseline to compare a
    rebuild's numbers against.
  - CSV export added alongside the existing plain-text share
    (`DiagnosticsActivity.exportCsv()`), parsing each log line's
    timestamp/category/message into real columns via a new
    `FileProvider` (declared fresh in the manifest, none existed
    before) so it opens correctly in Excel/Sheets rather than being
    pasted as raw text.

## v4.3.0
**New**
- Button feedback style is now configurable in Stijl, three options:
  - **Scale** (new default): the pressed view shrinks slightly on
    touch-down and springs back on release. Immediate and visible on any
    tap length, since it's driven directly by the touch event rather
    than by how long an animation has to play before something else
    interrupts it.
  - **Ripple (delayed)**: keeps the existing `RippleDrawable`, but the
    actual click is delayed ~150ms (`View.performClick()` posted via a
    `Handler`) so the ripple has time to render before the screen
    changes underneath it.
  - **Flash**: a brief alpha dip on touch-down.
  - All three are implemented as a touch-listener view-tree walker
    (`StylePrefs.applyButtonFeedbackStyle`), wired into the same 10
    screens as the other Stijl view-tree passes. `SeekBar` and
    `EditText` are explicitly excluded, since a consuming touch listener
    (used by the Ripple-delayed style) could interfere with drag/text
    gestures.

**Fixed**
- Root cause of "feedback only visible on a long press, not a normal
  tap": most of Stijl's click handlers call `recreate()` immediately,
  tearing down and rebuilding the whole screen faster than the existing
  `RippleDrawable` animation had time to render on a quick tap-release --
  only a slow press-and-hold gave it enough time to become visible. The
  new default (Scale) sidesteps this entirely by not depending on
  animation duration surviving until release.
- Chips in Bewerken (which get fully recreated on every selection, not
  just once at screen load) now get their feedback touch listener
  attached at chip-creation time inside `renderChipRow()`, rather than
  relying on a single walker pass that would miss every chip rebuilt
  after the initial one.

## v4.2.1 (build tooling only, no in-app changes)
**Changed**
- The built APK file itself is now named `Video Wallpaper(<version>).apk`
  (e.g. `Video Wallpaper(4.2.1).apk`) instead of the AGP default
  `app-release.apk`. Set via `applicationVariants.all { outputs.all {
  outputFileName = ... } }` in `app/build.gradle.kts`, using each
  variant's own `versionName` -- applies automatically to every future
  build without needing to be touched again as the version changes. This
  is the actual file Android Studio produces in `app/build/intermediates
  /apk/release/`, separate from the delivered zip's own
  `Video-Wallpaper VX.X.X.zip` / `VideoWallpaper VX.X.X/` naming, which
  was already in place.

## v4.2.0
**New**
- Stijl: both the accent and background RGB cards now have an editable
  hex input (type a 6-digit code directly) and a numeric input next to
  each R/G/B slider (type the exact 0-255 value instead of only
  dragging). `StyleActivity.kt` was restructured around a single
  `ColorGroup` inner class shared by both cards, since the accent and
  background groups are functionally identical -- avoids duplicating the
  sync logic twice. Each field (slider, numeric input, hex input) can
  drive the other two; an `updatingProgrammatically` guard flag on the
  group prevents update loops when one field's change triggers another.

## v4.1.0
**New**
- Stijl: custom background color via R/G/B sliders, mirroring the accent
  RGB slider exactly (same UI pattern, `StyleActivity.kt`). Wires up the
  new `BACKGROUND_CUSTOM` hue in `StylePrefs.kt`.
- `resolveBackgroundColor()` is now custom-aware, matching how
  `resolveAccentColor()` already handled `ACCENT_CUSTOM`.
- `applyBackgroundPattern()` (previously a no-op when pattern was "none")
  now also runs whenever a custom background color is active, applying
  it as a plain `ColorDrawable` on the root view when there's no pattern
  to composite it with. No new call sites needed -- the 9 screens that
  already called this function for pattern support automatically pick
  up custom background color too.

## v4.0.1
**Fixed**
- Kotlin compile error in `StylePrefs.kt`'s new corner-shape logic:
  `variants[bg.constantState]` indexed a `Map<Any, Int>` with a nullable
  key (`Drawable.ConstantState?`), since `Map.get()` requires a non-null
  key of the map's declared key type. Kotlin surfaces that mismatch as a
  confusing "type parameter K should be mentioned in input types" error
  rather than a clear nullability message. Fixed by explicitly checking
  the constantState for null and smart-casting to non-null before using
  it as the map key.

## v4.0.0
**New**
- Circular reveal transition (`HostActivity.kt`): tab switches now expand
  from the tapped nav icon's actual on-screen position
  (`ViewAnimationUtils.createCircularReveal`), replacing the Slide-based
  transition from v3.8.1. Since circular reveal needs both the outgoing
  and incoming fragment's views present at once (unlike `replace()`,
  which destroys the old view immediately), this uses `add()` + a manual
  reveal `Animator`, removing the old fragment only once the new one has
  fully covered it.
- Corner shape (`StylePrefs.applyCornerStyleToViewTree`): rounded/sharp
  toggle for cards, buttons, and chips app-wide. Implemented via
  `_sharp` drawable variants swapped in by comparing `Drawable
  .constantState` against the known rounded resources -- no layout XML
  changes needed to identify which views to swap.
- Font size (`BaseActivity.kt`): every Activity now extends a shared base
  class that applies the stored scale via a `Configuration` override in
  `attachBaseContext()`, so it's one implementation point for the whole
  app instead of per-screen text-size math.
- Typeface (`StylePrefs.applyTypefaceToViewTree`): serif/monospace/default,
  via a view-tree walk since Android has no Configuration-level typeface
  override the way it does for font scale. Uses the built-in generic
  font families -- no bundled font files.
- Background pattern (`StylePrefs.applyBackgroundPattern`): a small
  dot/diagonal-line tile generated procedurally at runtime via `Canvas`
  and tiled with `BitmapDrawable` + `TileMode.REPEAT`, layered over the
  resolved background color. No image assets needed.
- App icon following the accent color (`IconAliasManager.kt`): 5
  `<activity-alias>` entries targeting `OnboardingActivity` (the real
  launcher entry point), each with its own pre-baked icon, toggled via
  `PackageManager.setComponentEnabledSetting()` whenever the accent
  changes. Only covers the 5 preset hues -- a custom RGB accent can't be
  represented as a static icon, so custom mode falls back to the
  default (blue) icon.

**Fixed**
- Button press feedback was present but nearly imperceptible
  (`button_background`'s pressed-state color was `#E1EDF7` vs `#CFE0F0`
  unpressed -- barely different) or entirely absent (`button_accent_
  background`, the chip drawables, the nav bar and Meer/Settings rows,
  the Stijl color swatches, and Bibliotheek's rename/favorite buttons
  all had no background at all, so literally nothing happened on tap).
  Converted the button/chip drawables to real `RippleDrawable`s, added
  `?attr/selectableItemBackground` (or the borderless variant for small
  icon-style buttons) to every previously bare clickable row, and
  wrapped the programmatically-built Stijl swatches in a
  `RippleDrawable` too.

## v3.9.1 (build tooling only, no in-app changes)
**Fixed**
- `INSTALL_BASELINE_PROFILE_FAILED` persisted even after the v3.8.2
  workaround (`android.experimental.art-profile-r8-rewriting=false`) --
  that flag only controls whether R8 *rewrites* the profile's obfuscated
  member references, it doesn't stop AGP from embedding one in the APK at
  all. This time the actual profile files are excluded from packaging
  entirely (`packaging { resources { excludes += ... } }` in
  `app/build.gradle.kts`, targeting `assets/dexopt/baseline.prof` and
  `.profm`), so there's nothing left for the buggy installer step to act
  on. No effect on app behavior -- only removes an ART startup-time
  optimization hint that isn't meaningful for local debug installs anyway.
- If this still doesn't resolve it on your machine: try installing via
  `adb install -r app-release.apk` directly from a terminal instead of
  Android Studio's Run button -- Android Studio's own deployer uses a
  different install path than plain `adb install` and is more commonly
  affected by this specific bug.

## v3.9.0
**New**
- Stijl: custom accent color via R/G/B sliders (`activity_style.xml` +
  `StyleActivity.kt`), with a live-updating preview swatch and hex value.
  Doesn't touch the stored accent hue until "Gebruik deze kleur" is
  tapped, so dragging the sliders is a pure preview. Wires up the
  `ACCENT_CUSTOM` infrastructure in `StylePrefs.kt` that had existed
  unused since v3.6.0.

## v3.8.2 (build tooling only, no in-app changes)
**Fixed**
- `INSTALL_BASELINE_PROFILE_FAILED` ("status=run-from-apk") when installing
  the release APK locally from Android Studio. This is a known AGP/Android
  Studio installer bug around ART baseline profiles, not an app bug --
  several AndroidX libraries (likely `fragment-ktx` and/or `transition`,
  both added in 3.8.0) ship their own bundled baseline profiles that AGP
  merges into the release APK automatically, and that merged profile can
  fail to install on some devices/Android Studio versions. Worked around by
  setting `android.experimental.art-profile-r8-rewriting=false` in
  `gradle.properties`, which disables that rewriting step for local
  installs without affecting app behavior.
- If this alone doesn't resolve it: try `Build > Clean Project` and
  rebuild, or fully uninstall the app from the device/emulator first
  before reinstalling (a stale baseline profile from a previous install
  can also trigger this).

## v3.8.1
**Fixed**
- Brief flash/flicker at the start of every tab switch. Root cause:
  `FragmentTransaction.setCustomAnimations()` with legacy `res/anim` View
  Animation resources has a known one-frame gap -- the incoming fragment's
  view gets measured/laid out at its *final* position before the animation
  transform is applied, so it flashes fully-formed for a frame before
  sliding. Replaced with the AndroidX Transition framework (`Slide`) set
  via `Fragment.enterTransition`/`exitTransition` +
  `setReorderingAllowed(true)`, which coordinates through the layout pass
  correctly. Added the `androidx.transition:transition` dependency.
  Activity-level transitions (Meer's sub-screens, Onboarding) are
  unaffected -- they use `overridePendingTransition`, a different
  mechanism without this issue, so they still use the `res/anim` files.

## v3.8.0
**Changed**
- Start, Bewerken, Bibliotheek, and Meer restructured from four separate
  Activities into a single `HostActivity` with four Fragments
  (`StartFragment`, `BewerkenFragment`, `LibraryFragment`, `MoreFragment`).
  The bottom nav bar now lives in `HostActivity`'s layout as a permanent
  sibling of the fragment container, so it's completely untouched by the
  slide transition -- only the container's content animates.
- `BottomNav.kt` rewritten: `setup()` wires click handling once,
  `updateActiveTab()` re-tints the bar on every fragment swap (it's no
  longer recreated per screen).

**Removed**
- `MainActivity.kt`, `BewerkenActivity.kt`, `LibraryActivity.kt`,
  `MoreActivity.kt`, and their standalone layouts -- replaced by the
  fragments above.

## v3.7.1
**Changed**
- Transition animation made noticeably more pronounced (60% translate
  instead of the previous subtle 8% shift).
- Transitions are now direction-aware: moving to a tab further along the
  bar slides right-to-left, moving back slides left-to-right.

## v3.7.0
**New**
- `Player.Listener.onPlayerError` registered on the ExoPlayer instance --
  the wallpaper now hears about decoder/frame-processing errors
  immediately instead of only detecting problems via position polling.
- Lightweight recovery path: on a reported error, the app first tries
  `prepare()` again on the same player instance before falling back to a
  full teardown + rebuild.
- New diagnostic counter: how often the lightweight recovery succeeded.
- The log now records the player's actual `PlaybackException` error code.

## v3.6.8
**Changed**
- Watchdog check interval doubled (5s -> 10s) and preventive heap-rebuild
  threshold raised (85% -> 90%) to reduce battery use from frequent
  rebuilds. Tradeoff: stall detection now takes ~20s instead of ~10s.

## v3.6.7
**Fixed**
- Post-app-update bug: the app now clears its "active wallpaper" state on
  every version change instead of continuing to claim an old preset is
  applied when it can no longer verify that. Shows a one-time notice.
  (Note: the initial fix had a bug of its own -- see "Known issues" below.)

**New**
- Diagnostiek: "Log delen" button exports device info, memory, counters,
  and the full log via the system share sheet.

## v3.6.6
**Changed**
- Watchdog log lines now include which video was involved, how long it
  had been playing, and memory usage at the moment of the event.

## v3.6.5
**Changed**
- Diagnostic log and counters moved off `SharedPreferences` onto plain
  files (`DiagnosticLog.kt`) -- same cross-process staleness problem as
  the active-video bug, same fix pattern.
- Every log line tagged with a short per-Engine-instance ID.
- Hot-swap failures are now logged in-app (previously logcat-only).

## v3.6.0 - v3.6.4
**New**
- Bewerken redesigned: chip-style Kwaliteit/Filter pickers, bitrate
  profiles (Zuinig/Gebalanceerd/Hoog/Aangepast) with a slider, icon-led
  Prestaties toggles, a Voorbeeld (preview) button, persistent bottom
  action bar.
- Bewerken settings now persist between sessions (`BewerkenPrefs.kt`).
- Custom in-app "Video bewerken?" bottom sheet, replacing the default
  AlertDialog (`EditVideoPromptDialog.kt`).
- Meer restructured: Stijl/Slideshow/Diagnostiek stay; Taal/Thema/Status/
  Batterij-uitzondering/Versiegeschiedenis moved into a new Instellingen
  screen (gear icon).
- Stijl: background color independently configurable from accent color
  (Blue/Slate/Warm via layered `ThemeOverlay`s), random button, reset
  button, and (currently unused/paused) infrastructure for a custom RGB
  accent color.
- Tab-switch transition animation added (fade, later changed to slide).

**Fixed**
- Real bug: video wouldn't update after the first-applied wallpaper,
  because `VideoWallpaperService` runs in a separate process and
  `SharedPreferences` writes from the main process weren't reliably seen.
  Fixed with a `BroadcastReceiver` carrying the new URI directly, then
  further hardened with `ActiveVideoFile.kt` (a plain file instead of
  `SharedPreferences`) once it turned out the wallpaper process could stay
  alive across multiple Engine instances with a stale cached prefs object.
- "Volledige 4K" quality option capped to a real 2160p ceiling instead of
  an unlimited passthrough that could overwhelm the encoder.
- AAPT build error: `ThemeOverlay.*` styles need explicit `parent=""` or
  AAPT infers (and fails to find) a parent from the dotted name.
- Kotlin compiler "recursive problem" on `renderXChips()` functions --
  fixed with explicit `: Unit` return types on self-referencing
  expression-body functions.

## Known issues
- **Post-update wallpaper bug -- confirmed fixed on a real device.** Three
  layers deep: (1) v3.6.7's original fix treated "no stored version code"
  the same as "fresh install" and skipped the reset on the very first
  launch after upgrading from any pre-3.6.7 version; v4.4.0 fixed the
  actual condition. (2) v4.4.0 also added detection for when Android
  itself isn't pointing at this app as the live wallpaper anymore,
  prompting to re-open the system picker. (3) v4.6.0 found a third,
  deeper layer: even when Android *does* still consider this app the
  configured wallpaper (so layer 2's check passes and no prompt
  appears), the specific running Engine could still be showing a stale
  video if it ever missed the cross-process broadcast telling it to
  switch -- `onVisibilityChanged()` now independently re-verifies the
  active video against `ActiveVideoFile` every time the wallpaper
  becomes visible again, rather than only reacting to that broadcast.
- Possible battery use increase in newer versions -- under investigation;
  v3.6.8's watchdog tuning and v3.7.0's error-listener/lightweight-recovery
  work are both aimed at this, not yet confirmed effective. v4.4.0 added
  battery level/charging state to every rebuild log line and an hourly
  heartbeat; v4.8.0 added a computed battery-correlation analysis
  (rebuilds while charging vs. not) and loop-boundary timing at stall
  events, so there's now real analysis tooling in place -- still needs
  enough real-world log time to accumulate before this can be called
  resolved either way.
- **Long-uptime decoder stall on Pixel 10 series devices -- confirmed
  resolved as of v5.1.1's changes.** Two confirmed freezes originally
  (~3h07m and ~11h11m of continuous playback before stalling, both with
  heap at only 2% and thermal normal, ruling out memory pressure and
  overheating). No longer occurring with the combination of v4.9.2's
  async MediaCodec queueing, the v5.1.0 faster/split watchdog (stall
  detection down to ~4s worst-case), and Media3 1.10.1's own confirmed
  native memory leak fix (`MergingMediaSource`) -- which may have been
  a contributing factor independent of anything tested here, since JVM
  heap alone (what `checkHeapPressure()` measures) was never the full
  memory picture. Given this confirmation, the `WAKE_LOCK`/
  `setWakeMode()` addition from v5.1.0 was removed again in v5.1.3 --
  its own real (if modest) battery cost is no longer worth carrying for
  an issue that appears resolved without it, and battery life is the
  higher priority. Worth revisiting whether v4.9.3's proactive 2-hour
  refresh is still needed as a defensive layer now that the root cause
  itself appears fixed -- open question, not yet decided.

## Still open / not built
- Visual overhaul for the Start screen and the Bewerken screen, for a
  future version.
- Whether the polling watchdog's role (including the proactive 2-hour
  refresh specifically) can be scaled back now that both the
  error-listener system (v3.7.0) and the confirmed long-uptime freeze
  fix are in place -- open question, revisit once there's enough
  heartbeat/battery log data to compare how often each path actually
  fires and whether the proactive refresh is still pulling its weight.

## Building

1. Open this folder in Android Studio, let Gradle sync (downloads Media3
   etc.).
2. `keystore.properties` is already included in this project with real
   values -- no manual setup needed.
3. Build Variant -> `release`, then **Build -> Build Bundle(s)/APK(s) ->
   Build APK(s)**.
4. Install the new APK. If updating from an existing install, you may need
   to re-apply your wallpaper afterward (see "Known issues" above).
