import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val keystorePropertiesFile = rootProject.file("keystore.properties")
val keystoreProperties = Properties()
val hasKeystoreProperties = keystorePropertiesFile.exists()
if (hasKeystoreProperties) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    namespace = "com.example.videowallpaper"
    compileSdk = 36

    // Several AndroidX libraries ship a bundled ART baseline profile
    // (assets/dexopt/baseline.prof + .profm), which AGP merges into the
    // release APK automatically. Installing that merged profile is what's
    // failing with INSTALL_BASELINE_PROFILE_FAILED / "status=run-from-apk"
    // -- a known Android Studio/adb installer bug, not an app issue.
    // Stripping the files out of the APK's packaging removes the thing
    // the buggy install step is choking on; the app runs identically
    // without a baseline profile, just without that startup-time
    // optimization hint (irrelevant for local debug/install use).
    packaging {
        resources {
            excludes += "/assets/dexopt/baseline.prof"
            excludes += "/assets/dexopt/baseline.profm"
        }
    }

    defaultConfig {
        applicationId = "com.example.videowallpaper"
        minSdk = 26
        targetSdk = 35
        versionCode = 80
        versionName = "5.12.0"
    }

    signingConfigs {
        if (hasKeystoreProperties) {
            create("release") {
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = keystoreProperties["keyPassword"] as String
                storeFile = file(keystoreProperties["storeFile"] as String)
                storePassword = keystoreProperties["storePassword"] as String
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (hasKeystoreProperties) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    // Renames the actual built APK file itself (not just the delivered
    // zip) to "Video Wallpaper(<version>).apk" -- applies to every build
    // variant/flavor combination automatically, so this doesn't need to
    // be touched again as versionName changes in future patches.
    applicationVariants.all {
        val variant = this
        outputs.all {
            val output = this as com.android.build.gradle.internal.api.BaseVariantOutputImpl
            output.outputFileName = "Video Wallpaper(${variant.versionName}).apk"
        }
    }
}

dependencies {
    // Media3 / ExoPlayer -- the same playback stack used by YouTube's own apps
    implementation("androidx.media3:media3-exoplayer:1.10.1")
    implementation("androidx.media3:media3-common:1.10.1")
    // Transformer/Effect -- used for the one-time transcode (cap resolution,
    // trim, bitrate, color enhance) done once when a video is picked, so the
    // wallpaper service itself never touches the heavy original.
    implementation("androidx.media3:media3-transformer:1.10.1")
    implementation("androidx.media3:media3-effect:1.10.1")

    // Deliberately no com.google.android.material and no media3-ui here --
    // both kept failing to link on this project's build (layout inflation
    // errors that never fully resolved), so the UI uses plain platform
    // widgets (Button, Switch, SurfaceView) with hand-drawn backgrounds
    // instead of MaterialButton/MaterialSwitch/PlayerView.
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("androidx.transition:transition:1.5.1")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
