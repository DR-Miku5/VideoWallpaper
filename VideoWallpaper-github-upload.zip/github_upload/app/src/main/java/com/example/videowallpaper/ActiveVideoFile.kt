package com.example.videowallpaper

import android.content.Context
import java.io.File

/**
 * The active video URI, as a plain text file rather than SharedPreferences.
 *
 * SharedPreferencesImpl caches a file's contents in memory per-process and
 * doesn't reliably see writes made from another process. The wallpaper's
 * own ":wallpaper" process can additionally stay alive across multiple
 * WallpaperService.Engine instances -- e.g. across repeated visits to
 * Android's own "set live wallpaper" preview screen -- so even a "fresh"
 * Engine.onCreate() can end up reading that same already-cached, stale
 * SharedPreferences object rather than a truly new one. A plain file has
 * no such cache layer: every read reflects whatever was most recently
 * written, from any process, any time.
 */
object ActiveVideoFile {

    private const val FILE_NAME = "active_video_uri.txt"
    private const val SUMMARY_FILE_NAME = "active_video_summary.txt"
    private const val TYPE_FILE_NAME = "active_media_type.txt"

    const val TYPE_VIDEO = "video"
    const val TYPE_PHOTO = "photo"

    fun write(context: Context, uriString: String) {
        try {
            File(context.filesDir, FILE_NAME).writeText(uriString)
        } catch (e: Exception) {
            // Non-fatal -- worst case the wallpaper falls back to whatever
            // it already has in memory or in SharedPreferences.
        }
    }

    fun read(context: Context): String? {
        return try {
            val file = File(context.filesDir, FILE_NAME)
            if (file.exists()) file.readText().takeIf { it.isNotBlank() } else null
        } catch (e: Exception) {
            null
        }
    }

    fun clear(context: Context) {
        try {
            File(context.filesDir, FILE_NAME).delete()
        } catch (e: Exception) {
            // Non-fatal.
        }
        try {
            File(context.filesDir, TYPE_FILE_NAME).delete()
        } catch (e: Exception) {
            // Non-fatal.
        }
    }

    /** e.g. "1080p · None · 6 Mbps" -- for diagnostic log lines only, not playback. */
    fun writeSummary(context: Context, summary: String) {
        try {
            File(context.filesDir, SUMMARY_FILE_NAME).writeText(summary)
        } catch (e: Exception) {
            // Non-fatal -- logs just fall back to omitting the context.
        }
    }

    fun readSummary(context: Context): String? {
        return try {
            val file = File(context.filesDir, SUMMARY_FILE_NAME)
            if (file.exists()) file.readText().takeIf { it.isNotBlank() } else null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * TYPE_VIDEO or TYPE_PHOTO -- tells VideoWallpaperService's Engine
     * whether to run the existing ExoPlayer pipeline or the static-image
     * rendering path. Written alongside the URI every time the active
     * media changes; missing entirely (an install predating photo
     * support, or the file never existing yet) defaults to video, since
     * every active-media write before this existed was always a video.
     */
    fun writeType(context: Context, type: String) {
        try {
            File(context.filesDir, TYPE_FILE_NAME).writeText(type)
        } catch (e: Exception) {
            // Non-fatal.
        }
    }

    fun readType(context: Context): String {
        return try {
            val file = File(context.filesDir, TYPE_FILE_NAME)
            if (file.exists()) file.readText().trim().ifBlank { TYPE_VIDEO } else TYPE_VIDEO
        } catch (e: Exception) {
            TYPE_VIDEO
        }
    }
}
