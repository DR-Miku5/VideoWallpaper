package com.example.videowallpaper

import android.content.Context
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity

/**
 * Applies the stored font-scale preference (Klein/Standaard/Groot in
 * Stijl) via a Configuration override, wrapping the base Context before
 * the Activity attaches to it. This is the standard Android mechanism for
 * per-app font scaling independent of the system's own accessibility
 * font size setting. Every Activity in the app extends this instead of
 * AppCompatActivity directly so the preference applies everywhere
 * uniformly, in one place.
 */
abstract class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        val fontScale = StylePrefs.getFontScale(newBase)
        val config = Configuration(newBase.resources.configuration)
        config.fontScale = fontScale
        val context = newBase.createConfigurationContext(config)
        super.attachBaseContext(context)
    }
}
