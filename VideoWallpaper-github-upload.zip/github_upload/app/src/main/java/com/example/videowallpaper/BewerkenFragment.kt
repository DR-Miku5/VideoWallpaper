package com.example.videowallpaper

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.preference.PreferenceManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.GaussianBlur
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.min
import kotlin.math.roundToInt

class BewerkenFragment : Fragment() {

    companion object {
        private const val TAG = "BewerkenFragment"
        const val ARG_SOURCE_URI = "source_uri"
        const val ARG_AUTO_APPLY = "auto_apply"
        const val KEY_PENDING_SOURCE_URI = "pending_source_uri"
    }

    private enum class FilterOption { NONE, ENHANCE, GRAYSCALE, SEPIA, BLUR, BRIGHTNESS }
    private data class Chip(val value: String, val label: String)

    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var applyButton: Button
    private lateinit var qualityChipRow: LinearLayout
    private lateinit var filterChipRow: LinearLayout
    private lateinit var bitrateProfileRow: LinearLayout
    private lateinit var bitrateValueText: TextView
    private lateinit var bitrateSeekBar: SeekBar
    private lateinit var trimStartInput: EditText
    private lateinit var trimEndInput: EditText
    private lateinit var estimatedSizeText: TextView
    private lateinit var autoResolutionSwitch: Switch
    private lateinit var frameRateCapSwitch: Switch
    private lateinit var batterySaverSwitch: Switch
    private lateinit var saveToLibrarySwitch: Switch
    private lateinit var batteryImpactText: TextView

    private var detectedScreenHeight: Int = 1080
    private var pendingDurationMs: Long? = null
    private var pendingSourceUri: Uri? = null
    private var transformer: Transformer? = null

    private var selectedQuality: String = BewerkenPrefs.QUALITY_1080
    private var selectedFilter: String = BewerkenPrefs.FILTER_NONE
    private var selectedBitrateProfile: String = BewerkenPrefs.PROFILE_BALANCED

    private val qualityChips by lazy {
        listOf(
            Chip(BewerkenPrefs.QUALITY_480, getString(R.string.quality_chip_480)),
            Chip(BewerkenPrefs.QUALITY_720, getString(R.string.quality_chip_720)),
            Chip(BewerkenPrefs.QUALITY_1080, getString(R.string.quality_chip_1080)),
            Chip(BewerkenPrefs.QUALITY_1440, getString(R.string.quality_chip_1440)),
            Chip(BewerkenPrefs.QUALITY_4K, getString(R.string.quality_chip_4k))
        )
    }
    private val filterChips by lazy {
        listOf(
            Chip(BewerkenPrefs.FILTER_NONE, getString(R.string.filter_chip_none)),
            Chip(BewerkenPrefs.FILTER_ENHANCE, getString(R.string.filter_chip_enhance)),
            Chip(BewerkenPrefs.FILTER_GRAYSCALE, getString(R.string.filter_chip_grayscale)),
            Chip(BewerkenPrefs.FILTER_SEPIA, getString(R.string.filter_chip_sepia)),
            Chip(BewerkenPrefs.FILTER_BLUR, getString(R.string.filter_chip_blur)),
            Chip(BewerkenPrefs.FILTER_BRIGHTNESS, getString(R.string.filter_chip_brightness))
        )
    }
    private val bitrateProfileChips by lazy {
        listOf(
            Chip(BewerkenPrefs.PROFILE_EFFICIENT, getString(R.string.bitrate_profile_efficient)),
            Chip(BewerkenPrefs.PROFILE_BALANCED, getString(R.string.bitrate_profile_balanced)),
            Chip(BewerkenPrefs.PROFILE_HIGH, getString(R.string.bitrate_profile_high)),
            Chip(BewerkenPrefs.PROFILE_CUSTOM, getString(R.string.bitrate_profile_custom))
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_bewerken, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        StylePrefs.applyCustomAccentToViewTree(requireContext(), view)
        StylePrefs.applyTypefaceToViewTree(requireContext(), view)
        StylePrefs.applyBackgroundPattern(requireContext(), view)
        StylePrefs.applyButtonFeedbackStyle(requireContext(), view)

        statusText = view.findViewById(R.id.statusText)
        progressBar = view.findViewById(R.id.progressBar)
        applyButton = view.findViewById(R.id.applyButton)
        StylePrefs.applyCustomAccentToButton(requireContext(), applyButton, 12f)
        qualityChipRow = view.findViewById(R.id.qualityChipRow)
        filterChipRow = view.findViewById(R.id.filterChipRow)
        bitrateProfileRow = view.findViewById(R.id.bitrateProfileRow)
        bitrateValueText = view.findViewById(R.id.bitrateValueText)
        bitrateSeekBar = view.findViewById(R.id.bitrateSeekBar)
        trimStartInput = view.findViewById(R.id.trimStartInput)
        trimEndInput = view.findViewById(R.id.trimEndInput)
        estimatedSizeText = view.findViewById(R.id.estimatedSizeText)
        autoResolutionSwitch = view.findViewById(R.id.autoResolutionSwitch)
        frameRateCapSwitch = view.findViewById(R.id.frameRateCapSwitch)
        batterySaverSwitch = view.findViewById(R.id.batterySaverSwitch)
        saveToLibrarySwitch = view.findViewById(R.id.saveToLibrarySwitch)
        batteryImpactText = view.findViewById(R.id.batteryImpactText)

        detectedScreenHeight = detectScreenHeight()
        loadPersistedSettings()
        renderQualityChips()
        renderFilterChips()
        renderBitrateProfileChips()
        updateBitrateDisplay()

        val sizeEstimateWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                BewerkenPrefs.setTrimStart(requireContext(), trimStartInput.text.toString())
                BewerkenPrefs.setTrimEnd(requireContext(), trimEndInput.text.toString())
                updateEstimatedSize()
            }
        }
        trimStartInput.addTextChangedListener(sizeEstimateWatcher)
        trimEndInput.addTextChangedListener(sizeEstimateWatcher)

        bitrateSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val mbps = 0.5f + progress / 10f
                bitrateValueText.text = getString(R.string.bitrate_value_mbps, formatMbps(mbps))
                BewerkenPrefs.setCustomBitrateMbps(requireContext(), mbps)
                updateEstimatedSize()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        autoResolutionSwitch.setOnCheckedChangeListener { _, checked ->
            BewerkenPrefs.setAutoResolution(requireContext(), checked)
        }
        frameRateCapSwitch.setOnCheckedChangeListener { _, checked ->
            BewerkenPrefs.setFrameRateCap(requireContext(), checked)
        }
        batterySaverSwitch.setOnCheckedChangeListener { _, checked ->
            BewerkenPrefs.setBatterySaver(requireContext(), checked)
        }

        view.findViewById<View>(R.id.previewButton).setOnClickListener { showPreview() }

        applyButton.setOnClickListener {
            val uri = pendingSourceUri
            if (uri == null) {
                Toast.makeText(requireContext(), R.string.no_video_selected, Toast.LENGTH_SHORT).show()
            } else {
                startTranscode(uri)
            }
        }
        view.findViewById<Button>(R.id.resetSettingsButton).setOnClickListener { resetToDefaults() }

        resolveSourceUri()
        updateEstimatedSize()
    }

    private fun loadPersistedSettings() {
        selectedQuality = BewerkenPrefs.getQuality(requireContext())
        selectedFilter = BewerkenPrefs.getFilter(requireContext())
        selectedBitrateProfile = BewerkenPrefs.getBitrateProfile(requireContext())
        trimStartInput.setText(BewerkenPrefs.getTrimStart(requireContext()))
        trimEndInput.setText(BewerkenPrefs.getTrimEnd(requireContext()))
        autoResolutionSwitch.isChecked = BewerkenPrefs.getAutoResolution(requireContext())
        frameRateCapSwitch.isChecked = BewerkenPrefs.getFrameRateCap(requireContext())
        batterySaverSwitch.isChecked = BewerkenPrefs.getBatterySaver(requireContext())
        saveToLibrarySwitch.isChecked = BewerkenPrefs.getSaveToLibrary(requireContext())
        saveToLibrarySwitch.setOnCheckedChangeListener { _, checked ->
            BewerkenPrefs.setSaveToLibrary(requireContext(), checked)
        }
    }

    private fun resetToDefaults() {
        BewerkenPrefs.resetToDefaults(requireContext())
        loadPersistedSettings()
        renderQualityChips()
        renderFilterChips()
        renderBitrateProfileChips()
        updateBitrateDisplay()
        updateEstimatedSize()
        Toast.makeText(requireContext(), R.string.reset_settings_done, Toast.LENGTH_SHORT).show()
    }

    // --- Chip rendering -----------------------------------------------

    private fun renderQualityChips(): Unit = renderChipRow(qualityChipRow, qualityChips, selectedQuality) { value ->
        selectedQuality = value
        BewerkenPrefs.setQuality(requireContext(), value)
        renderQualityChips()
    }

    private fun renderFilterChips(): Unit = renderChipRow(filterChipRow, filterChips, selectedFilter) { value ->
        selectedFilter = value
        BewerkenPrefs.setFilter(requireContext(), value)
        renderFilterChips()
    }

    private fun renderBitrateProfileChips(): Unit = renderChipRow(bitrateProfileRow, bitrateProfileChips, selectedBitrateProfile) { value ->
        selectedBitrateProfile = value
        BewerkenPrefs.setBitrateProfile(requireContext(), value)
        renderBitrateProfileChips()
        updateBitrateDisplay()
        updateEstimatedSize()
    }

    private fun renderChipRow(row: LinearLayout, chips: List<Chip>, selected: String, onPick: (String) -> Unit) {
        row.removeAllViews()
        val marginPx = (6 * resources.displayMetrics.density).toInt()
        val paddingH = (14 * resources.displayMetrics.density).toInt()
        val paddingV = (8 * resources.displayMetrics.density).toInt()

        for (chip in chips) {
            val isSelected = chip.value == selected
            val textView = TextView(requireContext())
            textView.text = chip.label
            textView.textSize = 12f
            textView.setPadding(paddingH, paddingV, paddingH, paddingV)
            textView.setTextColor(if (isSelected) requireContext().getColor(R.color.accent_text) else requireContext().getColor(R.color.nav_inactive_on_dark))
            if (isSelected && StylePrefs.getAccentHue(requireContext()) == StylePrefs.ACCENT_CUSTOM) {
                val drawable = android.graphics.drawable.GradientDrawable()
                drawable.setColor(StylePrefs.getCustomAccentColor(requireContext()))
                drawable.cornerRadius = 14 * resources.displayMetrics.density
                textView.background = drawable
            } else {
                textView.setBackgroundResource(if (isSelected) R.drawable.chip_selected else R.drawable.chip_unselected_glass)
            }
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.marginEnd = marginPx
            textView.layoutParams = params
            textView.setOnClickListener { onPick(chip.value) }
            StylePrefs.applyButtonFeedbackStyle(requireContext(), textView)
            row.addView(textView)
        }
    }

    private fun updateBitrateDisplay() {
        val isCustom = selectedBitrateProfile == BewerkenPrefs.PROFILE_CUSTOM
        bitrateSeekBar.isEnabled = isCustom
        bitrateSeekBar.alpha = if (isCustom) 1f else 0.55f

        val mbps = BewerkenPrefs.mbpsForProfile(requireContext(), selectedBitrateProfile)
        bitrateSeekBar.progress = ((mbps - 0.5f) * 10).roundToInt().coerceIn(0, 495)
        bitrateValueText.text = getString(R.string.bitrate_value_mbps, formatMbps(mbps))
    }

    private fun formatMbps(mbps: Float): String =
        if (mbps == mbps.toInt().toFloat()) mbps.toInt().toString() else "%.1f".format(mbps)

    // --- Source resolution ---------------------------------------------

    private fun resolveSourceUri() {
        val fromArgs = arguments?.getParcelable<Uri>(ARG_SOURCE_URI)
        val prefs = PreferenceManager.getDefaultSharedPreferences(requireContext())

        val uri = fromArgs ?: prefs.getString(KEY_PENDING_SOURCE_URI, null)?.let { Uri.parse(it) }
        if (uri == null) {
            statusText.text = getString(R.string.no_video_selected)
            return
        }

        pendingSourceUri = uri
        prefs.edit().putString(KEY_PENDING_SOURCE_URI, uri.toString()).apply()

        // Reading duration means opening the URI's data source, which for
        // a cloud-backed picker item (OneDrive, Google Drive, Google
        // Photos items not yet cached locally) triggers an on-demand
        // network download right here -- videos are large enough that a
        // slow connection can make this take a genuinely long time.
        // Previously this ran directly on the main thread with no
        // feedback at all: looked identical to a frozen app, and on a
        // slow enough connection could trigger Android's own "app not
        // responding" dialog, since the main thread was blocked the
        // whole time. Now runs on a background thread with the same
        // busy indicator already used for compression, so a slow fetch
        // reads as "loading," not "broken."
        setBusy(true, getString(R.string.loading_video))
        Thread {
            val duration = retrieveDurationMs(uri)
            requireActivity().runOnUiThread {
                if (!isAdded) return@runOnUiThread // fragment may have been destroyed while this was in flight
                pendingDurationMs = duration
                setBusy(false, getString(R.string.video_selected))
                updateEstimatedSize()

                if (fromArgs != null && arguments?.getBoolean(ARG_AUTO_APPLY, false) == true) {
                    startTranscode(uri)
                }
            }
        }.start()
    }

    private fun showPreview() {
        val uri = pendingSourceUri
        if (uri == null) {
            Toast.makeText(requireContext(), R.string.no_video_selected, Toast.LENGTH_SHORT).show()
            return
        }
        val startSec = trimStartInput.text.toString().toLongOrNull() ?: 0L
        val endSec = trimEndInput.text.toString().toLongOrNull()
        PreviewDialog.show(requireActivity(), uri, startSec, endSec)
    }

    // --- Helpers ---------------------------------------------------------

    private fun filterOptionFor(value: String): FilterOption = when (value) {
        BewerkenPrefs.FILTER_ENHANCE -> FilterOption.ENHANCE
        BewerkenPrefs.FILTER_GRAYSCALE -> FilterOption.GRAYSCALE
        BewerkenPrefs.FILTER_SEPIA -> FilterOption.SEPIA
        BewerkenPrefs.FILTER_BLUR -> FilterOption.BLUR
        BewerkenPrefs.FILTER_BRIGHTNESS -> FilterOption.BRIGHTNESS
        else -> FilterOption.NONE
    }

    private fun filterLabel(filter: FilterOption): String = when (filter) {
        FilterOption.NONE -> getString(R.string.filter_chip_none)
        FilterOption.ENHANCE -> getString(R.string.filter_chip_enhance)
        FilterOption.GRAYSCALE -> getString(R.string.filter_chip_grayscale)
        FilterOption.SEPIA -> getString(R.string.filter_chip_sepia)
        FilterOption.BLUR -> getString(R.string.filter_chip_blur)
        FilterOption.BRIGHTNESS -> getString(R.string.filter_chip_brightness)
    }

    private fun qualityCapHeightFor(value: String): Int = when (value) {
        BewerkenPrefs.QUALITY_480 -> 480
        BewerkenPrefs.QUALITY_720 -> 720
        BewerkenPrefs.QUALITY_1440 -> 1440
        BewerkenPrefs.QUALITY_4K -> 2160 // true 4K ceiling, not an unlimited passthrough
        else -> 1080
    }

    private fun detectScreenHeight(): Int {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                requireActivity().windowManager.currentWindowMetrics.bounds.height()
            } else {
                @Suppress("DEPRECATION")
                val metrics = android.util.DisplayMetrics()
                @Suppress("DEPRECATION")
                requireActivity().windowManager.defaultDisplay.getRealMetrics(metrics)
                metrics.heightPixels
            }
        } catch (e: Exception) {
            1080
        }
    }

    private fun retrieveDurationMs(uri: Uri): Long? {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(requireContext(), uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            retriever.release()
            durationStr?.toLongOrNull()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read video duration", e)
            null
        }
    }

    private fun updateEstimatedSize() {
        updateBatteryImpactEstimate()

        val totalDurationSec = pendingDurationMs?.let { it / 1000.0 }
        if (totalDurationSec == null) {
            estimatedSizeText.text = getString(R.string.estimated_size_unknown)
            return
        }
        val startSec = trimStartInput.text.toString().toDoubleOrNull() ?: 0.0
        val endSec = trimEndInput.text.toString().toDoubleOrNull() ?: totalDurationSec
        val effectiveDurationSec = (endSec - startSec).coerceIn(0.0, totalDurationSec)
        val bitrateMbps = BewerkenPrefs.mbpsForProfile(requireContext(), selectedBitrateProfile).toDouble()

        val estimatedMb = (bitrateMbps * effectiveDurationSec / 8.0).roundToInt()
        estimatedSizeText.text = getString(R.string.estimated_size, estimatedMb)
    }

    /**
     * A relative (Laag/Gemiddeld/Hoog), not fabricated-precise, indicator
     * -- computed from resolution and framerate, since those are what
     * actually drive continuous decode cost, not bitrate (bitrate affects
     * file size/detail-per-frame, not how much work the decoder does
     * reconstructing each frame). Weighted by height^2 (roughly
     * proportional to pixel count) since that's the dominant factor;
     * whether the framerate cap is on is a secondary, smaller multiplier,
     * since the source video's actual framerate isn't known at this
     * point without deeper file inspection -- deliberately a directional
     * comparison, not a claim of measuring anything real yet (that's
     * what the Start-screen figure, from actual log data, is for).
     */
    private fun updateBatteryImpactEstimate() {
        val heightPx = qualityCapHeightFor(selectedQuality)
        val resolutionScore = (heightPx * heightPx) / (480.0 * 480.0) // 480p as the low baseline
        val frameScore = if (frameRateCapSwitch.isChecked) 1.0 else 1.5
        val score = resolutionScore * frameScore

        val levelRes = when {
            score <= 3.0 -> R.string.battery_impact_low
            score <= 10.0 -> R.string.battery_impact_medium
            else -> R.string.battery_impact_high
        }
        batteryImpactText.text = getString(R.string.battery_impact_label, getString(levelRes))
    }

    private fun isBatteryLow(): Boolean {
        return try {
            val batteryManager = requireContext().getSystemService(android.content.Context.BATTERY_SERVICE) as BatteryManager
            val level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            level in 0..20
        } catch (e: Exception) {
            false
        }
    }

    private fun computeConfigSignature(
        uri: Uri,
        qualityCap: Int,
        filter: FilterOption,
        startSec: Long,
        endSec: Long?,
        bitrateMbps: Double,
        autoResolution: Boolean,
        frameRateCap: Boolean,
        batterySaver: Boolean
    ): String {
        val raw = listOf(
            uri.toString(), qualityCap, filter.name, startSec, endSec, bitrateMbps,
            autoResolution, frameRateCap, batterySaver
        ).joinToString("|")
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(raw.toByteArray())
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun setBusy(busy: Boolean, statusMessage: String) {
        progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        applyButton.isEnabled = !busy
        statusText.text = statusMessage
    }

    private fun startTranscode(sourceUri: Uri) {
        val startSec = trimStartInput.text.toString().toLongOrNull() ?: 0L
        val endSec = trimEndInput.text.toString().toLongOrNull()
        val manualQualityCap = qualityCapHeightFor(selectedQuality)
        val filter = filterOptionFor(selectedFilter)
        val bitrateMbps = BewerkenPrefs.mbpsForProfile(requireContext(), selectedBitrateProfile).toDouble()
        val autoResolution = autoResolutionSwitch.isChecked
        val frameRateCap = frameRateCapSwitch.isChecked
        val batterySaverEnabled = batterySaverSwitch.isChecked
        val batterySaverActive = batterySaverEnabled && isBatteryLow()

        val configSignature = computeConfigSignature(
            sourceUri, manualQualityCap, filter, startSec, endSec, bitrateMbps,
            autoResolution, frameRateCap, batterySaverEnabled
        )

        // Reusing an already-compressed, already-saved file only makes
        // sense when saving is actually wanted -- if "Opslaan in
        // bibliotheek" is off, silently pointing at an old saved library
        // entry instead of a fresh, genuinely temporary copy would
        // directly contradict what was just chosen, and the toggle would
        // never even get consulted for as long as a matching saved
        // preset already exists.
        val existingMatch = if (BewerkenPrefs.getSaveToLibrary(requireContext())) {
            PresetStore.findByConfigSignature(requireContext(), configSignature)
        } else {
            null
        }

        existingMatch?.let { existing ->
            PresetStore.setActive(requireContext(), existing)
            setBusy(false, getString(R.string.video_selected))
            if (PresetStore.isThisAppTheSystemWallpaper(requireContext())) {
                Toast.makeText(requireContext(), R.string.reused_existing_compression, Toast.LENGTH_SHORT).show()
            } else {
                DiagnosticLog.appendAppEvent(requireContext(), "Stale wallpaper connection detected (Bewerken, reused compression)")
                ReapplyNeededDialog.show(requireActivity())
            }
            goToStart()
            return
        }

        setBusy(true, getString(R.string.compressing))

        val presetId = UUID.randomUUID().toString()
        val output = File(PresetStore.presetsDir(requireContext()), "$presetId.mp4")

        try {
            var mediaItemBuilder = MediaItem.Builder().setUri(sourceUri)

            if (startSec > 0 || endSec != null) {
                val clipping = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startSec * 1000)
                    .apply { if (endSec != null) setEndPositionMs(endSec * 1000) }
                    .build()
                mediaItemBuilder = mediaItemBuilder.setClippingConfiguration(clipping)
            }
            val mediaItem = mediaItemBuilder.build()

            val resolutionCapHeight: Int = when {
                batterySaverActive -> min(720, detectedScreenHeight)
                autoResolution -> detectedScreenHeight
                else -> manualQualityCap
            }

            val effectiveBitrateMbps = if (batterySaverActive) min(bitrateMbps, 3.0) else bitrateMbps

            val videoEffects = mutableListOf<androidx.media3.common.Effect>()
            videoEffects.add(Presentation.createForHeight(resolutionCapHeight))
            if (frameRateCap) {
                videoEffects.add(FrameDropEffect.createDefaultFrameDropEffect(30f))
            }

            when (filter) {
                FilterOption.NONE -> { }
                FilterOption.ENHANCE -> {
                    videoEffects.add(Contrast(0.1f))
                    videoEffects.add(
                        RgbAdjustment.Builder()
                            .setRedScale(1.05f).setGreenScale(1.05f).setBlueScale(1.05f)
                            .build()
                    )
                }
                FilterOption.GRAYSCALE -> {
                    videoEffects.add(RgbFilter.createGrayscaleFilter())
                }
                FilterOption.SEPIA -> {
                    videoEffects.add(
                        RgbAdjustment.Builder()
                            .setRedScale(1.2f).setGreenScale(1.0f).setBlueScale(0.8f)
                            .build()
                    )
                    videoEffects.add(Contrast(0.05f))
                }
                FilterOption.BLUR -> {
                    videoEffects.add(GaussianBlur(6f))
                }
                FilterOption.BRIGHTNESS -> {
                    videoEffects.add(Brightness(0.25f))
                }
            }

            val editedMediaItem = EditedMediaItem.Builder(mediaItem)
                .apply { if (videoEffects.isNotEmpty()) setEffects(Effects(emptyList(), videoEffects)) }
                .build()

            val bitrateBps = (effectiveBitrateMbps.coerceIn(0.5, 50.0) * 1_000_000).toInt()

            val encoderSettings = VideoEncoderSettings.Builder()
                .setBitrate(bitrateBps)
                .build()
            val encoderFactory = DefaultEncoderFactory.Builder(requireContext())
                .setRequestedVideoEncoderSettings(encoderSettings)
                .build()

            val listener = object : Transformer.Listener {
                override fun onCompleted(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult
                ) {
                    val thumbnailPath = generateThumbnail(output, presetId)
                    val summary = buildString {
                        append(if (resolutionCapHeight == 2160) "4K" else "${resolutionCapHeight}p")
                        append(" · ")
                        append(filterLabel(filter))
                        append(" · ")
                        append(formatMbps(effectiveBitrateMbps.toFloat()))
                        append(" Mbps")
                        if (frameRateCap) append(" · 30fps")
                        if (batterySaverActive) append(" · ${getString(R.string.battery_saver_label)}")
                    }
                    val preset = Preset(
                        id = presetId,
                        createdAtMs = System.currentTimeMillis(),
                        videoFilePath = output.absolutePath,
                        thumbnailPath = thumbnailPath,
                        configSignature = configSignature,
                        isFavorite = false,
                        summary = summary
                    )
                    // The compressed file and the active-wallpaper pointer
                    // are needed regardless -- setActive() only needs the
                    // Preset object itself, not a saved library entry, so
                    // "don't save to library" just means skipping add()
                    // while everything needed to actually apply the video
                    // still happens exactly as normal.
                    if (BewerkenPrefs.getSaveToLibrary(requireContext())) {
                        PresetStore.add(requireContext(), preset)
                    }
                    PresetStore.setActive(requireContext(), preset)

                    requireActivity().runOnUiThread {
                        setBusy(false, getString(R.string.video_selected))
                        if (PresetStore.isThisAppTheSystemWallpaper(requireContext())) {
                            val message = if (batterySaverActive) R.string.battery_saver_applied else R.string.video_selected
                            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
                        } else {
                            DiagnosticLog.appendAppEvent(requireContext(), "Stale wallpaper connection detected (Bewerken, new compression)")
                            ReapplyNeededDialog.show(requireActivity())
                        }
                        goToStart()
                    }
                }

                override fun onError(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    output.delete()
                    requireActivity().runOnUiThread {
                        setBusy(false, getString(R.string.no_video_selected))
                        Toast.makeText(requireContext(), R.string.compression_failed, Toast.LENGTH_LONG).show()
                    }
                }
            }

            transformer = Transformer.Builder(requireContext())
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setEncoderFactory(encoderFactory)
                .addListener(listener)
                .build()
                .also { it.start(editedMediaItem, output.absolutePath) }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start transcode", e)
            setBusy(false, getString(R.string.no_video_selected))
            Toast.makeText(requireContext(), R.string.compression_failed, Toast.LENGTH_LONG).show()
        }
    }

    private fun generateThumbnail(videoFile: File, presetId: String): String? {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(videoFile.absolutePath)
            val frame: Bitmap? = retriever.getFrameAtTime(0)
            retriever.release()
            if (frame == null) return null

            val thumbFile = File(PresetStore.presetsDir(requireContext()), "$presetId.jpg")
            FileOutputStream(thumbFile).use { out ->
                frame.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }
            thumbFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Failed to generate thumbnail", e)
            null
        }
    }

    private fun goToStart() {
        (requireActivity() as HostActivity).switchTo(NavTab.START)
    }

    override fun onDestroy() {
        super.onDestroy()
        transformer?.cancel()
        transformer = null
    }
}
