package com.example.videowallpaper

import android.content.Context
import android.preference.PreferenceManager

/**
 * Everything a person configures in Bewerken (quality, filter, trim,
 * bitrate profile/value, performance toggles) is remembered here and
 * reloaded next time the screen opens, instead of always snapping back to
 * defaults.
 */
object BewerkenPrefs {

    private const val KEY_QUALITY = "bewerken_quality"
    private const val KEY_FILTER = "bewerken_filter"
    private const val KEY_TRIM_START = "bewerken_trim_start"
    private const val KEY_TRIM_END = "bewerken_trim_end"
    private const val KEY_BITRATE_PROFILE = "bewerken_bitrate_profile"
    private const val KEY_CUSTOM_BITRATE = "bewerken_custom_bitrate"
    private const val KEY_AUTO_RESOLUTION = "bewerken_auto_resolution"
    private const val KEY_FRAME_RATE_CAP = "bewerken_frame_rate_cap"
    private const val KEY_BATTERY_SAVER = "bewerken_battery_saver"
    private const val KEY_SAVE_TO_LIBRARY = "bewerken_save_to_library"

    const val QUALITY_480 = "480"
    const val QUALITY_720 = "720"
    const val QUALITY_1080 = "1080"
    const val QUALITY_1440 = "1440"
    const val QUALITY_4K = "4k"

    const val FILTER_NONE = "none"
    const val FILTER_ENHANCE = "enhance"
    const val FILTER_GRAYSCALE = "grayscale"
    const val FILTER_SEPIA = "sepia"
    const val FILTER_BLUR = "blur"
    const val FILTER_BRIGHTNESS = "brightness"

    const val PROFILE_EFFICIENT = "efficient"
    const val PROFILE_BALANCED = "balanced"
    const val PROFILE_HIGH = "high"
    const val PROFILE_CUSTOM = "custom"

    private fun prefs(context: Context) = PreferenceManager.getDefaultSharedPreferences(context)

    fun getQuality(context: Context): String = prefs(context).getString(KEY_QUALITY, QUALITY_1080) ?: QUALITY_1080
    fun setQuality(context: Context, value: String) { prefs(context).edit().putString(KEY_QUALITY, value).apply() }

    fun getFilter(context: Context): String = prefs(context).getString(KEY_FILTER, FILTER_NONE) ?: FILTER_NONE
    fun setFilter(context: Context, value: String) { prefs(context).edit().putString(KEY_FILTER, value).apply() }

    fun getTrimStart(context: Context): String = prefs(context).getString(KEY_TRIM_START, "") ?: ""
    fun setTrimStart(context: Context, value: String) { prefs(context).edit().putString(KEY_TRIM_START, value).apply() }

    fun getTrimEnd(context: Context): String = prefs(context).getString(KEY_TRIM_END, "") ?: ""
    fun setTrimEnd(context: Context, value: String) { prefs(context).edit().putString(KEY_TRIM_END, value).apply() }

    fun getBitrateProfile(context: Context): String =
        prefs(context).getString(KEY_BITRATE_PROFILE, PROFILE_BALANCED) ?: PROFILE_BALANCED
    fun setBitrateProfile(context: Context, value: String) {
        prefs(context).edit().putString(KEY_BITRATE_PROFILE, value).apply()
    }

    fun getCustomBitrateMbps(context: Context): Float = prefs(context).getFloat(KEY_CUSTOM_BITRATE, 6.0f)
    fun setCustomBitrateMbps(context: Context, value: Float) {
        prefs(context).edit().putFloat(KEY_CUSTOM_BITRATE, value).apply()
    }

    fun getAutoResolution(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO_RESOLUTION, false)
    fun setAutoResolution(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_RESOLUTION, value).apply()
    }

    fun getFrameRateCap(context: Context): Boolean = prefs(context).getBoolean(KEY_FRAME_RATE_CAP, false)
    fun setFrameRateCap(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_FRAME_RATE_CAP, value).apply()
    }

    fun getBatterySaver(context: Context): Boolean = prefs(context).getBoolean(KEY_BATTERY_SAVER, false)
    fun setBatterySaver(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_BATTERY_SAVER, value).apply()
    }

    /**
     * Whether compressing a video also saves it as a reusable preset in
     * Bibliotheek. Defaults to true, matching the app's behavior before
     * this existed -- someone has to explicitly turn this off for
     * anything to change. Off is meant for a one-off/temporary apply:
     * the compressed file still gets created and still gets applied as
     * the wallpaper (both are required for it to actually work), it
     * just never gets registered as a Preset, so it won't show up in
     * Bibliotheek and won't be found later by the "reuse identical
     * compression" check. This preference itself lives in the same
     * SharedPreferences as everything else Bewerken remembers, so
     * (like all of it) it survives app updates -- only an actual
     * uninstall would clear it, same as every other setting.
     */
    fun getSaveToLibrary(context: Context): Boolean = prefs(context).getBoolean(KEY_SAVE_TO_LIBRARY, true)
    fun setSaveToLibrary(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_SAVE_TO_LIBRARY, value).apply()
    }

    /** Bitrate a given profile resolves to; PROFILE_CUSTOM instead reads the saved slider value. */
    fun mbpsForProfile(context: Context, profile: String): Float = when (profile) {
        PROFILE_EFFICIENT -> 3.0f
        PROFILE_HIGH -> 12.0f
        PROFILE_CUSTOM -> getCustomBitrateMbps(context)
        else -> 6.0f // PROFILE_BALANCED
    }

    fun resetToDefaults(context: Context) {
        setQuality(context, QUALITY_1080)
        setFilter(context, FILTER_NONE)
        setTrimStart(context, "")
        setTrimEnd(context, "")
        setBitrateProfile(context, PROFILE_BALANCED)
        setCustomBitrateMbps(context, 6.0f)
        setAutoResolution(context, false)
        setFrameRateCap(context, false)
        setBatterySaver(context, false)
        setSaveToLibrary(context, true)
    }
}
