package com.example.videowallpaper

import android.app.Activity
import android.widget.TextView

enum class NavTab { START, BEWERKEN, BIBLIOTHEEK, MEER }

/**
 * The bottom nav bar is a single persistent view living in HostActivity's
 * layout (see activity_host.xml) -- it's never recreated when the active
 * tab changes, only the fragment container above it swaps content. That's
 * what keeps the nav bar completely unaffected by the slide transition:
 * it's a sibling of the animating container, not part of it.
 *
 * setup() wires the click handling once; updateActiveTab() re-tints the
 * bar every time HostActivity switches to a different fragment.
 */
object BottomNav {

    fun setup(activity: Activity, onTabSelected: (NavTab) -> Unit) {
        activity.findViewById<android.view.View>(R.id.navStart).setOnClickListener {
            onTabSelected(NavTab.START)
        }
        activity.findViewById<android.view.View>(R.id.navBewerken).setOnClickListener {
            onTabSelected(NavTab.BEWERKEN)
        }
        activity.findViewById<android.view.View>(R.id.navBibliotheek).setOnClickListener {
            onTabSelected(NavTab.BIBLIOTHEEK)
        }
        activity.findViewById<android.view.View>(R.id.navMeer).setOnClickListener {
            onTabSelected(NavTab.MEER)
        }
    }

    fun updateActiveTab(activity: Activity, active: NavTab) {
        val startIcon = activity.findViewById<TextView>(R.id.navStartIcon)
        val bewerkenIcon = activity.findViewById<TextView>(R.id.navBewerkenIcon)
        val bibliotheekIcon = activity.findViewById<TextView>(R.id.navBibliotheekIcon)
        val meerIcon = activity.findViewById<TextView>(R.id.navMeerIcon)

        val activeColor = StylePrefs.resolveAccentColor(activity)
        val inactiveColor = activity.getColor(R.color.nav_inactive_on_dark)

        fun tint(icon: TextView, isActive: Boolean) {
            icon.setTextColor(if (isActive) activeColor else inactiveColor)
        }

        tint(startIcon, active == NavTab.START)
        tint(bewerkenIcon, active == NavTab.BEWERKEN)
        tint(bibliotheekIcon, active == NavTab.BIBLIOTHEEK)
        tint(meerIcon, active == NavTab.MEER)
    }
}
