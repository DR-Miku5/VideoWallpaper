package com.example.videowallpaper

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Diagnostic counters and the rolling event log, stored as plain files
 * instead of SharedPreferences.
 *
 * This data is written from the wallpaper's separate ":wallpaper" process
 * and read from the main app process's Diagnostiek/Meer screens --
 * exactly the same cross-process relationship that caused the active-video
 * bugs fixed in ActiveVideoFile. SharedPreferences' per-process caching
 * isn't reliable across that boundary; plain files have no such cache.
 *
 * Overhauled for the fact that every version tends to add a new kind of
 * event to log (stalls, heap rebuilds, error recoveries, hot-swaps, app-
 * level lifecycle) -- what was a reasonable line cap for one or two event
 * types early on gets crowded out fast once five or six different kinds
 * are all sharing the same rolling window. Two changes address that:
 * a much higher line cap (200, up from 40) so real multi-day patterns
 * survive long enough to actually be visible, and a date in every
 * timestamp (not just the time) since a 200-line log can now legitimately
 * span many days.
 */
object DiagnosticLog {

    private const val LOG_FILE = "diagnostic_log.txt"
    private const val STALL_COUNT_FILE = "diag_stall_count.txt"
    private const val HEAP_COUNT_FILE = "diag_heap_count.txt"
    private const val ERROR_RECOVERY_COUNT_FILE = "diag_error_recovery_count.txt"
    private const val LOOP_COUNT_FILE = "diag_loop_count.txt"
    private const val PROACTIVE_REFRESH_COUNT_FILE = "diag_proactive_refresh_count.txt"
    private const val MAX_LOG_LINES = 200

    private fun timestamp(): String =
        SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

    private fun appendLine(context: Context, line: String) {
        try {
            val file = File(context.filesDir, LOG_FILE)
            val existing = if (file.exists()) file.readText() else ""
            val lines = (existing.split("\n").filter { it.isNotBlank() } + line)
                .takeLast(MAX_LOG_LINES)
            file.writeText(lines.joinToString("\n"))
        } catch (e: Exception) {
            // Non-fatal -- diagnostics losing a line isn't worth crashing over.
        }
    }

    /** [instanceId] tag lets DiagnosticsActivity tell apart "same engine
     *  rebuilding repeatedly" from "a whole new engine instance appeared"
     *  -- e.g. from repeated visits to Android's own live wallpaper
     *  preview screen while the underlying process stayed alive. */
    fun append(context: Context, instanceId: String, message: String) {
        appendLine(context, "${timestamp()}  [$instanceId] $message")
    }

    /**
     * For events that happen in the main app process rather than inside
     * a specific wallpaper Engine instance (app startup, version-change
     * handling, preset changes) -- there's no engine instanceId to tag
     * these with, so they get a flat [APP] tag instead.
     */
    fun appendAppEvent(context: Context, message: String) {
        appendLine(context, "${timestamp()}  [APP] $message")
    }

    /**
     * A visually distinct divider line logged whenever the app version
     * changes, so a long exported log makes it obvious which events
     * happened under which version -- useful for exactly the kind of
     * "did this start after an update" question the battery and post-
     * update investigations both depend on.
     */
    fun appendVersionMarker(context: Context, fromVersion: String, toVersion: String) {
        appendLine(context, "${timestamp()}  ===== updated $fromVersion -> $toVersion =====")
    }

    fun read(context: Context): String {
        return try {
            val file = File(context.filesDir, LOG_FILE)
            if (file.exists()) file.readText() else ""
        } catch (e: Exception) {
            ""
        }
    }

    fun clear(context: Context) {
        try { File(context.filesDir, LOG_FILE).delete() } catch (e: Exception) { }
        try { File(context.filesDir, STALL_COUNT_FILE).delete() } catch (e: Exception) { }
        try { File(context.filesDir, HEAP_COUNT_FILE).delete() } catch (e: Exception) { }
        try { File(context.filesDir, ERROR_RECOVERY_COUNT_FILE).delete() } catch (e: Exception) { }
        try { File(context.filesDir, LOOP_COUNT_FILE).delete() } catch (e: Exception) { }
        try { File(context.filesDir, PROACTIVE_REFRESH_COUNT_FILE).delete() } catch (e: Exception) { }
    }

    fun incrementStallRebuilds(context: Context) = increment(context, STALL_COUNT_FILE)
    fun incrementHeapRebuilds(context: Context) = increment(context, HEAP_COUNT_FILE)
    fun incrementErrorRecoveries(context: Context) = increment(context, ERROR_RECOVERY_COUNT_FILE)
    fun incrementLoopCount(context: Context) = increment(context, LOOP_COUNT_FILE)
    fun incrementProactiveRefreshes(context: Context) = increment(context, PROACTIVE_REFRESH_COUNT_FILE)

    fun stallRebuildCount(context: Context): Int = readCount(context, STALL_COUNT_FILE)
    fun heapRebuildCount(context: Context): Int = readCount(context, HEAP_COUNT_FILE)
    fun errorRecoveryCount(context: Context): Int = readCount(context, ERROR_RECOVERY_COUNT_FILE)
    fun loopCount(context: Context): Int = readCount(context, LOOP_COUNT_FILE)
    fun proactiveRefreshCount(context: Context): Int = readCount(context, PROACTIVE_REFRESH_COUNT_FILE)

    enum class NativeHeapTrend { STABLE, GROWING }
    data class NativeHeapReport(val trend: NativeHeapTrend, val changeMb: Long, val sampleCount: Int)

    /**
     * Compares the average "after release" native heap reading across
     * the most recent batch of releases against the batch before that --
     * every "Player released: native heap XMB -> YMB" line is an equally
     * valid checkpoint regardless of what triggered the release (stall,
     * proactive refresh, etc.), since they all measure the same thing:
     * memory right after a clean rebuild.
     *
     * Deliberately compares averaged batches rather than single readings
     * or a simple oldest-vs-newest comparison -- native heap fluctuates
     * meaningfully more than something like battery drain does, so
     * averaging a batch of several readings smooths out normal noise
     * that a single-point comparison would risk mistaking for a trend.
     * BATCH_SIZE readings needed on each side (so MIN_SAMPLES total)
     * before returning anything at all, and growth has to clear a real
     * threshold (not just any nonzero difference) to be reported --
     * returns null rather than guess when there isn't enough data yet,
     * same honesty rule as the battery drain-rate figure follows.
     */
    fun nativeHeapTrend(context: Context): NativeHeapReport? {
        val pattern = Regex("""Player released: native heap \d+MB -> (\d+)MB""")
        val readings = mutableListOf<Long>()
        for (line in read(context).split("\n")) {
            pattern.find(line)?.let { readings.add(it.groupValues[1].toLong()) }
        }

        val batchSize = 8
        val minSamples = batchSize * 2
        if (readings.size < minSamples) return null

        val recentBatch = readings.takeLast(batchSize)
        val earlierBatch = readings.takeLast(minSamples).take(batchSize)
        val recentAvg = recentBatch.average()
        val earlierAvg = earlierBatch.average()
        val changeMb = (recentAvg - earlierAvg).toLong()

        val growthThresholdMb = 15
        val trend = if (changeMb >= growthThresholdMb) NativeHeapTrend.GROWING else NativeHeapTrend.STABLE
        return NativeHeapReport(trend, changeMb, readings.size)
    }

    /**
     * The most recent thermal reading logged -- every heartbeat/rebuild
     * line already includes "thermal X" (from
     * VideoWallpaperService.thermalStatus()), this just pulls the last
     * one out so it can be shown as its own glanceable stat instead of
     * only existing buried in raw log text.
     */
    fun latestThermalStatus(context: Context): String? {
        val pattern = Regex("""thermal (\w+)""")
        var last: String? = null
        for (line in read(context).split("\n")) {
            pattern.find(line)?.let { last = it.groupValues[1] }
        }
        return last
    }

    data class SinceUpdateStats(val fromVersion: String, val toVersion: String, val stalls: Int, val proactiveRefreshes: Int)

    /**
     * Finds the most recent "===== updated X -> Y =====" marker
     * (appendVersionMarker) and counts stall-rebuild and proactive-
     * refresh events logged after it -- answers "has anything gone
     * wrong since I last updated" directly, rather than only showing
     * lifetime totals that could include issues from versions ago.
     * Returns null if no update marker has ever been logged (e.g. a
     * fresh install that's never been updated since).
     */
    fun statsSinceLastUpdate(context: Context): SinceUpdateStats? {
        val markerPattern = Regex("""=====\s*updated\s+(.+?)\s*->\s*(.+?)\s*=====""")
        val lines = read(context).split("\n")
        var markerIndex = -1
        var fromVersion = ""
        var toVersion = ""
        for (i in lines.indices) {
            markerPattern.find(lines[i])?.let {
                markerIndex = i
                fromVersion = it.groupValues[1]
                toVersion = it.groupValues[2]
            }
        }
        if (markerIndex == -1) return null

        val linesSince = lines.subList(markerIndex + 1, lines.size)
        val stalls = linesSince.count { it.contains("stalled decoder", ignoreCase = true) }
        val proactive = linesSince.count { it.contains("Proactive refresh", ignoreCase = true) }
        return SinceUpdateStats(fromVersion, toVersion, stalls, proactive)
    }

    /** Pulls the percent and charging state out of a "battery 62% (not charging)" fragment, with the line's own timestamp. */
    private val batteryPointPattern = Regex("""^(\d{2}-\d{2} \d{2}:\d{2}:\d{2}).*battery (\d+)% \((charging|not charging)\)""")
    private val logTimestampFormat = java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.getDefault())

    /**
     * Every heartbeat/rebuild/error log line already includes a battery
     * reading -- this turns that scattered data into one concrete number:
     * an estimated %/hour drain rate while the wallpaper was active and
     * the device wasn't charging. Only averages consecutive readings
     * between 1 minute and 3 hours apart (filters out same-instant
     * duplicates and multi-day gaps where the phone was used normally in
     * between) and only where the percentage actually decreased. Returns
     * null if there isn't enough data yet -- deliberately never returns a
     * fabricated placeholder number, since a made-up "estimate" would be
     * actively misleading rather than just unavailable.
     *
     * Known limitation: log timestamps don't include a year, so this
     * would compute nonsense across a year boundary -- acceptable given
     * how recently this app has been in use.
     *
     * Shared between Diagnostiek (where it originated, v4.9.0) and Start
     * (which shows the same real number prominently rather than a
     * separate invented "estimate"), so there's exactly one source of
     * truth for this figure.
     */
    fun estimatedDrainRatePerHour(context: Context): Double? {
        data class Point(val timeMs: Long, val percent: Int, val charging: Boolean)

        val points = mutableListOf<Point>()
        for (line in read(context).split("\n")) {
            val match = batteryPointPattern.find(line) ?: continue
            val (timestamp, percentStr, chargingStr) = match.destructured
            val parsedTime = try {
                logTimestampFormat.parse(timestamp)?.time
            } catch (e: Exception) {
                null
            } ?: continue
            points.add(Point(parsedTime, percentStr.toInt(), chargingStr == "charging"))
        }
        points.sortBy { it.timeMs }

        val hourlyRates = mutableListOf<Double>()
        for (i in 1 until points.size) {
            val prev = points[i - 1]
            val cur = points[i]
            if (prev.charging || cur.charging) continue
            val gapMs = cur.timeMs - prev.timeMs
            val gapHours = gapMs / 3_600_000.0
            if (gapHours < (1.0 / 60.0) || gapHours > 3.0) continue // skip near-instant duplicates and multi-day gaps
            val percentDrop = prev.percent - cur.percent
            if (percentDrop <= 0) continue // only real drain, not a jump from charging or a noisy reading
            hourlyRates.add(percentDrop / gapHours)
        }

        return if (hourlyRates.isEmpty()) null else hourlyRates.average()
    }

    private fun increment(context: Context, fileName: String) {
        try {
            val file = File(context.filesDir, fileName)
            val current = if (file.exists()) file.readText().trim().toIntOrNull() ?: 0 else 0
            file.writeText((current + 1).toString())
        } catch (e: Exception) { }
    }

    private fun readCount(context: Context, fileName: String): Int {
        return try {
            val file = File(context.filesDir, fileName)
            if (file.exists()) file.readText().trim().toIntOrNull() ?: 0 else 0
        } catch (e: Exception) {
            0
        }
    }
}
