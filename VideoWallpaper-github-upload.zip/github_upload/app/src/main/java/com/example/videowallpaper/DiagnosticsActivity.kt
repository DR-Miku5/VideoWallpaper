package com.example.videowallpaper

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File

class DiagnosticsActivity : BaseActivity() {

    private lateinit var deviceInfoText: TextView
    private lateinit var memoryInfoText: TextView
    private lateinit var batteryAnalysisText: TextView
    private lateinit var thermalStatusText: TextView
    private lateinit var nativeHeapTrendText: TextView
    private lateinit var watchdogCountersText: TextView
    private lateinit var watchdogLogList: androidx.recyclerview.widget.RecyclerView
    private lateinit var watchdogLogEmptyText: TextView
    private lateinit var sinceUpdateCard: android.widget.LinearLayout
    private lateinit var sinceUpdateTitleText: TextView
    private lateinit var sinceUpdateDetailText: TextView
    private lateinit var logSearchInput: android.widget.EditText
    private lateinit var filterAllChip: TextView
    private lateinit var filterAppChip: TextView
    private lateinit var filterRebuildsChip: TextView
    private lateinit var filterErrorsChip: TextView
    private val logLineAdapter = LogLineAdapter(emptyList())
    private var allLogLines: List<String> = emptyList()
    private var activeFilter = LogFilter.ALL
    private var searchQuery = ""

    private enum class LogFilter { ALL, APP, REBUILDS, ERRORS }

    /** Matches "MM-dd HH:mm:ss  [TAG] message" -- the normal log line shape. */
    private val logLinePattern = Regex("""^(\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s+\[([^\]]+)]\s+(.*)$""")
    /** Pulls the charging state out of a "battery 62% (not charging)" fragment. */
    private val batteryFragmentPattern = Regex("""battery \d+% \((charging|not charging)\)""")

    override fun onCreate(savedInstanceState: Bundle?) {
        StylePrefs.applyAccentTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnostics)
        StylePrefs.applyCustomAccentToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyTypefaceToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyBackgroundPattern(this, findViewById(android.R.id.content))
        StylePrefs.applyButtonFeedbackStyle(this, findViewById(android.R.id.content))

        deviceInfoText = findViewById(R.id.deviceInfoText)
        memoryInfoText = findViewById(R.id.memoryInfoText)
        batteryAnalysisText = findViewById(R.id.batteryAnalysisText)
        thermalStatusText = findViewById(R.id.thermalStatusText)
        nativeHeapTrendText = findViewById(R.id.nativeHeapTrendText)
        watchdogCountersText = findViewById(R.id.watchdogCountersText)
        watchdogLogList = findViewById(R.id.watchdogLogList)
        watchdogLogEmptyText = findViewById(R.id.watchdogLogEmptyText)
        sinceUpdateCard = findViewById(R.id.sinceUpdateCard)
        sinceUpdateTitleText = findViewById(R.id.sinceUpdateTitleText)
        sinceUpdateDetailText = findViewById(R.id.sinceUpdateDetailText)
        logSearchInput = findViewById(R.id.logSearchInput)
        filterAllChip = findViewById(R.id.filterAllChip)
        filterAppChip = findViewById(R.id.filterAppChip)
        filterRebuildsChip = findViewById(R.id.filterRebuildsChip)
        filterErrorsChip = findViewById(R.id.filterErrorsChip)
        watchdogLogList.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
        watchdogLogList.adapter = logLineAdapter

        logSearchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                searchQuery = s?.toString()?.trim()?.lowercase() ?: ""
                applyLogFilter()
            }
        })

        val filterClickListener = { filter: LogFilter ->
            activeFilter = filter
            applyLogFilter()
        }
        filterAllChip.setOnClickListener { filterClickListener(LogFilter.ALL) }
        filterAppChip.setOnClickListener { filterClickListener(LogFilter.APP) }
        filterRebuildsChip.setOnClickListener { filterClickListener(LogFilter.REBUILDS) }
        filterErrorsChip.setOnClickListener { filterClickListener(LogFilter.ERRORS) }

        findViewById<Button>(R.id.resetDiagnosticsButton).setOnClickListener {
            DiagnosticLog.clear(this)
            refresh()
        }
        findViewById<Button>(R.id.shareDiagnosticsButton).setOnClickListener {
            shareDiagnostics()
        }
        findViewById<Button>(R.id.exportCsvButton).setOnClickListener {
            exportCsv()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        deviceInfoText.text = buildString {
            append(getString(R.string.diagnostics_model, Build.MANUFACTURER, Build.MODEL))
            append("\n")
            append(getString(R.string.diagnostics_android_version, Build.VERSION.RELEASE, Build.VERSION.SDK_INT))
        }

        val runtime = Runtime.getRuntime()
        val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        val maxMb = runtime.maxMemory() / (1024 * 1024)
        val ratio = if (maxMb > 0) (usedMb * 100 / maxMb) else 0
        memoryInfoText.text = getString(R.string.diagnostics_memory_line, usedMb, maxMb, ratio)

        val stallCount = DiagnosticLog.stallRebuildCount(this)
        val heapCount = DiagnosticLog.heapRebuildCount(this)
        val recoveryCount = DiagnosticLog.errorRecoveryCount(this)
        val proactiveCount = DiagnosticLog.proactiveRefreshCount(this)
        watchdogCountersText.text = getString(R.string.diagnostics_watchdog_counters, stallCount, heapCount, recoveryCount, proactiveCount)

        val log = DiagnosticLog.read(this)
        allLogLines = log.split("\n").filter { it.isNotBlank() }.reversed()
        applyLogFilter()

        batteryAnalysisText.text = buildBatteryAnalysis(log)

        val thermal = DiagnosticLog.latestThermalStatus(this)
        thermalStatusText.text = if (thermal != null) getString(R.string.diagnostics_thermal_status, thermal) else ""
        thermalStatusText.visibility = if (thermal != null) android.view.View.VISIBLE else android.view.View.GONE

        val heapTrend = DiagnosticLog.nativeHeapTrend(this)
        nativeHeapTrendText.text = when {
            heapTrend == null -> getString(R.string.diagnostics_native_heap_no_data)
            heapTrend.trend == DiagnosticLog.NativeHeapTrend.GROWING ->
                getString(R.string.diagnostics_native_heap_growing, heapTrend.changeMb, heapTrend.sampleCount)
            else -> getString(R.string.diagnostics_native_heap_stable, heapTrend.sampleCount)
        }

        val sinceUpdate = DiagnosticLog.statsSinceLastUpdate(this)
        if (sinceUpdate != null) {
            sinceUpdateCard.visibility = android.view.View.VISIBLE
            sinceUpdateTitleText.text = getString(R.string.diagnostics_since_update_title, sinceUpdate.fromVersion, sinceUpdate.toVersion)
            sinceUpdateDetailText.text = getString(R.string.diagnostics_since_update_detail, sinceUpdate.stalls, sinceUpdate.proactiveRefreshes)
        } else {
            sinceUpdateCard.visibility = android.view.View.GONE
        }
    }

    /**
     * Applies both the search query and the active category filter
     * together against the full log, then hands the result to the
     * adapter -- allLogLines stays the untouched source of truth
     * (already newest-first) so switching filters or clearing the
     * search never loses anything.
     */
    private fun applyLogFilter() {
        var filtered = allLogLines
        if (searchQuery.isNotEmpty()) {
            filtered = filtered.filter { it.lowercase().contains(searchQuery) }
        }
        filtered = when (activeFilter) {
            LogFilter.ALL -> filtered
            LogFilter.APP -> filtered.filter { it.contains("[APP]") }
            LogFilter.REBUILDS -> filtered.filter { it.contains("Rebuilt player", ignoreCase = true) || it.contains("Proactive refresh", ignoreCase = true) }
            LogFilter.ERRORS -> filtered.filter { it.contains("error", ignoreCase = true) || it.contains("failed", ignoreCase = true) }
        }

        if (filtered.isEmpty()) {
            watchdogLogList.visibility = android.view.View.GONE
            watchdogLogEmptyText.visibility = android.view.View.VISIBLE
        } else {
            watchdogLogList.visibility = android.view.View.VISIBLE
            watchdogLogEmptyText.visibility = android.view.View.GONE
            logLineAdapter.submitLines(filtered)
        }

        updateFilterChipStyles()
    }

    private fun updateFilterChipStyles() {
        val chips = mapOf(
            LogFilter.ALL to filterAllChip,
            LogFilter.APP to filterAppChip,
            LogFilter.REBUILDS to filterRebuildsChip,
            LogFilter.ERRORS to filterErrorsChip
        )
        for ((filter, chip) in chips) {
            val selected = filter == activeFilter
            chip.setBackgroundResource(if (selected) R.drawable.chip_filter_selected else R.drawable.chip_unselected_glass)
            chip.setTextColor(getColor(if (selected) R.color.text_primary else R.color.nav_inactive_on_dark))
        }
    }

    /**
     * Answers the actual open question -- "do rebuilds happen more while
     * unplugged" -- by counting how many rebuild-adjacent log lines
     * mention charging vs. not charging, rather than just dumping the raw
     * counters and leaving the person to eyeball a 200-line log for a
     * pattern themselves.
     */
    private fun buildBatteryAnalysis(log: String): String {
        var notCharging = 0
        var charging = 0
        for (line in log.split("\n")) {
            val match = batteryFragmentPattern.find(line) ?: continue
            if (match.groupValues[1] == "charging") charging++ else notCharging++
        }

        val loopCount = DiagnosticLog.loopCount(this)
        val loopLine = getString(R.string.diagnostics_loop_count, loopCount)
        val drainLine = computeDrainRateLine(log)

        return if (notCharging == 0 && charging == 0) {
            getString(R.string.diagnostics_battery_no_data) + "\n" + loopLine
        } else {
            getString(R.string.diagnostics_battery_correlation, notCharging, charging) + "\n" + drainLine + "\n" + loopLine
        }
    }

    /**
     * Every heartbeat/rebuild/error log line already includes a battery
     * reading -- DiagnosticLog.estimatedDrainRatePerHour() turns that
     * scattered data into one concrete %/hour figure; this just formats
     * it for display.
     */
    private fun computeDrainRateLine(log: String): String {
        val rate = DiagnosticLog.estimatedDrainRatePerHour(this)
        return if (rate == null) {
            getString(R.string.diagnostics_battery_drain_no_data)
        } else {
            getString(R.string.diagnostics_battery_drain_rate, rate)
        }
    }

    /**
     * Builds one plain-text block with everything shown on this screen --
     * device info, memory, counters, and the full rolling log -- and hands
     * it to the system share sheet, so it can go to email, a message,
     * a notes app, or wherever's easiest to paste back for troubleshooting.
     */
    private fun shareDiagnostics() {
        val stallCount = DiagnosticLog.stallRebuildCount(this)
        val heapCount = DiagnosticLog.heapRebuildCount(this)
        val recoveryCount = DiagnosticLog.errorRecoveryCount(this)
        val proactiveCount = DiagnosticLog.proactiveRefreshCount(this)
        val log = DiagnosticLog.read(this)

        val report = buildString {
            appendLine("Video Wallpaper diagnostics -- ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            appendLine()
            appendLine(getString(R.string.diagnostics_model, Build.MANUFACTURER, Build.MODEL))
            appendLine(getString(R.string.diagnostics_android_version, Build.VERSION.RELEASE, Build.VERSION.SDK_INT))
            appendLine()
            appendLine(getString(R.string.diagnostics_watchdog_counters, stallCount, heapCount, recoveryCount, proactiveCount))
            appendLine()
            appendLine(buildBatteryAnalysis(log))
            appendLine()
            appendLine(if (log.isBlank()) getString(R.string.diagnostics_no_events) else log)
        }

        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/plain"
        intent.putExtra(Intent.EXTRA_SUBJECT, "Video Wallpaper diagnostics")
        intent.putExtra(Intent.EXTRA_TEXT, report)
        startActivity(Intent.createChooser(intent, getString(R.string.diagnostics_share)))
    }

    /**
     * Parses the rolling log's "MM-dd HH:mm:ss  [TAG] message" lines into
     * three real columns (date/time, category, message) plus the version-
     * marker divider lines as their own category, and shares it as an
     * actual .csv file (via FileProvider, not just pasted text) so it
     * opens correctly in Excel/Sheets for graphing or filtering.
     */
    private fun exportCsv() {
        val log = DiagnosticLog.read(this)
        if (log.isBlank()) {
            android.widget.Toast.makeText(this, R.string.diagnostics_no_events, android.widget.Toast.LENGTH_SHORT).show()
            return
        }

        val csv = buildString {
            appendLine("Datum/Tijd,Categorie,Bericht")
            for (rawLine in log.split("\n")) {
                val line = rawLine.trim()
                if (line.isEmpty()) continue
                val match = logLinePattern.find(line)
                if (match != null) {
                    val (time, category, message) = match.destructured
                    appendLine("${csvField(time)},${csvField(category)},${csvField(message)}")
                } else {
                    // Version-marker divider lines and anything else that
                    // doesn't match the normal shape -- still exported,
                    // just without a parsed category.
                    appendLine("${csvField("")},${csvField("VERSION")},${csvField(line)}")
                }
            }
        }

        try {
            val exportsDir = File(cacheDir, "diagnostics").apply { mkdirs() }
            val file = File(exportsDir, "video_wallpaper_diagnostics.csv")
            file.writeText(csv)

            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/csv"
            intent.putExtra(Intent.EXTRA_STREAM, uri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, getString(R.string.diagnostics_export_csv)))
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, R.string.diagnostics_export_failed, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    /** Wraps a CSV field in quotes and escapes any quotes/commas it contains. */
    private fun csvField(value: String): String = "\"${value.replace("\"", "\"\"")}\""
}
