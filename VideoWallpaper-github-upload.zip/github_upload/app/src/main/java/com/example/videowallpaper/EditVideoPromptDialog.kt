package com.example.videowallpaper

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window

/**
 * The app's own styled bottom sheet for "edit this video, or apply it
 * straight away?" -- replaces the plain grey default AlertDialog with a
 * sheet that matches the rest of the app (rounded top, accent button).
 */
object EditVideoPromptDialog {

    fun show(activity: Activity, onEdit: () -> Unit, onApplyDefault: () -> Unit) {
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_edit_video_prompt, null)
        dialog.setContentView(view)

        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.45f)
        }

        view.findViewById<android.widget.Button>(R.id.promptEditButton).setOnClickListener {
            dialog.dismiss()
            onEdit()
        }
        view.findViewById<android.widget.Button>(R.id.promptApplyDefaultButton).setOnClickListener {
            dialog.dismiss()
            onApplyDefault()
        }

        dialog.setCancelable(true)
        dialog.show()
    }
}
