package com.example.videowallpaper

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewAnimationUtils
import android.view.animation.PathInterpolator
import androidx.fragment.app.Fragment
import kotlin.math.hypot
import kotlin.math.max

class HostActivity : BaseActivity() {

    private var currentTab: NavTab = NavTab.START
    private val revealDurationMs = 550L

    override fun onCreate(savedInstanceState: Bundle?) {
        StylePrefs.applyAccentTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_host)
        StylePrefs.applyCornerStyleToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyCustomAccentToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyTypefaceToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyButtonFeedbackStyle(this, findViewById(android.R.id.content))

        BottomNav.setup(this) { target -> switchTo(target) }

        if (savedInstanceState == null) {
            val initialTab = when {
                intent.getBooleanExtra(EXTRA_INITIAL_TAB_LIBRARY, false) -> NavTab.BIBLIOTHEEK
                else -> NavTab.START
            }
            currentTab = initialTab
            val initialFragment = fragmentFor(initialTab)
            if (initialTab == NavTab.START && intent.getBooleanExtra("auto_open_picker", false)) {
                val args = Bundle()
                args.putBoolean("auto_open_picker", true)
                initialFragment.arguments = args
            }
            // First-ever fragment: nothing underneath to reveal over, so a
            // plain add with no animation is correct here.
            supportFragmentManager.beginTransaction()
                .add(R.id.fragmentContainer, initialFragment)
                .commit()
        }
        BottomNav.updateActiveTab(this, currentTab)
    }

    private fun fragmentFor(tab: NavTab): Fragment = when (tab) {
        NavTab.START -> StartFragment()
        NavTab.BEWERKEN -> BewerkenFragment()
        NavTab.BIBLIOTHEEK -> LibraryFragment()
        NavTab.MEER -> MoreFragment()
    }

    private fun navIconIdFor(tab: NavTab): Int = when (tab) {
        NavTab.START -> R.id.navStart
        NavTab.BEWERKEN -> R.id.navBewerken
        NavTab.BIBLIOTHEEK -> R.id.navBibliotheek
        NavTab.MEER -> R.id.navMeer
    }

    /** Where in the fragment container's own coordinate space the destination tab's nav icon sits. */
    private fun revealOriginFor(tab: NavTab): Pair<Int, Int> {
        val container = findViewById<View>(R.id.fragmentContainer)
        val navView = findViewById<View>(navIconIdFor(tab))
        val navLoc = IntArray(2)
        navView.getLocationOnScreen(navLoc)
        val containerLoc = IntArray(2)
        container.getLocationOnScreen(containerLoc)
        val x = navLoc[0] - containerLoc[0] + navView.width / 2
        val y = navLoc[1] - containerLoc[1] + navView.height / 2
        return x to y
    }

    /**
     * Swaps the fragment container's content with a circular reveal that
     * expands from the destination tab's own nav icon -- the new screen is
     * full-size and stationary from frame one, just clipped to a growing
     * circle, so it visibly covers the previous screen rather than sliding
     * past it. The nav bar include in activity_host.xml is a sibling of
     * the container, outside this animation entirely, so it never moves.
     *
     * Circular reveal needs both the old and new fragment's views present
     * at once (unlike replace(), which destroys the old view immediately),
     * so this uses add() + a manual reveal Animator, removing the old
     * fragment only after the new one has fully covered it.
     */
    fun switchTo(target: NavTab, sourceUriForBewerken: Uri? = null, autoApply: Boolean = false) {
        if (target == currentTab && sourceUriForBewerken == null) return

        val outgoing = supportFragmentManager.findFragmentById(R.id.fragmentContainer)
        val fragment = fragmentFor(target)
        if (target == NavTab.BEWERKEN && sourceUriForBewerken != null) {
            val args = Bundle()
            args.putParcelable(BewerkenFragment.ARG_SOURCE_URI, sourceUriForBewerken)
            args.putBoolean(BewerkenFragment.ARG_AUTO_APPLY, autoApply)
            fragment.arguments = args
        }

        val (originX, originY) = revealOriginFor(target)

        supportFragmentManager.beginTransaction()
            .add(R.id.fragmentContainer, fragment)
            .runOnCommit {
                val newView = fragment.view ?: return@runOnCommit
                newView.visibility = View.INVISIBLE
                newView.post {
                    val finalRadius = hypot(
                        max(originX, newView.width - originX).toDouble(),
                        max(originY, newView.height - originY).toDouble()
                    ).toFloat()
                    newView.visibility = View.VISIBLE
                    val anim = ViewAnimationUtils.createCircularReveal(
                        newView, originX, originY, 0f, finalRadius
                    )
                    anim.duration = revealDurationMs
                    anim.interpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
                    anim.addListener(object : AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator) {
                            if (outgoing != null && outgoing.isAdded) {
                                supportFragmentManager.beginTransaction()
                                    .remove(outgoing)
                                    .commitAllowingStateLoss()
                            }
                        }
                    })
                    anim.start()
                }
            }
            .commit()

        currentTab = target
        BottomNav.updateActiveTab(this, target)
    }

    companion object {
        const val EXTRA_INITIAL_TAB_LIBRARY = "initial_tab_library"
    }
}
