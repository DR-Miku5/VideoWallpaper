package com.example.videowallpaper

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * Real launcher-icon recoloring on Android requires declaring multiple
 * <activity-alias> entries in the manifest (each with its own icon), all
 * pointing at the real launcher Activity, and toggling which ONE is
 * enabled via PackageManager -- there's no other way to swap a launcher
 * icon's color at runtime. Only the 5 preset accent hues have a pre-baked
 * icon; an arbitrary custom RGB value can't be represented this way, so
 * custom accent mode falls back to the default (blue) icon.
 */
object IconAliasManager {

    private val suffixForHue = mapOf(
        StylePrefs.ACCENT_BLUE to "Blue",
        StylePrefs.ACCENT_PURPLE to "Purple",
        StylePrefs.ACCENT_TEAL to "Teal",
        StylePrefs.ACCENT_CORAL to "Coral",
        StylePrefs.ACCENT_GREEN to "Green"
    )

    fun syncToAccent(context: Context, hue: String) {
        val targetSuffix = suffixForHue[hue] ?: "Blue" // custom (or anything unrecognized) falls back to blue
        val pm = context.packageManager
        for (suffix in suffixForHue.values) {
            val alias = ComponentName(context.packageName, "com.example.videowallpaper.LauncherAlias$suffix")
            val newState = if (suffix == targetSuffix) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            }
            try {
                pm.setComponentEnabledSetting(alias, newState, PackageManager.DONT_KILL_APP)
            } catch (e: Exception) {
                // Non-fatal -- worst case the icon just doesn't update this time.
            }
        }
    }
}
