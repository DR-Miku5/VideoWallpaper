package com.example.videowallpaper

import android.content.res.Resources
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Real version history instead of a single static paragraph -- each
 * version gets its own card with a title and bullet list, newest first.
 * Content lives in string-arrays in strings.xml so every locale can carry
 * its own changelog text.
 */
class InfoActivity : BaseActivity() {

    private data class ChangelogSection(val titleRes: Int, val itemsRes: Int)

    companion object {
        /**
         * The first entry of `sections` below, exposed so Meer's
         * what's-new banner can show the actual latest change instead
         * of a generic message -- this list is the one place that gets
         * updated every release anyway, so there's nothing extra to
         * remember to keep in sync.
         */
        val LATEST_CHANGELOG_ITEMS_RES = R.array.changelog_v5_12_0_items
    }

    private val sections = listOf(
        ChangelogSection(R.string.changelog_v5_12_0_title, R.array.changelog_v5_12_0_items),
        ChangelogSection(R.string.changelog_v5_11_2_title, R.array.changelog_v5_11_2_items),
        ChangelogSection(R.string.changelog_v5_11_1_title, R.array.changelog_v5_11_1_items),
        ChangelogSection(R.string.changelog_v5_11_0_title, R.array.changelog_v5_11_0_items),
        ChangelogSection(R.string.changelog_v5_10_1_title, R.array.changelog_v5_10_1_items),
        ChangelogSection(R.string.changelog_v5_10_0_title, R.array.changelog_v5_10_0_items),
        ChangelogSection(R.string.changelog_v5_9_2_title, R.array.changelog_v5_9_2_items),
        ChangelogSection(R.string.changelog_v5_9_1_title, R.array.changelog_v5_9_1_items),
        ChangelogSection(R.string.changelog_v5_9_0_title, R.array.changelog_v5_9_0_items),
        ChangelogSection(R.string.changelog_v5_8_0_title, R.array.changelog_v5_8_0_items),
        ChangelogSection(R.string.changelog_v5_7_0_title, R.array.changelog_v5_7_0_items),
        ChangelogSection(R.string.changelog_v5_6_1_title, R.array.changelog_v5_6_1_items),
        ChangelogSection(R.string.changelog_v5_6_0_title, R.array.changelog_v5_6_0_items),
        ChangelogSection(R.string.changelog_v5_5_2_title, R.array.changelog_v5_5_2_items),
        ChangelogSection(R.string.changelog_v5_5_1_title, R.array.changelog_v5_5_1_items),
        ChangelogSection(R.string.changelog_v5_5_0_title, R.array.changelog_v5_5_0_items),
        ChangelogSection(R.string.changelog_v5_4_2_title, R.array.changelog_v5_4_2_items),
        ChangelogSection(R.string.changelog_v5_4_1_title, R.array.changelog_v5_4_1_items),
        ChangelogSection(R.string.changelog_v5_4_0_title, R.array.changelog_v5_4_0_items),
        ChangelogSection(R.string.changelog_v5_3_0_title, R.array.changelog_v5_3_0_items),
        ChangelogSection(R.string.changelog_v5_2_1_title, R.array.changelog_v5_2_1_items),
        ChangelogSection(R.string.changelog_v5_2_0_title, R.array.changelog_v5_2_0_items),
        ChangelogSection(R.string.changelog_v5_1_9_title, R.array.changelog_v5_1_9_items),
        ChangelogSection(R.string.changelog_v5_1_8_title, R.array.changelog_v5_1_8_items),
        ChangelogSection(R.string.changelog_v5_1_7_title, R.array.changelog_v5_1_7_items),
        ChangelogSection(R.string.changelog_v5_1_6_title, R.array.changelog_v5_1_6_items),
        ChangelogSection(R.string.changelog_v5_1_5_title, R.array.changelog_v5_1_5_items),
        ChangelogSection(R.string.changelog_v5_1_4_title, R.array.changelog_v5_1_4_items),
        ChangelogSection(R.string.changelog_v5_1_3_title, R.array.changelog_v5_1_3_items),
        ChangelogSection(R.string.changelog_v5_1_2_title, R.array.changelog_v5_1_2_items),
        ChangelogSection(R.string.changelog_v5_1_1_title, R.array.changelog_v5_1_1_items),
        ChangelogSection(R.string.changelog_v5_1_0_title, R.array.changelog_v5_1_0_items),
        ChangelogSection(R.string.changelog_v5_0_0_title, R.array.changelog_v5_0_0_items),
        ChangelogSection(R.string.changelog_v4_9_3_title, R.array.changelog_v4_9_3_items),
        ChangelogSection(R.string.changelog_v4_9_2_title, R.array.changelog_v4_9_2_items),
        ChangelogSection(R.string.changelog_v4_9_1_title, R.array.changelog_v4_9_1_items),
        ChangelogSection(R.string.changelog_v4_9_0_title, R.array.changelog_v4_9_0_items),
        ChangelogSection(R.string.changelog_v4_8_1_title, R.array.changelog_v4_8_1_items),
        ChangelogSection(R.string.changelog_v4_8_0_title, R.array.changelog_v4_8_0_items),
        ChangelogSection(R.string.changelog_v4_7_0_title, R.array.changelog_v4_7_0_items),
        ChangelogSection(R.string.changelog_v4_6_0_title, R.array.changelog_v4_6_0_items),
        ChangelogSection(R.string.changelog_v4_5_0_title, R.array.changelog_v4_5_0_items),
        ChangelogSection(R.string.changelog_v4_4_0_title, R.array.changelog_v4_4_0_items),
        ChangelogSection(R.string.changelog_v4_3_0_title, R.array.changelog_v4_3_0_items),
        ChangelogSection(R.string.changelog_v4_2_0_title, R.array.changelog_v4_2_0_items),
        ChangelogSection(R.string.changelog_v4_1_0_title, R.array.changelog_v4_1_0_items),
        ChangelogSection(R.string.changelog_v4_0_1_title, R.array.changelog_v4_0_1_items),
        ChangelogSection(R.string.changelog_v4_0_0_title, R.array.changelog_v4_0_0_items),
        ChangelogSection(R.string.changelog_v3_9_0_title, R.array.changelog_v3_9_0_items),
        ChangelogSection(R.string.changelog_v3_8_1_title, R.array.changelog_v3_8_1_items),
        ChangelogSection(R.string.changelog_v3_8_0_title, R.array.changelog_v3_8_0_items),
        ChangelogSection(R.string.changelog_v3_7_1_title, R.array.changelog_v3_7_1_items),
        ChangelogSection(R.string.changelog_v3_7_0_title, R.array.changelog_v3_7_0_items),
        ChangelogSection(R.string.changelog_v3_6_8_title, R.array.changelog_v3_6_8_items),
        ChangelogSection(R.string.changelog_v3_6_7_title, R.array.changelog_v3_6_7_items),
        ChangelogSection(R.string.changelog_v3_6_6_title, R.array.changelog_v3_6_6_items),
        ChangelogSection(R.string.changelog_v3_6_5_title, R.array.changelog_v3_6_5_items),
        ChangelogSection(R.string.changelog_v3_6_4_title, R.array.changelog_v3_6_4_items),
        ChangelogSection(R.string.changelog_v3_6_3_title, R.array.changelog_v3_6_3_items),
        ChangelogSection(R.string.changelog_v3_6_2_title, R.array.changelog_v3_6_2_items),
        ChangelogSection(R.string.changelog_v3_6_1_title, R.array.changelog_v3_6_1_items),
        ChangelogSection(R.string.changelog_v3_6_0_title, R.array.changelog_v3_6_0_items),
        ChangelogSection(R.string.changelog_v3_5_39_title, R.array.changelog_v3_5_39_items),
        ChangelogSection(R.string.changelog_v3_5_38_title, R.array.changelog_v3_5_38_items),
        ChangelogSection(R.string.changelog_v3_5_37_title, R.array.changelog_v3_5_37_items),
        ChangelogSection(R.string.changelog_v3_5_36_title, R.array.changelog_v3_5_36_items),
        ChangelogSection(R.string.changelog_v3_5_35_title, R.array.changelog_v3_5_35_items),
        ChangelogSection(R.string.changelog_v3_5_34_title, R.array.changelog_v3_5_34_items),
        ChangelogSection(R.string.changelog_v3_5_33_title, R.array.changelog_v3_5_33_items),
        ChangelogSection(R.string.changelog_v3_5_32_title, R.array.changelog_v3_5_32_items),
        ChangelogSection(R.string.changelog_v3_5_31_title, R.array.changelog_v3_5_31_items),
        ChangelogSection(R.string.changelog_v3_5_30_title, R.array.changelog_v3_5_30_items),
        ChangelogSection(R.string.changelog_v3_5_29_title, R.array.changelog_v3_5_29_items),
        ChangelogSection(R.string.changelog_v3_5_28_title, R.array.changelog_v3_5_28_items),
        ChangelogSection(R.string.changelog_v3_5_27_title, R.array.changelog_v3_5_27_items),
        ChangelogSection(R.string.changelog_earlier_title, R.array.changelog_earlier_items)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        StylePrefs.applyAccentTheme(this)
        super.onCreate(savedInstanceState)

        val dp = { v: Int -> (v * resources.displayMetrics.density).toInt() }

        val scrollView = ScrollView(this)
        scrollView.fitsSystemWindows = true
        scrollView.setBackgroundColor(StylePrefs.resolveBackgroundColor(this))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(20), dp(20), dp(20))
        scrollView.addView(root)

        val header = TextView(this)
        header.text = getString(R.string.changelog_title)
        header.setTextColor(getColor(R.color.text_primary))
        header.textSize = 20f
        header.setTypeface(header.typeface, Typeface.BOLD)
        header.setPadding(0, 0, 0, dp(16))
        root.addView(header)

        val formatsCard = LinearLayout(this)
        formatsCard.orientation = LinearLayout.VERTICAL
        formatsCard.setBackgroundResource(R.drawable.card_background)
        formatsCard.setPadding(dp(16), dp(16), dp(16), dp(16))
        val formatsParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        formatsParams.bottomMargin = dp(16)
        formatsCard.layoutParams = formatsParams

        val formatsTitle = TextView(this)
        formatsTitle.text = getString(R.string.supported_formats_title)
        formatsTitle.setTextColor(StylePrefs.resolveAccentColor(this))
        formatsTitle.setTypeface(formatsTitle.typeface, Typeface.BOLD)
        formatsTitle.textSize = 14f
        formatsTitle.setPadding(0, 0, 0, dp(6))
        formatsCard.addView(formatsTitle)

        val formatsBody = TextView(this)
        formatsBody.text = getString(R.string.supported_formats)
        formatsBody.setTextColor(getColor(R.color.text_secondary))
        formatsBody.textSize = 14f
        formatsCard.addView(formatsBody)

        root.addView(formatsCard)

        for (section in sections) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundResource(R.drawable.card_background)
            card.setPadding(dp(16), dp(16), dp(16), dp(16))
            val cardParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            cardParams.bottomMargin = dp(16)
            card.layoutParams = cardParams

            val title = TextView(this)
            title.text = getString(section.titleRes)
            title.setTextColor(StylePrefs.resolveAccentColor(this))
            title.setTypeface(title.typeface, Typeface.BOLD)
            title.textSize = 14f
            title.setPadding(0, 0, 0, dp(8))
            card.addView(title)

            val items: Array<String> = resources.getStringArray(section.itemsRes)
            for (item in items) {
                val row = TextView(this)
                row.text = "\u2022  $item"
                row.setTextColor(getColor(R.color.text_secondary))
                row.textSize = 14f
                row.setPadding(0, dp(4), 0, dp(4))
                card.addView(row)
            }

            root.addView(card)
        }

        setContentView(scrollView)
    }
}
