package com.example.videowallpaper

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.DateFormat
import java.util.Date

/**
 * Bibliotheek's gallery grid -- see PresetGridAdapter.kt for the card
 * binding and PresetActionsDialog.kt for the tap-to-act sheet. All the
 * search/sort/favorites-filter logic here is unchanged from the previous
 * list-based version; only how results get *displayed* changed, from
 * manually inflating LinearLayout rows to feeding a RecyclerView adapter.
 */
class LibraryFragment : Fragment() {

    private enum class SortMode { NEWEST, LARGEST, FAVORITES_FIRST }

    private lateinit var presetGrid: RecyclerView
    private lateinit var emptyStateContainer: android.widget.LinearLayout
    private lateinit var emptyStateText: TextView
    private lateinit var favoritesOnlySwitch: android.widget.Switch
    private lateinit var searchInput: EditText
    private lateinit var sortRadioGroup: RadioGroup
    private lateinit var adapter: PresetGridAdapter
    private var showFavoritesOnly = false
    private var searchQuery = ""
    private var sortMode = SortMode.NEWEST

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_library, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        presetGrid = view.findViewById(R.id.presetGrid)
        emptyStateContainer = view.findViewById(R.id.emptyStateContainer)
        emptyStateText = view.findViewById(R.id.emptyStateText)
        favoritesOnlySwitch = view.findViewById(R.id.favoritesOnlySwitch)
        searchInput = view.findViewById(R.id.searchInput)
        sortRadioGroup = view.findViewById(R.id.sortRadioGroup)

        adapter = PresetGridAdapter(
            presets = emptyList(),
            activeId = null,
            onUse = { preset ->
                PresetStore.setActive(requireContext(), preset)
                if (PresetStore.isThisAppTheSystemWallpaper(requireContext())) {
                    android.widget.Toast.makeText(requireContext(), R.string.preset_now_active, android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    DiagnosticLog.appendAppEvent(requireContext(), "Stale wallpaper connection detected (Bibliotheek use)")
                    ReapplyNeededDialog.show(requireActivity())
                }
                refresh()
            },
            onRename = { preset -> showRenameDialog(preset) },
            onDelete = { preset ->
                PresetStore.delete(requireContext(), preset.id)
                refresh()
            },
            onToggleFavorite = { preset ->
                PresetStore.toggleFavorite(requireContext(), preset.id)
                refresh()
            }
        )
        presetGrid.layoutManager = GridLayoutManager(requireContext(), 2)
        presetGrid.adapter = adapter

        favoritesOnlySwitch.setOnCheckedChangeListener { _, checked ->
            showFavoritesOnly = checked
            refresh()
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                searchQuery = s?.toString()?.trim()?.lowercase() ?: ""
                refresh()
            }
        })

        sortRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            sortMode = when (checkedId) {
                R.id.sortLargest -> SortMode.LARGEST
                R.id.sortFavoritesFirst -> SortMode.FAVORITES_FIRST
                else -> SortMode.NEWEST
            }
            refresh()
        }

        StylePrefs.applyCustomAccentToViewTree(requireContext(), view)
        StylePrefs.applyTypefaceToViewTree(requireContext(), view)
        StylePrefs.applyBackgroundPattern(requireContext(), view)
        StylePrefs.applyButtonFeedbackStyle(requireContext(), view)
    }

    override fun onResume() {
        super.onResume()
        refresh() // presets can change while this screen isn't visible
    }

    private fun displayName(preset: Preset, dateFormat: DateFormat): String =
        preset.customName ?: dateFormat.format(Date(preset.createdAtMs))

    private fun refresh() {
        val activeId = PresetStore.activePreset(requireContext())?.id
        var presets = PresetStore.loadAll(requireContext())

        if (showFavoritesOnly) presets = presets.filter { it.isFavorite }

        val dateFormat = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        if (searchQuery.isNotEmpty()) {
            presets = presets.filter {
                displayName(it, dateFormat).lowercase().contains(searchQuery) ||
                    it.summary.lowercase().contains(searchQuery)
            }
        }

        presets = when (sortMode) {
            SortMode.NEWEST -> presets.sortedByDescending { it.createdAtMs }
            SortMode.LARGEST -> presets.sortedByDescending { File(it.videoFilePath).let { f -> if (f.exists()) f.length() else 0L } }
            SortMode.FAVORITES_FIRST -> presets.sortedWith(compareByDescending<Preset> { it.isFavorite }.thenByDescending { it.createdAtMs })
        }

        if (presets.isEmpty()) {
            presetGrid.visibility = View.GONE
            emptyStateContainer.visibility = View.VISIBLE
            emptyStateText.text = if (searchQuery.isNotEmpty()) getString(R.string.library_empty_search) else getString(R.string.library_empty)
            return
        }

        presetGrid.visibility = View.VISIBLE
        emptyStateContainer.visibility = View.GONE
        adapter.submit(presets, activeId)
    }

    private fun showRenameDialog(preset: Preset) {
        val input = EditText(requireContext())
        input.setText(preset.customName ?: "")
        input.hint = getString(R.string.rename_hint)

        AlertDialog.Builder(requireContext())
            .setTitle(R.string.rename_title)
            .setView(input)
            .setPositiveButton(R.string.rename_save) { _, _ ->
                PresetStore.rename(requireContext(), preset.id, input.text.toString())
                refresh()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
