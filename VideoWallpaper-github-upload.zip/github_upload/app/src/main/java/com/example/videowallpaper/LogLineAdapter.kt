package com.example.videowallpaper

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Feeds the diagnostic log to Diagnostiek's log list one line per row,
 * instead of one giant TextView holding the entire (up to 200-line) log
 * as a single growing block. Shown newest-first (the log file itself
 * stays oldest-first, for CSV export and chronological reading) --
 * whoever's checking this cares about the most recent events, not
 * scrolling all the way down through old history to find them.
 */
class LogLineAdapter(private var lines: List<String>) : RecyclerView.Adapter<LogLineAdapter.ViewHolder>() {

    class ViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView)

    fun submitLines(newLines: List<String>) {
        lines = newLines
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_log_line, parent, false) as TextView
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textView.text = lines[position]
        holder.textView.setOnLongClickListener {
            val clipboard = holder.textView.context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("log line", lines[position]))
            android.widget.Toast.makeText(holder.textView.context, R.string.diagnostics_log_line_copied, android.widget.Toast.LENGTH_SHORT).show()
            true
        }
    }

    override fun getItemCount(): Int = lines.size
}
