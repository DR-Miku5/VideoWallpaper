package com.example.videowallpaper

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

/**
 * Meer: the things you *do* (Stijl, Slideshow, Diagnostiek) plus a link
 * into Instellingen for the things you set once and rarely touch again
 * (language, theme, status, version history, battery exemption).
 */
class MoreFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_more, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        StylePrefs.applyCustomAccentToViewTree(requireContext(), view)
        StylePrefs.applyTypefaceToViewTree(requireContext(), view)
        StylePrefs.applyBackgroundPattern(requireContext(), view)
        StylePrefs.applyButtonFeedbackStyle(requireContext(), view)

        view.findViewById<TextView>(R.id.greetingText).text = greetingForCurrentTime()

        val stallCount = DiagnosticLog.stallRebuildCount(requireContext())
        view.findViewById<TextView>(R.id.healthMoodText).text = if (stallCount == 0) "☀️" else "⚠️"
        view.findViewById<TextView>(R.id.healthSummaryText).text = if (stallCount == 0) {
            getString(R.string.more_health_good)
        } else {
            getString(R.string.more_health_issues, stallCount)
        }
        val drainRate = DiagnosticLog.estimatedDrainRatePerHour(requireContext())
        view.findViewById<TextView>(R.id.healthDetailText).text = if (drainRate == null) {
            getString(R.string.more_health_detail_no_data)
        } else {
            getString(R.string.more_health_detail, getString(R.string.diagnostics_battery_drain_rate, drainRate))
        }

        val totalBytes = PresetStore.loadAll(requireContext()).sumOf {
            val f = java.io.File(it.videoFilePath)
            if (f.exists()) f.length() else 0L
        }
        view.findViewById<TextView>(R.id.storageStatText).text =
            getString(R.string.more_storage_stat, (totalBytes / (1024 * 1024)).toInt())

        val latestChangeItems = resources.getStringArray(InfoActivity.LATEST_CHANGELOG_ITEMS_RES)
        view.findViewById<TextView>(R.id.whatsNewText).text = if (latestChangeItems.isNotEmpty()) {
            "✨ ${latestChangeItems.first()}"
        } else {
            getString(R.string.more_whats_new, BuildConfig.VERSION_NAME)
        }
        view.findViewById<View>(R.id.whatsNewBanner).setOnClickListener {
            startActivity(Intent(requireContext(), InfoActivity::class.java))
            TransitionHelper.applyForward(requireActivity())
        }

        val accentColor = StylePrefs.resolveAccentColor(requireContext())
        (view.findViewById<View>(R.id.styleAccentSwatch).background.mutate() as android.graphics.drawable.GradientDrawable)
            .setColor(accentColor)

        val pulseGranted = androidx.core.app.NotificationManagerCompat
            .getEnabledListenerPackages(requireContext())
            .contains(requireContext().packageName)
        val pulseText = view.findViewById<TextView>(R.id.pulseStatusText)
        if (pulseGranted) {
            pulseText.text = getString(R.string.more_pulse_active)
            pulseText.setTextColor(requireContext().getColor(android.R.color.holo_green_light))
        } else {
            pulseText.text = getString(R.string.more_pulse_inactive)
            pulseText.setTextColor(requireContext().getColor(R.color.nav_inactive_on_dark))
        }

        view.findViewById<View>(R.id.styleRow).setOnClickListener {
            startActivity(Intent(requireContext(), StyleActivity::class.java))
            TransitionHelper.applyForward(requireActivity())
        }
        view.findViewById<View>(R.id.slideshowRow).setOnClickListener {
            startActivity(Intent(requireContext(), SlideshowActivity::class.java))
            TransitionHelper.applyForward(requireActivity())
        }
        view.findViewById<View>(R.id.diagnosticsRow).setOnClickListener {
            startActivity(Intent(requireContext(), DiagnosticsActivity::class.java))
            TransitionHelper.applyForward(requireActivity())
        }
        view.findViewById<View>(R.id.settingsRow).setOnClickListener {
            startActivity(Intent(requireContext(), SettingsActivity::class.java))
            TransitionHelper.applyForward(requireActivity())
        }

        view.findViewById<TextView>(R.id.versionFooterText).text =
            getString(R.string.app_version_footer, BuildConfig.VERSION_NAME)
    }

    /** A simple time-of-day greeting -- no new tracking needed, just the device's current clock. */
    private fun greetingForCurrentTime(): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when {
            hour < 12 -> getString(R.string.more_greeting_morning)
            hour < 18 -> getString(R.string.more_greeting_afternoon)
            else -> getString(R.string.more_greeting_evening)
        }
    }
}
