package com.example.videowallpaper

import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Requires the person to manually grant "Notification access" in system
 * settings -- Android doesn't allow this permission to be requested via a
 * normal runtime dialog, only through Settings.ACTION_NOTIFICATION_
 * LISTENER_SETTINGS. Runs in the main app process; the wallpaper itself
 * lives in a separate ":wallpaper" process, so this talks to it via the
 * same cross-process broadcast pattern used for active-video changes.
 */
class NotificationPulseListenerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!PulsePrefs.isNotificationPulseEnabled(this)) return
        val broadcast = Intent(VideoWallpaperService.ACTION_PULSE)
        broadcast.setPackage(packageName)
        sendBroadcast(broadcast)
    }
}
