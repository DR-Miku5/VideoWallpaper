package com.example.videowallpaper

import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

class OnboardingActivity : BaseActivity() {

    companion object {
        private const val KEY_ONBOARDING_COMPLETE = "onboarding_complete"
    }

    private data class Page(val emoji: String, val titleRes: Int, val descRes: Int)

    private val pages = listOf(
        Page("🎬", R.string.onboarding_title_1, R.string.onboarding_desc_1),
        Page("⚡", R.string.onboarding_title_2, R.string.onboarding_desc_2),
        Page("📚", R.string.onboarding_title_3, R.string.onboarding_desc_3)
    )

    private var currentPage = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        StylePrefs.applyAccentTheme(this)
        super.onCreate(savedInstanceState)

        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        if (prefs.getBoolean(KEY_ONBOARDING_COMPLETE, false)) {
            // Already seen it -- pass straight through, no UI ever inflates.
            goToHost()
            return
        }

        setContentView(R.layout.activity_onboarding)
        StylePrefs.applyCustomAccentToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyTypefaceToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyBackgroundPattern(this, findViewById(android.R.id.content))
        StylePrefs.applyButtonFeedbackStyle(this, findViewById(android.R.id.content))
        renderPage()

        findViewById<android.view.View>(R.id.skipText).setOnClickListener { finishOnboarding() }
        findViewById<android.view.View>(R.id.nextButton).setOnClickListener {
            if (currentPage < pages.size - 1) {
                currentPage++
                renderPage()
            } else {
                finishOnboarding()
            }
        }
    }

    private fun renderPage() {
        val page = pages[currentPage]
        findViewById<android.widget.TextView>(R.id.onboardingIcon).text = page.emoji
        findViewById<android.widget.TextView>(R.id.onboardingTitle).text = getString(page.titleRes)
        findViewById<android.widget.TextView>(R.id.onboardingDescription).text = getString(page.descRes)
        findViewById<android.widget.Button>(R.id.nextButton).text =
            if (currentPage == pages.size - 1) getString(R.string.onboarding_get_started) else getString(R.string.onboarding_next)

        val dotsContainer = findViewById<android.widget.LinearLayout>(R.id.dotsContainer)
        dotsContainer.removeAllViews()
        val dp = (6 * resources.displayMetrics.density).toInt()
        for (i in pages.indices) {
            val dot = android.view.View(this)
            val size = if (i == currentPage) dp * 2 else dp
            val params = android.widget.LinearLayout.LayoutParams(size, size)
            params.marginStart = dp / 2
            params.marginEnd = dp / 2
            dot.layoutParams = params
            dot.setBackgroundColor(if (i == currentPage) StylePrefs.resolveAccentColor(this) else getColor(R.color.divider))
            dotsContainer.addView(dot)
        }
    }

    private fun finishOnboarding() {
        PreferenceManager.getDefaultSharedPreferences(this)
            .edit()
            .putBoolean(KEY_ONBOARDING_COMPLETE, true)
            .apply()
        goToHost()
    }

    private fun goToHost() {
        startActivity(Intent(this, HostActivity::class.java))
        TransitionHelper.applyForward(this)
        finish()
    }
}
