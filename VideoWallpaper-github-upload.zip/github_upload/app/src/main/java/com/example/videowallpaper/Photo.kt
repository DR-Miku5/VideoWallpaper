package com.example.videowallpaper

import org.json.JSONObject

/**
 * One added photo for Slideshow rotation -- much simpler than Preset since
 * photos don't need transcoding/bitrate/config-signature; the picked image
 * is just downsampled to a sane max dimension (to avoid the same kind of
 * memory pressure a huge 4K video caused) and stored as-is.
 */
data class Photo(
    val id: String,
    val createdAtMs: Long,
    val filePath: String,
    var isFavorite: Boolean,
    var customName: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("createdAtMs", createdAtMs)
        put("filePath", filePath)
        put("isFavorite", isFavorite)
        put("customName", customName ?: "")
    }

    companion object {
        fun fromJson(json: JSONObject): Photo = Photo(
            id = json.getString("id"),
            createdAtMs = json.getLong("createdAtMs"),
            filePath = json.getString("filePath"),
            isFavorite = json.optBoolean("isFavorite", false),
            customName = json.optString("customName", "").ifEmpty { null }
        )
    }
}
