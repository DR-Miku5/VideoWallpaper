package com.example.videowallpaper

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.preference.PreferenceManager
import android.util.Log
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream

/**
 * Photos are stored the same way Presets are (a small JSON array in
 * SharedPreferences, actual files in their own filesDir subfolder) but
 * need none of Preset's transcoding/bitrate/config-signature machinery --
 * a picked image just gets downsampled to a sane max dimension (the same
 * kind of precaution the video pipeline needed after the original 4K OOM
 * crash) and saved as-is.
 */
object PhotoStore {

    private const val TAG = "PhotoStore"
    private const val KEY_PHOTOS = "photos_json"
    const val KEY_ACTIVE_PHOTO_ID = "active_photo_id"

    /** Matches the video pipeline's 4K cap -- a photo doesn't need to be sharper than that to fill any current screen. */
    private const val MAX_DIMENSION_PX = 2160

    fun photosDir(context: Context): File =
        File(context.filesDir, "photos").apply { mkdirs() }

    fun loadAll(context: Context): List<Photo> {
        val raw = PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_PHOTOS, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { Photo.fromJson(array.getJSONObject(it)) }
                .sortedByDescending { it.createdAtMs }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveAll(context: Context, photos: List<Photo>) {
        val array = JSONArray()
        photos.forEach { array.put(it.toJson()) }
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_PHOTOS, array.toString())
            .apply()
    }

    /**
     * Some content providers -- Google Photos' cloud-backed provider is
     * the common case -- expose certain items as "virtual documents"
     * that openInputStream() legitimately returns null for by design
     * (typically items not fully cached locally, or that need explicit
     * MIME-type negotiation to export). openTypedAssetFileDescriptor()
     * with an explicit type is the documented way to still read bytes
     * from those. Tries the simple path first since it's cheaper for the
     * common case (a local file), and only falls back when that returns
     * null rather than throwing (a thrown exception means something more
     * fundamentally wrong -- permission revoked, URI invalid -- that a
     * different open method won't fix either).
     *
     * The fallback itself tries the URI's *actual* reported MIME type
     * before a wildcard -- some providers strictly validate the
     * requested type against what they can serve and refuse a wildcard
     * even when they'd happily serve the exact type, which is what
     * caused a real failure on a plain image/jpeg file (not some obscure
     * format) despite this fallback already existing. The real exception
     * from the fallback is now also captured and logged, instead of
     * being silently swallowed -- a failure with no reason attached
     * isn't actually diagnosable if it happens again.
     */
    private fun openImageStream(context: Context, uri: Uri): Pair<java.io.InputStream?, String?> {
        context.contentResolver.openInputStream(uri)?.let { return it to null }

        val reportedType = context.contentResolver.getType(uri)
        val typesToTry = listOfNotNull(reportedType, "image/*").distinct()
        var lastError: String? = null
        for (mimeType in typesToTry) {
            try {
                val stream = context.contentResolver.openTypedAssetFileDescriptor(uri, mimeType, null)?.createInputStream()
                if (stream != null) return stream to null
            } catch (e: Exception) {
                lastError = "${e.javaClass.simpleName}: ${e.message}"
                // Not necessarily the last type to try -- fall through and attempt the next one.
            }
        }
        return null to lastError
    }

    /**
     * Downsamples and copies a picked image into this app's own storage,
     * then adds it to the library. Returns null if the image couldn't be
     * decoded at all (corrupt file, unsupported format, permission denied
     * on the source URI after the picker closes). Every failure path logs
     * specifically which stage failed and why, rather than only returning
     * null -- a silent null gives no way to tell "couldn't even open the
     * file" apart from "opened fine but the format couldn't be decoded"
     * apart from "decoded fine but couldn't be saved."
     */
    fun importPhoto(context: Context, sourceUri: Uri): Photo? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try {
            val (stream, openError) = openImageStream(context, sourceUri)
            if (stream == null) {
                Log.e(TAG, "Photo import: could not open a stream for $sourceUri (tried openInputStream and openTypedAssetFileDescriptor with both the reported and wildcard mime type). Last error: $openError")
                DiagnosticLog.appendAppEvent(
                    context,
                    "Photo import failed: could not open stream" +
                        (openError?.let { " ($it)" } ?: "") +
                        " (mime type: ${context.contentResolver.getType(sourceUri)})"
                )
                return null
            }
            stream.use { BitmapFactory.decodeStream(it, null, bounds) }
        } catch (e: Exception) {
            Log.e(TAG, "Photo import: failed reading bounds from $sourceUri", e)
            DiagnosticLog.appendAppEvent(context, "Photo import failed reading file: ${e.javaClass.simpleName}: ${e.message}")
            return null
        }

        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            // BitmapFactory sets these to -1 when it can't determine
            // dimensions at all -- i.e. it doesn't recognize the format,
            // not merely a small/corrupt image. HEIC/HEIF specifically
            // only decodes via BitmapFactory on API 28+; this app's
            // minSdk is 26, so that's one concrete, real gap this covers.
            Log.e(TAG, "Photo import: BitmapFactory could not determine dimensions for $sourceUri (unrecognized format, or HEIC/HEIF on Android < 9)")
            DiagnosticLog.appendAppEvent(context, "Photo import failed: unrecognized image format (mime type from picker: ${context.contentResolver.getType(sourceUri)})")
            return null
        }

        return try {
            var sampleSize = 1
            while (bounds.outWidth / (sampleSize * 2) >= MAX_DIMENSION_PX ||
                bounds.outHeight / (sampleSize * 2) >= MAX_DIMENSION_PX
            ) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val (stream, openError) = openImageStream(context, sourceUri)
            val bitmap = stream?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            }
            if (bitmap == null) {
                Log.e(TAG, "Photo import: bounds decoded but full decode returned null for $sourceUri (stream open error: $openError)")
                DiagnosticLog.appendAppEvent(context, "Photo import failed: full decode returned null after bounds succeeded" + (openError?.let { " ($it)" } ?: ""))
                return null
            }

            val id = java.util.UUID.randomUUID().toString()
            val file = File(photosDir(context), "$id.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            }
            bitmap.recycle()

            val photo = Photo(
                id = id,
                createdAtMs = System.currentTimeMillis(),
                filePath = file.absolutePath,
                isFavorite = false
            )
            add(context, photo)
            photo
        } catch (e: Exception) {
            Log.e(TAG, "Photo import: failed during decode/save for $sourceUri", e)
            DiagnosticLog.appendAppEvent(context, "Photo import failed: ${e.javaClass.simpleName}: ${e.message}")
            null
        }
    }

    fun add(context: Context, photo: Photo) {
        saveAll(context, loadAll(context) + photo)
    }

    fun toggleFavorite(context: Context, id: String) {
        val updated = loadAll(context).map {
            if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it
        }
        saveAll(context, updated)
    }

    fun rename(context: Context, id: String, newName: String?) {
        val updated = loadAll(context).map {
            if (it.id == id) it.copy(customName = newName?.ifBlank { null }) else it
        }
        saveAll(context, updated)
    }

    fun delete(context: Context, id: String) {
        val current = loadAll(context)
        val toRemove = current.firstOrNull { it.id == id } ?: return
        File(toRemove.filePath).delete()
        saveAll(context, current.filterNot { it.id == id })
        if (activePhoto(context)?.id == id) {
            PreferenceManager.getDefaultSharedPreferences(context).edit().remove(KEY_ACTIVE_PHOTO_ID).apply()
        }
    }

    fun activePhoto(context: Context): Photo? {
        val activeId = PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_ACTIVE_PHOTO_ID, null) ?: return null
        return loadAll(context).firstOrNull { it.id == activeId }
    }

    /** Points the wallpaper service at this photo, the photo equivalent of PresetStore.setActive(). */
    fun setActive(context: Context, photo: Photo) {
        val uriString = Uri.fromFile(File(photo.filePath)).toString()
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_ACTIVE_PHOTO_ID, photo.id)
            .apply()
        ActiveVideoFile.write(context, uriString)
        ActiveVideoFile.writeType(context, ActiveVideoFile.TYPE_PHOTO)
        // Also clear the active *preset* marker -- a photo and a video
        // preset can't both be "the active one" at the same time, and
        // leaving a stale preset id around would make Bibliotheek show
        // an old video preset as active when a photo is actually showing.
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .remove(PresetStore.KEY_ACTIVE_PRESET_ID)
            .apply()

        val broadcast = Intent(VideoWallpaperService.ACTION_ACTIVE_VIDEO_CHANGED)
        broadcast.setPackage(context.packageName)
        broadcast.putExtra(VideoWallpaperService.EXTRA_VIDEO_URI, uriString)
        context.sendBroadcast(broadcast)
        DiagnosticLog.appendAppEvent(context, "Photo activated from app: ${PresetStore.shortLabel(uriString)}${photo.customName?.let { " (\"$it\")" } ?: ""}")
    }
}
