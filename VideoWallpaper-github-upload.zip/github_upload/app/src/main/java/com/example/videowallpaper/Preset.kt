package com.example.videowallpaper

import org.json.JSONObject

/**
 * One saved, already-compressed wallpaper: its own video file + thumbnail,
 * independent from whichever preset is currently active. Library screen
 * lists these; BewerkenFragment creates one each time a compress finishes.
 */
data class Preset(
    val id: String,
    val createdAtMs: Long,
    val videoFilePath: String,
    val thumbnailPath: String?,
    val configSignature: String,
    var isFavorite: Boolean,
    val summary: String, // e.g. "1080p · Grayscale · 6 Mbps"
    var customName: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("createdAtMs", createdAtMs)
        put("videoFilePath", videoFilePath)
        put("thumbnailPath", thumbnailPath ?: "")
        put("configSignature", configSignature)
        put("isFavorite", isFavorite)
        put("summary", summary)
        put("customName", customName ?: "")
    }

    companion object {
        fun fromJson(json: JSONObject): Preset = Preset(
            id = json.getString("id"),
            createdAtMs = json.getLong("createdAtMs"),
            videoFilePath = json.getString("videoFilePath"),
            thumbnailPath = json.getString("thumbnailPath").ifEmpty { null },
            configSignature = json.optString("configSignature", ""),
            isFavorite = json.optBoolean("isFavorite", false),
            summary = json.optString("summary", ""),
            customName = json.optString("customName", "").ifEmpty { null }
        )
    }
}
