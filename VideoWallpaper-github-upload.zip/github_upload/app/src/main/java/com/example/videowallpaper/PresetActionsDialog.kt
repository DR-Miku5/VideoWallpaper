package com.example.videowallpaper

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.TextView

object PresetActionsDialog {
    fun show(
        context: Context,
        presetName: String,
        isActive: Boolean,
        onUse: () -> Unit,
        onRename: () -> Unit,
        onDelete: () -> Unit
    ) {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val view = LayoutInflater.from(context).inflate(R.layout.dialog_preset_actions, null)
        dialog.setContentView(view)

        StylePrefs.applyCustomAccentToViewTree(context, view)
        StylePrefs.applyCornerStyleToViewTree(context, view)
        StylePrefs.applyTypefaceToViewTree(context, view)

        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.45f)
        }

        view.findViewById<TextView>(R.id.actionsPresetName).text = presetName

        view.findViewById<Button>(R.id.actionUseButton).apply {
            isEnabled = !isActive
            text = if (isActive) context.getString(R.string.preset_active) else context.getString(R.string.use_preset)
            setOnClickListener {
                dialog.dismiss()
                onUse()
            }
        }
        view.findViewById<Button>(R.id.actionRenameButton).setOnClickListener {
            dialog.dismiss()
            onRename()
        }
        view.findViewById<Button>(R.id.actionDeleteButton).setOnClickListener {
            dialog.dismiss()
            onDelete()
        }

        dialog.setCancelable(true)
        dialog.show()
    }
}
