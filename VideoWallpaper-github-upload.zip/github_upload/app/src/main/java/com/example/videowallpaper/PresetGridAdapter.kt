package com.example.videowallpaper

import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.ToggleButton
import androidx.recyclerview.widget.RecyclerView
import java.text.DateFormat
import java.util.Date

/**
 * Bibliotheek's gallery grid -- replaces the previous row-based list with
 * thumbnail-dominant cards, matching the confirmed visual overhaul design.
 * Since a dense 2-column grid has no room for always-visible action
 * buttons the way the old list did, tapping a card opens
 * PresetActionsDialog for Gebruiken/Hernoemen/Verwijderen; the favorite
 * star stays directly on the card since it's a single tap either way.
 */
class PresetGridAdapter(
    private var presets: List<Preset>,
    private var activeId: String?,
    private val onUse: (Preset) -> Unit,
    private val onRename: (Preset) -> Unit,
    private val onDelete: (Preset) -> Unit,
    private val onToggleFavorite: (Preset) -> Unit
) : RecyclerView.Adapter<PresetGridAdapter.ViewHolder>() {

    private val dateFormat: DateFormat = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val root: View = view.findViewById(R.id.gridCardRoot)
        val thumbnail: ImageView = view.findViewById(R.id.presetThumbnail)
        val activeBadge: TextView = view.findViewById(R.id.activeBadge)
        val activeRing: View = view.findViewById(R.id.activeRing)
        val favoriteToggle: ToggleButton = view.findViewById(R.id.favoriteToggle)
        val date: TextView = view.findViewById(R.id.presetDate)
        val summary: TextView = view.findViewById(R.id.presetSummary)
    }

    fun submit(newPresets: List<Preset>, newActiveId: String?) {
        presets = newPresets
        activeId = newActiveId
        notifyDataSetChanged()
    }

    private fun displayName(preset: Preset): String =
        preset.customName ?: dateFormat.format(Date(preset.createdAtMs))

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_preset_grid, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val preset = presets[position]
        val isActive = preset.id == activeId

        holder.thumbnail.setImageBitmap(null)
        preset.thumbnailPath?.let { path ->
            BitmapFactory.decodeFile(path)?.let { holder.thumbnail.setImageBitmap(it) }
        }

        holder.date.text = displayName(preset)
        holder.summary.text = preset.summary
        holder.activeBadge.visibility = if (isActive) View.VISIBLE else View.GONE
        holder.activeRing.visibility = if (isActive) View.VISIBLE else View.GONE

        holder.favoriteToggle.setOnCheckedChangeListener(null)
        holder.favoriteToggle.isChecked = preset.isFavorite
        holder.favoriteToggle.setOnClickListener { onToggleFavorite(preset) }

        holder.root.setOnClickListener {
            PresetActionsDialog.show(
                holder.root.context,
                displayName(preset),
                isActive,
                onUse = { onUse(preset) },
                onRename = { onRename(preset) },
                onDelete = { onDelete(preset) }
            )
        }
    }

    override fun getItemCount(): Int = presets.size
}
