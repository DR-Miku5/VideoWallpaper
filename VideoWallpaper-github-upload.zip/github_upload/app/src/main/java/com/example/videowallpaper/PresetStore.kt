package com.example.videowallpaper

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.preference.PreferenceManager
import org.json.JSONArray
import java.io.File

/**
 * Presets are stored as a small JSON array in SharedPreferences (a handful
 * of entries, no need for a database). Each preset's actual video/thumbnail
 * files live in filesDir/presets/.
 */
object PresetStore {

    private const val KEY_PRESETS = "presets_json"
    const val KEY_ACTIVE_PRESET_ID = "active_preset_id"

    fun presetsDir(context: Context): File =
        File(context.filesDir, "presets").apply { mkdirs() }

    fun loadAll(context: Context): List<Preset> {
        val raw = PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_PRESETS, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).map { Preset.fromJson(array.getJSONObject(it)) }
                .sortedByDescending { it.createdAtMs }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveAll(context: Context, presets: List<Preset>) {
        val array = JSONArray()
        presets.forEach { array.put(it.toJson()) }
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_PRESETS, array.toString())
            .apply()
    }

    fun add(context: Context, preset: Preset) {
        saveAll(context, loadAll(context) + preset)
    }

    fun findByConfigSignature(context: Context, signature: String): Preset? =
        loadAll(context).firstOrNull { it.configSignature == signature && File(it.videoFilePath).exists() }

    fun toggleFavorite(context: Context, id: String) {
        val updated = loadAll(context).map {
            if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it
        }
        saveAll(context, updated)
    }

    fun rename(context: Context, id: String, newName: String?) {
        val updated = loadAll(context).map {
            if (it.id == id) it.copy(customName = newName?.ifBlank { null }) else it
        }
        saveAll(context, updated)
    }

    fun delete(context: Context, id: String) {
        val current = loadAll(context)
        val toRemove = current.firstOrNull { it.id == id } ?: return
        File(toRemove.videoFilePath).delete()
        toRemove.thumbnailPath?.let { File(it).delete() }
        saveAll(context, current.filterNot { it.id == id })
    }

    /** Points the wallpaper service at this preset's compressed video. */
    private const val KEY_ACTIVE_THUMBNAIL_PATH = "active_thumbnail_path"
    private const val KEY_ACTIVE_SUMMARY = "active_summary"
    private const val KEY_ACTIVE_CUSTOM_NAME = "active_custom_name"
    private const val KEY_ACTIVE_CREATED_AT_MS = "active_created_at_ms"
    private const val KEY_ACTIVE_VIDEO_FILE_PATH = "active_video_file_path"
    private const val KEY_ACTIVE_CONFIG_SIGNATURE = "active_config_signature"

    /**
     * Everything Start needs to show the currently active video --
     * thumbnail, name, summary -- cached independently of whether it's
     * also a saved library entry. Preset objects, and therefore
     * PresetStore.activePreset(), only exist for videos that were added
     * to the library; since v5.11.0's "Opslaan in bibliotheek" toggle
     * made that optional, Start's own preview can no longer assume the
     * active video will always be found there. Written unconditionally
     * by setActive(), so it's always available regardless of that choice.
     */
    data class ActiveVideoMeta(
        val thumbnailPath: String?,
        val summary: String,
        val customName: String?,
        val createdAtMs: Long,
        val videoFilePath: String,
        val configSignature: String
    )

    fun activeVideoMeta(context: Context): ActiveVideoMeta? {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val videoFilePath = prefs.getString(KEY_ACTIVE_VIDEO_FILE_PATH, null) ?: return null
        return ActiveVideoMeta(
            thumbnailPath = prefs.getString(KEY_ACTIVE_THUMBNAIL_PATH, null),
            summary = prefs.getString(KEY_ACTIVE_SUMMARY, "") ?: "",
            customName = prefs.getString(KEY_ACTIVE_CUSTOM_NAME, null),
            createdAtMs = prefs.getLong(KEY_ACTIVE_CREATED_AT_MS, 0L),
            videoFilePath = videoFilePath,
            configSignature = prefs.getString(KEY_ACTIVE_CONFIG_SIGNATURE, "") ?: ""
        )
    }

    /**
     * True once the currently active video also exists as a saved
     * Preset -- if false, Start's "save to library" button has
     * something to actually do; if true, it's already there and the
     * button should stay hidden.
     */
    fun isActiveVideoSavedToLibrary(context: Context): Boolean = activePreset(context) != null

    /**
     * Reconstructs a Preset from the cached active-video metadata and
     * adds it to the library -- the retroactive "I changed my mind"
     * path for a video that was applied with "Opslaan in bibliotheek"
     * turned off. Does nothing if there's no active video to save, or
     * if it's already saved (no duplicate entries).
     */
    fun saveActiveVideoToLibrary(context: Context): Boolean {
        val meta = activeVideoMeta(context) ?: return false
        if (isActiveVideoSavedToLibrary(context)) return false

        val newId = java.util.UUID.randomUUID().toString()
        val preset = Preset(
            id = newId,
            createdAtMs = meta.createdAtMs,
            videoFilePath = meta.videoFilePath,
            thumbnailPath = meta.thumbnailPath,
            configSignature = meta.configSignature,
            isFavorite = false,
            summary = meta.summary,
            customName = meta.customName
        )
        add(context, preset)
        // The saved copy needs to become the tracked active preset too,
        // so isActiveVideoSavedToLibrary() correctly reflects it from
        // here on -- otherwise the button would stay visible after
        // saving, appearing to do nothing.
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_ACTIVE_PRESET_ID, newId)
            .apply()
        return true
    }

    fun setActive(context: Context, preset: Preset) {
        val uriString = Uri.fromFile(File(preset.videoFilePath)).toString()
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(VideoWallpaperService.KEY_VIDEO_URI, uriString)
            .putString(KEY_ACTIVE_PRESET_ID, preset.id)
            .putString(KEY_ACTIVE_THUMBNAIL_PATH, preset.thumbnailPath)
            .putString(KEY_ACTIVE_SUMMARY, preset.summary)
            .putString(KEY_ACTIVE_CUSTOM_NAME, preset.customName)
            .putLong(KEY_ACTIVE_CREATED_AT_MS, preset.createdAtMs)
            .putString(KEY_ACTIVE_VIDEO_FILE_PATH, preset.videoFilePath)
            .putString(KEY_ACTIVE_CONFIG_SIGNATURE, preset.configSignature)
            .apply()
        ActiveVideoFile.write(context, uriString)
        ActiveVideoFile.writeType(context, ActiveVideoFile.TYPE_VIDEO)
        // A photo and a video preset can't both be "the active one" --
        // clear any active photo marker so Slideshow/Bibliotheek/Foto's
        // never show a stale photo as active once a video takes over.
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .remove(PhotoStore.KEY_ACTIVE_PHOTO_ID)
            .apply()
        // The wallpaper engine runs in a separate process and won't see
        // this preference change on its own -- tell it explicitly, and
        // carry the URI directly rather than relying on the other
        // process re-reading (possibly stale-cached) SharedPreferences.
        val broadcast = Intent(VideoWallpaperService.ACTION_ACTIVE_VIDEO_CHANGED)
        broadcast.setPackage(context.packageName)
        broadcast.putExtra(VideoWallpaperService.EXTRA_VIDEO_URI, uriString)
        context.sendBroadcast(broadcast)
        DiagnosticLog.appendAppEvent(context, "Preset activated from app: ${shortLabel(uriString)}${preset.customName?.let { " (\"$it\")" } ?: ""}")
    }

    /**
     * Clears "what's active" entirely, rather than leaving the app
     * claiming a preset is applied when it can no longer be sure that's
     * true (e.g. right after an app update, where the wallpaper process
     * restarts and there's no reliable way to confirm the OS still shows
     * the same video). The person has to explicitly re-apply, but the
     * app's own UI never lies about it in the meantime.
     */
    fun clearActive(context: Context) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .remove(VideoWallpaperService.KEY_VIDEO_URI)
            .remove(KEY_ACTIVE_PRESET_ID)
            .apply()
        ActiveVideoFile.clear(context)
    }

    /**
     * The reliable way to find "what's active": matches by the preset's
     * own ID, stored directly at setActive() time -- not by comparing a
     * path re-derived from the stored URI against each preset's file
     * path, which can silently fail to match on some devices/Android
     * versions even when both strings point at the same file.
     */
    fun activePreset(context: Context): Preset? {
        val activeId = PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_ACTIVE_PRESET_ID, null) ?: return null
        return loadAll(context).firstOrNull { it.id == activeId }
    }

    /**
     * Whether Android currently has THIS app's service set as the live
     * wallpaper. setActive() can only ever update this app's own state
     * and broadcast to whatever Engine happens to be alive -- it can't
     * make Android itself point at this app if the system-level
     * connection has gone stale (only confirmed cause so far: the app
     * being uninstalled, which wipes Android's wallpaper registration
     * entirely -- an OS-level state no app code can prevent). Checked
     * passively by Start's banner rather than interrupting any apply
     * action -- v4.4.0's original dialog-on-apply approach was removed
     * in v5.1.4 as too intrusive, but silently saying "success" while
     * nothing actually changed left no way to know something was wrong
     * at all, which is worse. This is the middle ground: informative
     * without blocking anything.
     */
    fun isThisAppTheSystemWallpaper(context: Context): Boolean {
        return try {
            val info = android.app.WallpaperManager.getInstance(context).wallpaperInfo
            info != null && info.packageName == context.packageName
        } catch (e: Exception) {
            false
        }
    }

    /** Short, stable label identifying which file a log line is about, matching VideoWallpaperService's own videoLabel(). */
    fun shortLabel(uriString: String): String =
        uriString.substringAfterLast('/').substringBefore('.').take(8).ifBlank { "unknown" }
}
