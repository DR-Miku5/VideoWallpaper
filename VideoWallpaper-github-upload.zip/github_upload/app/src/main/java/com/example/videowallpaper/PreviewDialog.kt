package com.example.videowallpaper

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.Gravity
import android.view.LayoutInflater
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.view.Window
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

/**
 * Plays the trimmed range of the ORIGINAL source before you commit to a
 * compress -- filters aren't rendered live here (those only apply during
 * the actual Transformer export), but trim points are the thing people
 * most often want to double-check, and this covers that.
 */
object PreviewDialog {

    fun show(activity: Activity, sourceUri: Uri, startSec: Long, endSec: Long?) {
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_preview, null)
        dialog.setContentView(view)

        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.45f)
        }

        val player = ExoPlayer.Builder(activity).build()
        val surfaceView = view.findViewById<SurfaceView>(R.id.previewSurface)
        surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                player.setVideoSurfaceHolder(holder)
            }
            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
            override fun surfaceDestroyed(holder: SurfaceHolder) {}
        })

        var mediaItemBuilder = MediaItem.Builder().setUri(sourceUri)
        if (startSec > 0 || endSec != null) {
            val clipping = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startSec * 1000)
                .apply { if (endSec != null) setEndPositionMs(endSec * 1000) }
                .build()
            mediaItemBuilder = mediaItemBuilder.setClippingConfiguration(clipping)
        }
        player.setMediaItem(mediaItemBuilder.build())
        player.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
        player.prepare()
        player.play()

        view.findViewById<android.widget.Button>(R.id.previewCloseButton).setOnClickListener {
            dialog.dismiss()
        }
        dialog.setOnDismissListener { player.release() }
        dialog.setCancelable(true)
        dialog.show()
    }
}
