package com.example.videowallpaper

import android.content.Context
import android.preference.PreferenceManager

/**
 * Whether an incoming notification should trigger a brief pulse on the
 * wallpaper. Only takes visible effect while a photo is the active
 * wallpaper -- overlaying an effect on live video would need a much
 * larger rework (ExoPlayer owns the wallpaper's single Surface while
 * playing; there's no safe way to draw on top of it without custom
 * OpenGL compositing), so this is scoped to photo mode for now.
 */
object PulsePrefs {

    private const val KEY_NOTIFICATION_PULSE_ENABLED = "notification_pulse_enabled"

    fun isNotificationPulseEnabled(context: Context): Boolean =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getBoolean(KEY_NOTIFICATION_PULSE_ENABLED, false)

    fun setNotificationPulseEnabled(context: Context, enabled: Boolean) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putBoolean(KEY_NOTIFICATION_PULSE_ENABLED, enabled)
            .apply()
    }
}
