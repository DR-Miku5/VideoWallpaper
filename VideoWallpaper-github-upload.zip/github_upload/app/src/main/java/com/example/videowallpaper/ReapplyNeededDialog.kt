package com.example.videowallpaper

import android.app.Activity
import android.app.Dialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.Window
import android.widget.Toast

/**
 * Shown whenever PresetStore.setActive() / PhotoStore.setActive()
 * succeeded (the app's own records are correct) but Android itself
 * isn't currently pointing at this app's service as the live wallpaper
 * -- most commonly after the app itself was uninstalled and reinstalled,
 * which wipes Android's wallpaper registration entirely (an OS-level
 * state no app code can prevent). Explains why nothing visibly changed
 * and offers to open Android's own wallpaper picker directly, which is
 * the only thing that actually re-establishes that connection.
 *
 * The app's own styled bottom sheet, matching EditVideoPromptDialog's
 * pattern -- replaces the plain default system AlertDialog (generic
 * grey, doesn't match the rest of the app) with a sheet that respects
 * Stijl theming (accent color including custom RGB, corner style,
 * typeface), so it reads as part of the app rather than a stock Android
 * popup dropped on top of it.
 *
 * History: added v4.4.0 (as a plain AlertDialog), removed v5.1.4 (found
 * too intrusive), replaced with a passive Start-screen banner in v5.1.5.
 * Restored in v5.1.7 -- the banner alone wasn't resolving the reported
 * problem in practice. Both now coexist: this dialog for the immediate
 * moment of applying, the Start banner as a backup for any other time
 * the connection is stale. Re-styled as a custom sheet in v5.1.8.
 */
object ReapplyNeededDialog {
    fun show(activity: Activity) {
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_reapply_needed, null)
        dialog.setContentView(view)

        // Full Stijl theming, not just what the activity's base theme
        // already provides -- custom RGB accent colors and corner style
        // specifically need the explicit view-tree walk, since a theme
        // overlay alone can't represent an arbitrary custom color.
        StylePrefs.applyCustomAccentToViewTree(activity, view)
        StylePrefs.applyCornerStyleToViewTree(activity, view)
        StylePrefs.applyTypefaceToViewTree(activity, view)

        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.45f)
        }

        view.findViewById<android.widget.Button>(R.id.reapplyOpenPickerButton).setOnClickListener {
            dialog.dismiss()
            try {
                val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                intent.putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(activity, VideoWallpaperService::class.java)
                )
                activity.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(activity, R.string.wallpaper_picker_unavailable, Toast.LENGTH_LONG).show()
            }
        }
        view.findViewById<android.widget.Button>(R.id.reapplyCancelButton).setOnClickListener {
            dialog.dismiss()
        }

        dialog.setCancelable(true)
        dialog.show()
    }
}
