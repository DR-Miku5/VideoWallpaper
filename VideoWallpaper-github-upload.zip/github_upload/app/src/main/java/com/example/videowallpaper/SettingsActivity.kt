package com.example.videowallpaper

import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.NotificationManagerCompat
import androidx.core.os.LocaleListCompat
import java.io.File

class SettingsActivity : BaseActivity() {

    /** Language tag to (its own native name, a representative flag) -- name shown as-is in every locale, never translated. */
    private val languages = listOf(
        Triple("", null, "🌐"),
        Triple("nl", "Nederlands", "🇳🇱"),
        Triple("en", "English", "🇬🇧"),
        Triple("de", "Deutsch", "🇩🇪"),
        Triple("fr", "Français", "🇫🇷"),
        Triple("es", "Español", "🇪🇸")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        StylePrefs.applyAccentTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        setUpLanguageRow()
        setUpThemeSegments()
        setUpToggles()
        setUpPermissionsRow()
        setUpBatteryRow()
        setUpClearCacheRow()
        setUpChangelogRow()

        StylePrefs.applyCustomAccentToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyTypefaceToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyBackgroundPattern(this, findViewById(android.R.id.content))
        StylePrefs.applyButtonFeedbackStyle(this, findViewById(android.R.id.content))
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshPermissionsSummary()
    }

    private fun currentLanguageTag(): String {
        val currentTags = AppCompatDelegate.getApplicationLocales()
        return if (currentTags.isEmpty) "" else currentTags[0]?.language ?: ""
    }

    private fun setUpLanguageRow() {
        refreshLanguageRow()
        findViewById<View>(R.id.languageRow).setOnClickListener {
            showLanguagePickerDialog()
        }
    }

    private fun refreshLanguageRow() {
        val currentTag = currentLanguageTag()
        val (_, name, flag) = languages.firstOrNull { it.first == currentTag } ?: languages.first()
        findViewById<TextView>(R.id.languageFlagText).text = flag
        findViewById<TextView>(R.id.languageNameText).text = name ?: getString(R.string.language_system)
    }

    /**
     * The language row on the main screen is deliberately collapsed to
     * one line (matching the confirmed design) -- the actual picker
     * lives in this dialog, reusing the same custom bottom-sheet
     * pattern as ReapplyNeededDialog/PresetActionsDialog rather than a
     * plain AlertDialog, so it stays visually consistent with the rest
     * of the app.
     */
    private fun showLanguagePickerDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_language_picker, null)
        dialog.setContentView(view)
        StylePrefs.applyCustomAccentToViewTree(this, view)
        StylePrefs.applyCornerStyleToViewTree(this, view)
        StylePrefs.applyTypefaceToViewTree(this, view)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.45f)
        }

        val radioGroup = view.findViewById<RadioGroup>(R.id.languageDialogRadioGroup)
        val currentTag = currentLanguageTag()
        for ((tag, nativeName, flag) in languages) {
            val button = RadioButton(this)
            button.id = View.generateViewId()
            button.text = "$flag  ${nativeName ?: getString(R.string.language_system)}"
            button.setTextColor(getColor(R.color.text_primary))
            button.isChecked = tag == currentTag
            button.setOnClickListener {
                val locales = if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(tag)
                AppCompatDelegate.setApplicationLocales(locales)
                dialog.dismiss()
            }
            radioGroup.addView(button)
        }
        dialog.setCancelable(true)
        dialog.show()
    }

    /** Segmented sun/system/moon control, replacing the old stacked RadioGroup. */
    private fun setUpThemeSegments() {
        val lightSeg = findViewById<TextView>(R.id.themeLightSegment)
        val systemSeg = findViewById<TextView>(R.id.themeSystemSegment)
        val darkSeg = findViewById<TextView>(R.id.themeDarkSegment)

        fun applySelection(mode: String) {
            ThemePrefs.setThemeMode(this, mode)
            updateThemeSegmentStyles(mode)
        }

        lightSeg.setOnClickListener { applySelection(ThemePrefs.MODE_LIGHT) }
        systemSeg.setOnClickListener { applySelection(ThemePrefs.MODE_SYSTEM) }
        darkSeg.setOnClickListener { applySelection(ThemePrefs.MODE_DARK) }

        updateThemeSegmentStyles(ThemePrefs.getThemeMode(this))
    }

    private fun updateThemeSegmentStyles(mode: String) {
        val lightSeg = findViewById<TextView>(R.id.themeLightSegment)
        val systemSeg = findViewById<TextView>(R.id.themeSystemSegment)
        val darkSeg = findViewById<TextView>(R.id.themeDarkSegment)
        val segments = mapOf(ThemePrefs.MODE_LIGHT to lightSeg, ThemePrefs.MODE_SYSTEM to systemSeg, ThemePrefs.MODE_DARK to darkSeg)
        for ((segMode, seg) in segments) {
            val selected = segMode == mode
            seg.setBackgroundResource(if (selected) R.drawable.chip_filter_selected else 0)
            if (seg === systemSeg) {
                seg.setTextColor(getColor(if (selected) R.color.text_primary else R.color.nav_inactive_on_dark))
            }
        }
    }

    /** Wi-Fi-only and reduce-motion -- real, persisted toggles; see SettingsPrefs.kt for what's not yet built on top of them. */
    private fun setUpToggles() {
        val wifiSwitch = findViewById<android.widget.Switch>(R.id.wifiOnlySwitch)
        wifiSwitch.isChecked = SettingsPrefs.isWifiOnlyEnabled(this)
        wifiSwitch.setOnCheckedChangeListener { _, checked -> SettingsPrefs.setWifiOnlyEnabled(this, checked) }

        val motionSwitch = findViewById<android.widget.Switch>(R.id.reduceMotionSwitch)
        motionSwitch.isChecked = SettingsPrefs.isReduceMotionEnabled(this)
        motionSwitch.setOnCheckedChangeListener { _, checked -> SettingsPrefs.setReduceMotionEnabled(this, checked) }
    }

    private fun setUpPermissionsRow() {
        findViewById<View>(R.id.permissionsRow).setOnClickListener {
            showPermissionsDialog()
        }
    }

    private fun isBatteryExempt(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun isNotificationAccessGranted(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun refreshPermissionsSummary() {
        val activeCount = listOf(isBatteryExempt(), isNotificationAccessGranted()).count { it }
        findViewById<TextView>(R.id.permissionsSummaryText).text =
            getString(R.string.settings_permissions_summary, activeCount, 2)
    }

    private fun showPermissionsDialog() {
        val batteryLabel = getString(R.string.settings_permission_battery) + ": " +
            getString(if (isBatteryExempt()) R.string.settings_permission_active else R.string.settings_permission_inactive)
        val notifLabel = getString(R.string.settings_permission_notification) + ": " +
            getString(if (isNotificationAccessGranted()) R.string.settings_permission_active else R.string.settings_permission_inactive)
        AlertDialog.Builder(this)
            .setTitle(R.string.settings_permissions_summary_title_short)
            .setItems(arrayOf(batteryLabel, notifLabel), null)
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    private fun setUpBatteryRow() {
        findViewById<View>(R.id.batteryRow).setOnClickListener {
            requestBatteryOptimizationExemption()
        }
    }

    private fun setUpClearCacheRow() {
        refreshCacheSize()
        findViewById<View>(R.id.clearCacheRow).setOnClickListener {
            cacheDir.deleteRecursively()
            Toast.makeText(this, R.string.settings_cache_cleared, Toast.LENGTH_SHORT).show()
            refreshCacheSize()
        }
    }

    private fun refreshCacheSize() {
        val bytes = cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        findViewById<TextView>(R.id.cacheSizeText).text = "${bytes / (1024 * 1024)} MB"
    }

    private fun setUpChangelogRow() {
        findViewById<View>(R.id.changelogRow).setOnClickListener {
            startActivity(Intent(this, InfoActivity::class.java))
            TransitionHelper.applyForward(this)
        }
    }

    private fun refreshStatus() {
        val runtime = Runtime.getRuntime()
        val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        val maxMb = runtime.maxMemory() / (1024 * 1024)
        val memoryText = getString(R.string.status_memory_value, usedMb, maxMb)

        val statFs = StatFs(filesDir.path)
        val freeMb = (statFs.availableBytes) / (1024 * 1024)
        val storageText = getString(R.string.status_storage_value, freeMb)

        findViewById<TextView>(R.id.statusCaptionText).text =
            getString(R.string.settings_status_caption, memoryText, storageText)
    }

    private fun requestBatteryOptimizationExemption() {
        if (isBatteryExempt()) {
            Toast.makeText(this, R.string.battery_already_exempt, Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = android.net.Uri.parse("package:$packageName")
            startActivity(intent)
        }
    }
}
