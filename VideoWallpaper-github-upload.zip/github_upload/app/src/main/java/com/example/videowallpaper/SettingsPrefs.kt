package com.example.videowallpaper

import android.content.Context
import android.preference.PreferenceManager

/**
 * Two settings confirmed as genuinely new during the visual overhaul,
 * not restyles of anything that existed before. This object makes the
 * choice real and persistent -- the toggle itself is not a placeholder.
 * What's NOT included here: the actual enforcement. Wi-Fi-only would
 * need every cloud-backed picker read (video/photo import) to check
 * network type first; reduce-motion would need a flag threaded through
 * every animated transition (circular reveal, button feedback, Stijl's
 * reactive glow). Both are real follow-up work, not done in this pass.
 */
object SettingsPrefs {
    private const val KEY_WIFI_ONLY = "wifi_only_downloads"
    private const val KEY_REDUCE_MOTION = "reduce_motion"

    fun isWifiOnlyEnabled(context: Context): Boolean =
        PreferenceManager.getDefaultSharedPreferences(context).getBoolean(KEY_WIFI_ONLY, false)

    fun setWifiOnlyEnabled(context: Context, enabled: Boolean) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().putBoolean(KEY_WIFI_ONLY, enabled).apply()
    }

    fun isReduceMotionEnabled(context: Context): Boolean =
        PreferenceManager.getDefaultSharedPreferences(context).getBoolean(KEY_REDUCE_MOTION, false)

    fun setReduceMotionEnabled(context: Context, enabled: Boolean) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().putBoolean(KEY_REDUCE_MOTION, enabled).apply()
    }
}
