package com.example.videowallpaper

import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.activity.result.contract.ActivityResultContracts
import java.text.DateFormat
import java.util.Date

class SlideshowActivity : BaseActivity() {

    private lateinit var photoListContainer: LinearLayout
    private lateinit var photoEmptyText: TextView

    private val pickPhoto = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            // Not fatal -- the photo gets copied into our own storage immediately anyway.
        }
        val photo = PhotoStore.importPhoto(this, uri)
        if (photo == null) {
            Toast.makeText(this, R.string.photo_import_failed, Toast.LENGTH_LONG).show()
        }
        refreshPhotos()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        StylePrefs.applyAccentTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slideshow)
        StylePrefs.applyCustomAccentToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyTypefaceToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyBackgroundPattern(this, findViewById(android.R.id.content))
        StylePrefs.applyButtonFeedbackStyle(this, findViewById(android.R.id.content))

        photoListContainer = findViewById(R.id.photoListContainer)
        photoEmptyText = findViewById(R.id.photoEmptyText)

        val enableSwitch = findViewById<Switch>(R.id.slideshowEnableSwitch)
        val intervalGroup = findViewById<RadioGroup>(R.id.intervalRadioGroup)
        val sourceGroup = findViewById<RadioGroup>(R.id.sourceRadioGroup)
        val customIntervalRow = findViewById<LinearLayout>(R.id.customIntervalRow)
        val customIntervalInput = findViewById<EditText>(R.id.customIntervalInput)

        enableSwitch.isChecked = SlideshowPrefs.isEnabled(this)
        when {
            SlideshowPrefs.isCustomInterval(this) -> {
                findViewById<android.widget.RadioButton>(R.id.intervalCustom).isChecked = true
                customIntervalRow.visibility = android.view.View.VISIBLE
            }
            SlideshowPrefs.intervalMinutes(this) == 15 -> findViewById<android.widget.RadioButton>(R.id.interval15).isChecked = true
            SlideshowPrefs.intervalMinutes(this) == 60 -> findViewById<android.widget.RadioButton>(R.id.interval60).isChecked = true
            else -> findViewById<android.widget.RadioButton>(R.id.interval30).isChecked = true
        }
        customIntervalInput.setText(SlideshowPrefs.customIntervalMinutes(this).toString())

        findViewById<android.widget.RadioButton>(
            if (SlideshowPrefs.favoritesOnly(this)) R.id.sourceFavorites else R.id.sourceAll
        ).isChecked = true

        enableSwitch.setOnCheckedChangeListener { _, checked ->
            SlideshowPrefs.setEnabled(this, checked)
        }
        intervalGroup.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.intervalCustom) {
                customIntervalRow.visibility = android.view.View.VISIBLE
                SlideshowPrefs.setCustomIntervalMinutes(this, customIntervalInput.text.toString().toIntOrNull() ?: 30)
            } else {
                customIntervalRow.visibility = android.view.View.GONE
                val minutes = when (checkedId) {
                    R.id.interval15 -> 15
                    R.id.interval60 -> 60
                    else -> 30
                }
                SlideshowPrefs.setIntervalMinutes(this, minutes)
            }
        }
        customIntervalInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val minutes = s?.toString()?.toIntOrNull() ?: return
                if (findViewById<android.widget.RadioButton>(R.id.intervalCustom).isChecked) {
                    SlideshowPrefs.setCustomIntervalMinutes(this@SlideshowActivity, minutes)
                }
            }
        })
        sourceGroup.setOnCheckedChangeListener { _, checkedId ->
            SlideshowPrefs.setFavoritesOnly(this, checkedId == R.id.sourceFavorites)
        }

        findViewById<android.widget.Button>(R.id.addPhotoButton).setOnClickListener {
            pickPhoto.launch(arrayOf("image/*"))
        }

        val notificationPulseSwitch = findViewById<Switch>(R.id.notificationPulseSwitch)
        notificationPulseSwitch.isChecked = PulsePrefs.isNotificationPulseEnabled(this)
        notificationPulseSwitch.setOnCheckedChangeListener { _, checked ->
            PulsePrefs.setNotificationPulseEnabled(this, checked)
        }
        findViewById<android.widget.Button>(R.id.notificationAccessButton).setOnClickListener {
            try {
                startActivity(android.content.Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, R.string.pulse_notification_access_unavailable, Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPhotos()
    }

    private fun refreshPhotos() {
        photoListContainer.removeAllViews()
        val photos = PhotoStore.loadAll(this)
        photoEmptyText.visibility = if (photos.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE

        val activeId = PhotoStore.activePhoto(this)?.id
        val dateFormat = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        val inflater = android.view.LayoutInflater.from(this)

        for (photo in photos) {
            val row = inflater.inflate(R.layout.item_photo, photoListContainer, false)

            row.findViewById<ImageView>(R.id.photoThumbnail).let { thumb ->
                BitmapFactory.decodeFile(photo.filePath)?.let { thumb.setImageBitmap(it) }
            }
            row.findViewById<TextView>(R.id.photoDate).text =
                photo.customName ?: dateFormat.format(Date(photo.createdAtMs))

            row.findViewById<TextView>(R.id.photoRenameButton).setOnClickListener {
                showRenameDialog(photo)
            }

            val favoriteToggle = row.findViewById<ToggleButton>(R.id.photoFavoriteToggle)
            favoriteToggle.isChecked = photo.isFavorite
            favoriteToggle.setOnClickListener {
                PhotoStore.toggleFavorite(this, photo.id)
                refreshPhotos()
            }

            row.findViewById<android.widget.Button>(R.id.photoUseButton).apply {
                isEnabled = photo.id != activeId
                text = if (photo.id == activeId) getString(R.string.preset_active) else getString(R.string.use_preset)
                setOnClickListener {
                    PhotoStore.setActive(this@SlideshowActivity, photo)
                    if (PresetStore.isThisAppTheSystemWallpaper(this@SlideshowActivity)) {
                        Toast.makeText(this@SlideshowActivity, R.string.preset_now_active, Toast.LENGTH_SHORT).show()
                    } else {
                        ReapplyNeededDialog.show(this@SlideshowActivity)
                    }
                    refreshPhotos()
                }
            }

            row.findViewById<android.widget.Button>(R.id.photoDeleteButton).setOnClickListener {
                PhotoStore.delete(this, photo.id)
                refreshPhotos()
            }

            StylePrefs.applyCustomAccentToButton(this, row.findViewById(R.id.photoUseButton), 8f)
            photoListContainer.addView(row)
        }
        StylePrefs.applyCustomAccentToViewTree(this, photoListContainer)
        StylePrefs.applyButtonFeedbackStyle(this, photoListContainer)
    }

    private fun showRenameDialog(photo: Photo) {
        val input = EditText(this)
        input.setText(photo.customName ?: "")
        input.hint = getString(R.string.rename_hint)

        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(input)
            .setPositiveButton(R.string.rename_save) { _, _ ->
                PhotoStore.rename(this, photo.id, input.text.toString())
                refreshPhotos()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
