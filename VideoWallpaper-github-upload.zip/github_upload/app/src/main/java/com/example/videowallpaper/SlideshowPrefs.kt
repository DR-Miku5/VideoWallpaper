package com.example.videowallpaper

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.preference.PreferenceManager

object SlideshowPrefs {

    private const val KEY_ENABLED = "slideshow_enabled"
    private const val KEY_INTERVAL_MINUTES = "slideshow_interval_minutes"
    private const val KEY_CUSTOM_INTERVAL_MINUTES = "slideshow_custom_interval_minutes"
    private const val KEY_FAVORITES_ONLY = "slideshow_favorites_only"
    private const val KEY_ROTATION_INDEX = "slideshow_rotation_index"

    /** Stored in KEY_INTERVAL_MINUTES to mean "use the custom value" instead of one of the fixed options. */
    const val CUSTOM_INTERVAL_SENTINEL = -1

    fun isEnabled(context: Context): Boolean =
        PreferenceManager.getDefaultSharedPreferences(context).getBoolean(KEY_ENABLED, false)

    fun isCustomInterval(context: Context): Boolean =
        PreferenceManager.getDefaultSharedPreferences(context).getInt(KEY_INTERVAL_MINUTES, 30) == CUSTOM_INTERVAL_SENTINEL

    fun customIntervalMinutes(context: Context): Int =
        PreferenceManager.getDefaultSharedPreferences(context).getInt(KEY_CUSTOM_INTERVAL_MINUTES, 30)

    fun setCustomIntervalMinutes(context: Context, minutes: Int) {
        val clamped = minutes.coerceIn(1, 1440) // 1 minute to 24 hours, sane outer bounds
        PreferenceManager.getDefaultSharedPreferences(context).edit().putInt(KEY_CUSTOM_INTERVAL_MINUTES, clamped).apply()
        PreferenceManager.getDefaultSharedPreferences(context).edit().putInt(KEY_INTERVAL_MINUTES, CUSTOM_INTERVAL_SENTINEL).apply()
        if (isEnabled(context)) schedule(context)
    }

    fun intervalMinutes(context: Context): Int {
        val stored = PreferenceManager.getDefaultSharedPreferences(context).getInt(KEY_INTERVAL_MINUTES, 30)
        return if (stored == CUSTOM_INTERVAL_SENTINEL) customIntervalMinutes(context) else stored
    }

    fun favoritesOnly(context: Context): Boolean =
        PreferenceManager.getDefaultSharedPreferences(context).getBoolean(KEY_FAVORITES_ONLY, true)

    fun setFavoritesOnly(context: Context, value: Boolean) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().putBoolean(KEY_FAVORITES_ONLY, value).apply()
    }

    fun setIntervalMinutes(context: Context, minutes: Int) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().putInt(KEY_INTERVAL_MINUTES, minutes).apply()
        if (isEnabled(context)) schedule(context) // re-schedule with the new interval immediately
    }

    fun nextRotationIndex(context: Context, poolSize: Int): Int {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        val current = prefs.getInt(KEY_ROTATION_INDEX, -1)
        val next = if (poolSize == 0) 0 else (current + 1) % poolSize
        prefs.edit().putInt(KEY_ROTATION_INDEX, next).apply()
        return next
    }

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, SlideshowReceiver::class.java)
        return PendingIntent.getBroadcast(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (enabled) schedule(context) else cancel(context)
    }

    fun schedule(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intervalMs = intervalMinutes(context) * 60_000L
        // Inexact repeating: no special "exact alarm" permission needed, and
        // the system is free to batch this with other apps' alarms to save
        // battery -- fine for a "every N minutes" wallpaper rotation.
        alarmManager.setInexactRepeating(
            AlarmManager.RTC,
            System.currentTimeMillis() + intervalMs,
            intervalMs,
            pendingIntent(context)
        )
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent(context))
    }
}
