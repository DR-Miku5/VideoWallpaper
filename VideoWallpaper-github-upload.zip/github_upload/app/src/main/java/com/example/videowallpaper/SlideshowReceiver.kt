package com.example.videowallpaper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class SlideshowReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!SlideshowPrefs.isEnabled(context)) return

        val favoritesOnly = SlideshowPrefs.favoritesOnly(context)
        val presets = PresetStore.loadAll(context).let { if (favoritesOnly) it.filter { p -> p.isFavorite } else it }
        val photos = PhotoStore.loadAll(context).let { if (favoritesOnly) it.filter { p -> p.isFavorite } else it }

        // Videos first, then photos, in a single combined rotation order --
        // simplest way to give both types a turn without needing separate
        // interleaving logic.
        val poolSize = presets.size + photos.size
        if (poolSize == 0) return // nothing to rotate to yet

        val index = SlideshowPrefs.nextRotationIndex(context, poolSize)
        if (index < presets.size) {
            PresetStore.setActive(context, presets[index])
        } else {
            PhotoStore.setActive(context, photos[index - presets.size])
        }
        // The wallpaper service picks this up via the cross-process
        // broadcast PresetStore.setActive()/PhotoStore.setActive() already
        // send -- no need to relaunch the wallpaper or touch the engine
        // from here.
    }
}
