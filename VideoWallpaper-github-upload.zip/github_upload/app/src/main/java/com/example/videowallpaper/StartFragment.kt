package com.example.videowallpaper

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment

/**
 * Start: shows a preview of whatever's currently active, lets you pick a
 * video, then asks whether you want to customize it in Bewerken or just
 * apply it with the default bitrate (6 Mbps) straight away.
 */
class StartFragment : Fragment() {

    private lateinit var previewThumbnail: ImageView
    private lateinit var previewPlaceholder: TextView
    private lateinit var presetNameText: TextView
    private lateinit var presetSummaryText: TextView
    private lateinit var batteryEstimateText: TextView
    private lateinit var reapplyBanner: android.widget.LinearLayout
    private lateinit var muteToggle: android.widget.Switch
    private lateinit var saveToLibraryButton: TextView

    private val pickVideo = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            requireContext().contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: SecurityException) {
            // Not fatal -- Bewerken is about to transcode this into our
            // own storage anyway, so long-term access isn't needed.
        }
        promptEditChoice(uri)
    }

    private fun promptEditChoice(uri: Uri) {
        EditVideoPromptDialog.show(
            requireActivity(),
            onEdit = { goToBewerken(uri, autoApply = false) },
            onApplyDefault = { goToBewerken(uri, autoApply = true) }
        )
    }

    private fun goToBewerken(uri: Uri, autoApply: Boolean) {
        (requireActivity() as HostActivity).switchTo(NavTab.BEWERKEN, sourceUriForBewerken = uri, autoApply = autoApply)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_start, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        StylePrefs.applyCustomAccentToViewTree(requireContext(), view)
        StylePrefs.applyTypefaceToViewTree(requireContext(), view)
        StylePrefs.applyBackgroundPattern(requireContext(), view)
        StylePrefs.applyButtonFeedbackStyle(requireContext(), view)

        previewThumbnail = view.findViewById(R.id.previewThumbnail)
        previewPlaceholder = view.findViewById(R.id.previewPlaceholder)
        presetNameText = view.findViewById(R.id.presetNameText)
        presetSummaryText = view.findViewById(R.id.presetSummaryText)
        batteryEstimateText = view.findViewById(R.id.batteryEstimateText)
        reapplyBanner = view.findViewById(R.id.reapplyBanner)
        muteToggle = view.findViewById(R.id.muteToggle)
        saveToLibraryButton = view.findViewById(R.id.saveToLibraryButton)
        saveToLibraryButton.setOnClickListener {
            when {
                PresetStore.activeVideoMeta(requireContext()) == null ->
                    Toast.makeText(requireContext(), R.string.start_nothing_to_save, Toast.LENGTH_SHORT).show()
                PresetStore.isActiveVideoSavedToLibrary(requireContext()) ->
                    Toast.makeText(requireContext(), R.string.start_already_saved, Toast.LENGTH_SHORT).show()
                PresetStore.saveActiveVideoToLibrary(requireContext()) ->
                    Toast.makeText(requireContext(), R.string.start_saved_to_library, Toast.LENGTH_SHORT).show()
            }
        }
        view.findViewById<TextView>(R.id.reapplyBannerAction).setOnClickListener {
            openSystemWallpaperPicker()
        }

        val prefs = PreferenceManager.getDefaultSharedPreferences(requireContext())
        muteToggle.isChecked = !prefs.getBoolean(VideoWallpaperService.KEY_MUTED, true)
        muteToggle.setOnCheckedChangeListener { _, isChecked ->
            val muted = !isChecked
            prefs.edit().putBoolean(VideoWallpaperService.KEY_MUTED, muted).apply()
            val broadcast = Intent(VideoWallpaperService.ACTION_MUTE_CHANGED)
            broadcast.setPackage(requireContext().packageName)
            broadcast.putExtra(VideoWallpaperService.EXTRA_MUTED, muted)
            requireContext().sendBroadcast(broadcast)
        }

        view.findViewById<android.widget.Button>(R.id.pickAndEditButton).also {
            StylePrefs.applyCustomAccentToButton(requireContext(), it, 12f)
        }.setOnClickListener {
            pickVideo.launch(arrayOf("video/*"))
        }
        view.findViewById<android.widget.Button>(R.id.setWallpaperButton).setOnClickListener {
            openSystemWallpaperPicker()
        }

        showUpdateResetNoticeIfNeeded()

        if (arguments?.getBoolean("auto_open_picker", false) == true) {
            arguments?.putBoolean("auto_open_picker", false) // only once
            pickVideo.launch(arrayOf("video/*"))
        }
    }

    private fun showUpdateResetNoticeIfNeeded() {
        val prefs = PreferenceManager.getDefaultSharedPreferences(requireContext())
        if (prefs.getBoolean(VideoWallpaperApp.KEY_SHOW_UPDATE_RESET_NOTICE, false)) {
            prefs.edit().putBoolean(VideoWallpaperApp.KEY_SHOW_UPDATE_RESET_NOTICE, false).apply()
            Toast.makeText(requireContext(), R.string.update_reset_notice, Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPreview()
        refreshBatteryEstimate()
        refreshReapplyBanner()
    }

    /**
     * A passive, non-blocking check -- shown here rather than as a
     * dialog interrupting an apply action (v4.4.0's original approach,
     * removed in v5.1.4 as too intrusive). Checked every time Start
     * becomes visible, since that's a screen already looked at
     * regularly, without needing to interrupt anything to surface it.
     * Only shows when there's actually an active preset AND Android
     * isn't pointing at this app -- an empty library or a genuinely
     * connected wallpaper both correctly show nothing.
     */
    private fun refreshReapplyBanner() {
        val hasActivePreset = PresetStore.activePreset(requireContext()) != null
        val isConnected = PresetStore.isThisAppTheSystemWallpaper(requireContext())
        reapplyBanner.visibility = if (hasActivePreset && !isConnected) View.VISIBLE else View.GONE
    }

    /**
     * Shows the real, measured drain rate (DiagnosticLog.
     * estimatedDrainRatePerHour(), the same figure Diagnostiek computes)
     * prominently on the screen you actually look at day to day, instead
     * of only in Diagnostiek where it's easy to forget to check. Never
     * shows a fabricated placeholder number -- if there isn't enough
     * data yet, it says so plainly instead of guessing.
     */
    private fun refreshBatteryEstimate() {
        val rate = DiagnosticLog.estimatedDrainRatePerHour(requireContext())
        batteryEstimateText.text = if (rate == null) {
            getString(R.string.start_battery_estimate_no_data)
        } else {
            getString(R.string.start_battery_estimate, rate)
        }
    }

    private fun refreshPreview() {
        val meta = PresetStore.activeVideoMeta(requireContext())
        val thumbPath = meta?.thumbnailPath

        if (meta != null) {
            presetNameText.visibility = View.VISIBLE
            presetSummaryText.visibility = View.VISIBLE
            presetNameText.text = meta.customName
                ?: android.text.format.DateFormat.getDateFormat(requireContext()).format(java.util.Date(meta.createdAtMs))
            presetSummaryText.text = meta.summary
        } else {
            presetNameText.visibility = View.GONE
            presetSummaryText.visibility = View.GONE
        }

        if (thumbPath != null) {
            val bitmap = BitmapFactory.decodeFile(thumbPath)
            if (bitmap != null) {
                previewThumbnail.setImageBitmap(bitmap)
                previewThumbnail.visibility = View.VISIBLE
                previewPlaceholder.visibility = View.GONE
                return
            }
        }
        previewThumbnail.visibility = View.GONE
        previewPlaceholder.visibility = View.VISIBLE
    }

    private fun openSystemWallpaperPicker() {
        try {
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            intent.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(requireContext(), VideoWallpaperService::class.java)
            )
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(requireContext(), R.string.wallpaper_picker_unavailable, Toast.LENGTH_LONG).show()
        }
    }
}
