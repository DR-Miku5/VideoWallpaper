package com.example.videowallpaper

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView

class StyleActivity : BaseActivity() {

    private data class Swatch(val hue: String, val colorRes: Int)

    private val accentSwatches = listOf(
        Swatch(StylePrefs.ACCENT_BLUE, R.color.accent_blue),
        Swatch(StylePrefs.ACCENT_PURPLE, R.color.accent_purple),
        Swatch(StylePrefs.ACCENT_TEAL, R.color.accent_teal),
        Swatch(StylePrefs.ACCENT_CORAL, R.color.accent_coral),
        Swatch(StylePrefs.ACCENT_GREEN, R.color.accent_green)
    )

    private val backgroundSwatches = listOf(
        Swatch(StylePrefs.BACKGROUND_BLUE, R.color.background_blue),
        Swatch(StylePrefs.BACKGROUND_SLATE, R.color.background_slate),
        Swatch(StylePrefs.BACKGROUND_WARM, R.color.background_warm)
    )

    /**
     * One reusable controller for a swatch + hex input + R/G/B
     * sliders + numeric inputs group, since the accent and background
     * cards are functionally identical. Guards against update loops with
     * updatingProgrammatically: every listener checks it first and skips
     * if a programmatic sync (from another field in the same group) is
     * already in progress.
     */
    private inner class ColorGroup(
        val swatch: android.view.View,
        val hexInput: EditText,
        val redSeekBar: SeekBar,
        val greenSeekBar: SeekBar,
        val blueSeekBar: SeekBar,
        val redInput: EditText,
        val greenInput: EditText,
        val blueInput: EditText,
        initialColor: Int
    ) {
        private var updatingProgrammatically = false

        init {
            setColor(initialColor, updateHex = true, updateSliders = true, updateInputs = true)

            val seekListener = object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (!fromUser || updatingProgrammatically) return
                    setColor(currentColor(), updateHex = true, updateSliders = false, updateInputs = true)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            }
            redSeekBar.setOnSeekBarChangeListener(seekListener)
            greenSeekBar.setOnSeekBarChangeListener(seekListener)
            blueSeekBar.setOnSeekBarChangeListener(seekListener)

            fun numericWatcher(seekBar: SeekBar) = object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (updatingProgrammatically) return
                    val value = s?.toString()?.toIntOrNull()?.coerceIn(0, 255) ?: return
                    seekBar.progress = value
                    setColor(currentColor(), updateHex = true, updateSliders = false, updateInputs = false)
                }
            }
            redInput.addTextChangedListener(numericWatcher(redSeekBar))
            greenInput.addTextChangedListener(numericWatcher(greenSeekBar))
            blueInput.addTextChangedListener(numericWatcher(blueSeekBar))

            hexInput.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (updatingProgrammatically) return
                    val hex = s?.toString()?.trim() ?: return
                    if (hex.length != 6) return // wait for a full 6-digit code before parsing
                    val color = try {
                        Color.parseColor("#$hex")
                    } catch (e: IllegalArgumentException) {
                        return // not valid hex yet (e.g. mid-typing) -- ignore silently rather than erroring
                    }
                    setColor(color, updateHex = false, updateSliders = true, updateInputs = true)
                }
            })
        }

        private fun currentColor(): Int = Color.rgb(redSeekBar.progress, greenSeekBar.progress, blueSeekBar.progress)

        fun currentColorValue(): Int = currentColor()

        private fun setColor(color: Int, updateHex: Boolean, updateSliders: Boolean, updateInputs: Boolean) {
            updatingProgrammatically = true

            val r = Color.red(color)
            val g = Color.green(color)
            val b = Color.blue(color)

            if (updateSliders) {
                redSeekBar.progress = r
                greenSeekBar.progress = g
                blueSeekBar.progress = b
            }
            if (updateInputs) {
                redInput.setText(r.toString())
                greenInput.setText(g.toString())
                blueInput.setText(b.toString())
            }
            if (updateHex) {
                hexInput.setText(String.format("%02X%02X%02X", r, g, b))
            }

            val drawable = GradientDrawable()
            drawable.shape = GradientDrawable.OVAL
            drawable.setColor(color)
            swatch.background = drawable

            updatingProgrammatically = false
        }
    }

    private lateinit var accentGroup: ColorGroup
    private lateinit var backgroundGroup: ColorGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        StylePrefs.applyAccentTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_style)
        StylePrefs.applyCornerStyleToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyCustomAccentToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyTypefaceToViewTree(this, findViewById(android.R.id.content))
        StylePrefs.applyBackgroundPattern(this, findViewById(android.R.id.content))

        renderSwatches()
        setUpDensity()
        setUpCustomColor()
        setUpCustomBackgroundColor()
        setUpCornerStyle()
        setUpFontSize()
        setUpTypeface()
        setUpBackgroundPattern()
        setUpButtonFeedback()
        StylePrefs.applyButtonFeedbackStyle(this, findViewById(android.R.id.content))

        findViewById<android.widget.Button>(R.id.randomStyleButton).setOnClickListener {
            StylePrefs.randomize(this)
            recreate()
        }
        findViewById<android.widget.Button>(R.id.resetStyleButton).setOnClickListener {
            StylePrefs.resetToDefaults(this)
            recreate()
        }
    }

    private fun renderSwatches() {
        drawSwatchRow(
            findViewById(R.id.accentSwatchRow),
            accentSwatches,
            StylePrefs.getAccentHue(this)
        ) { hue -> StylePrefs.setAccentHue(this, hue); recreate() }

        drawSwatchRow(
            findViewById(R.id.backgroundSwatchRow),
            backgroundSwatches,
            StylePrefs.getBackgroundHue(this)
        ) { hue -> StylePrefs.setBackgroundHue(this, hue); recreate() }
    }

    private fun drawSwatchRow(
        row: LinearLayout,
        swatches: List<Swatch>,
        currentHue: String,
        onPick: (String) -> Unit
    ) {
        row.removeAllViews()
        val size = (28 * resources.displayMetrics.density).toInt()
        val margin = (10 * resources.displayMetrics.density).toInt()

        for (swatch in swatches) {
            val circle = android.view.View(this)
            val params = LinearLayout.LayoutParams(size, size)
            params.marginEnd = margin
            circle.layoutParams = params

            val drawable = GradientDrawable()
            drawable.shape = GradientDrawable.OVAL
            drawable.setColor(getColor(swatch.colorRes))
            if (swatch.hue == currentHue) {
                drawable.setStroke((2 * resources.displayMetrics.density).toInt(), getColor(android.R.color.white))
            }
            val rippleColor = android.content.res.ColorStateList.valueOf(
                resolveThemeColor(android.R.attr.colorControlHighlight)
            )
            circle.background = android.graphics.drawable.RippleDrawable(rippleColor, drawable, drawable)

            circle.setOnClickListener { onPick(swatch.hue) }
            row.addView(circle)
        }
    }

    private fun resolveThemeColor(attr: Int): Int {
        val typedValue = android.util.TypedValue()
        theme.resolveAttribute(attr, typedValue, true)
        return typedValue.data
    }

    private fun setUpDensity() {
        val group = findViewById<RadioGroup>(R.id.densityRadioGroup)
        findViewById<android.widget.RadioButton>(
            if (StylePrefs.isCompactDensity(this)) R.id.densityCompact else R.id.densityComfortable
        ).isChecked = true

        group.setOnCheckedChangeListener { _, checkedId ->
            StylePrefs.setCompactDensity(this, checkedId == R.id.densityCompact)
        }
    }

    private fun setUpCornerStyle() {
        val group = findViewById<RadioGroup>(R.id.cornerStyleRadioGroup)
        findViewById<android.widget.RadioButton>(
            if (StylePrefs.isSharpCorners(this)) R.id.cornerSharp else R.id.cornerRounded
        ).isChecked = true

        group.setOnCheckedChangeListener { _, checkedId ->
            val style = if (checkedId == R.id.cornerSharp) StylePrefs.CORNER_SHARP else StylePrefs.CORNER_ROUNDED
            StylePrefs.setCornerStyle(this, style)
            recreate()
        }
    }

    private fun setUpFontSize() {
        val group = findViewById<RadioGroup>(R.id.fontSizeRadioGroup)
        val current = StylePrefs.getFontScale(this)
        val checkedId = when (current) {
            StylePrefs.FONT_SCALE_SMALL -> R.id.fontSizeSmall
            StylePrefs.FONT_SCALE_LARGE -> R.id.fontSizeLarge
            else -> R.id.fontSizeStandard
        }
        findViewById<android.widget.RadioButton>(checkedId).isChecked = true

        group.setOnCheckedChangeListener { _, id ->
            val scale = when (id) {
                R.id.fontSizeSmall -> StylePrefs.FONT_SCALE_SMALL
                R.id.fontSizeLarge -> StylePrefs.FONT_SCALE_LARGE
                else -> StylePrefs.FONT_SCALE_STANDARD
            }
            StylePrefs.setFontScale(this, scale)
            recreate()
        }
    }

    private fun setUpTypeface() {
        val group = findViewById<RadioGroup>(R.id.typefaceRadioGroup)
        val checkedId = when (StylePrefs.getTypeface(this)) {
            StylePrefs.TYPEFACE_SERIF -> R.id.typefaceSerif
            StylePrefs.TYPEFACE_MONOSPACE -> R.id.typefaceMonospace
            else -> R.id.typefaceDefault
        }
        findViewById<android.widget.RadioButton>(checkedId).isChecked = true

        group.setOnCheckedChangeListener { _, id ->
            val family = when (id) {
                R.id.typefaceSerif -> StylePrefs.TYPEFACE_SERIF
                R.id.typefaceMonospace -> StylePrefs.TYPEFACE_MONOSPACE
                else -> StylePrefs.TYPEFACE_DEFAULT
            }
            StylePrefs.setTypeface(this, family)
            recreate()
        }
    }

    private fun setUpBackgroundPattern() {
        val group = findViewById<RadioGroup>(R.id.patternRadioGroup)
        val checkedId = when (StylePrefs.getBackgroundPattern(this)) {
            StylePrefs.PATTERN_DOTS -> R.id.patternDots
            StylePrefs.PATTERN_DIAGONAL -> R.id.patternDiagonal
            else -> R.id.patternNone
        }
        findViewById<android.widget.RadioButton>(checkedId).isChecked = true

        group.setOnCheckedChangeListener { _, id ->
            val pattern = when (id) {
                R.id.patternDots -> StylePrefs.PATTERN_DOTS
                R.id.patternDiagonal -> StylePrefs.PATTERN_DIAGONAL
                else -> StylePrefs.PATTERN_NONE
            }
            StylePrefs.setBackgroundPattern(this, pattern)
            recreate()
        }
    }

    private fun setUpButtonFeedback() {
        val group = findViewById<RadioGroup>(R.id.buttonFeedbackRadioGroup)
        val checkedId = when (StylePrefs.getButtonFeedbackStyle(this)) {
            StylePrefs.BUTTON_FEEDBACK_RIPPLE_DELAYED -> R.id.feedbackRippleDelayed
            StylePrefs.BUTTON_FEEDBACK_FLASH -> R.id.feedbackFlash
            else -> R.id.feedbackScale
        }
        findViewById<android.widget.RadioButton>(checkedId).isChecked = true

        group.setOnCheckedChangeListener { _, id ->
            val style = when (id) {
                R.id.feedbackRippleDelayed -> StylePrefs.BUTTON_FEEDBACK_RIPPLE_DELAYED
                R.id.feedbackFlash -> StylePrefs.BUTTON_FEEDBACK_FLASH
                else -> StylePrefs.BUTTON_FEEDBACK_SCALE
            }
            StylePrefs.setButtonFeedbackStyle(this, style)
            recreate()
        }
    }

    private fun setUpCustomColor() {
        accentGroup = ColorGroup(
            swatch = findViewById(R.id.customColorSwatch),
            hexInput = findViewById(R.id.customColorHexInput),
            redSeekBar = findViewById(R.id.redSeekBar),
            greenSeekBar = findViewById(R.id.greenSeekBar),
            blueSeekBar = findViewById(R.id.blueSeekBar),
            redInput = findViewById(R.id.redValueInput),
            greenInput = findViewById(R.id.greenValueInput),
            blueInput = findViewById(R.id.blueValueInput),
            initialColor = StylePrefs.getCustomAccentColor(this)
        )

        findViewById<android.widget.Button>(R.id.applyCustomColorButton).setOnClickListener {
            StylePrefs.setCustomAccentColor(this, accentGroup.currentColorValue())
            StylePrefs.setAccentHue(this, StylePrefs.ACCENT_CUSTOM)
            recreate()
        }
    }

    private fun setUpCustomBackgroundColor() {
        backgroundGroup = ColorGroup(
            swatch = findViewById(R.id.customBackgroundSwatch),
            hexInput = findViewById(R.id.customBackgroundHexInput),
            redSeekBar = findViewById(R.id.backgroundRedSeekBar),
            greenSeekBar = findViewById(R.id.backgroundGreenSeekBar),
            blueSeekBar = findViewById(R.id.backgroundBlueSeekBar),
            redInput = findViewById(R.id.backgroundRedValueInput),
            greenInput = findViewById(R.id.backgroundGreenValueInput),
            blueInput = findViewById(R.id.backgroundBlueValueInput),
            initialColor = StylePrefs.getCustomBackgroundColor(this)
        )

        findViewById<android.widget.Button>(R.id.applyCustomBackgroundButton).setOnClickListener {
            StylePrefs.setCustomBackgroundColor(this, backgroundGroup.currentColorValue())
            StylePrefs.setBackgroundHue(this, StylePrefs.BACKGROUND_CUSTOM)
            recreate()
        }
    }
}
