package com.example.videowallpaper

import android.content.Context
import android.preference.PreferenceManager
import android.util.TypedValue

/**
 * Accent color: applied by calling setTheme() with one of the
 * Theme.VideoWallpaper.Accent* variants in every Activity's onCreate,
 * before setContentView. Layouts/drawables reference ?attr/colorAccent
 * (not @color/accent directly) so the swap actually retints them; the two
 * spots that set color from Kotlin instead of XML resolve it via
 * resolveAccentColor() below rather than reading @color/accent directly.
 *
 * Density: a scale factor (0.75 for compact, 1.0 for comfortable) used by
 * the programmatically-built screens (Meer, Bibliotheek, Diagnostiek,
 * Info) when computing padding -- StartFragment's XML layout doesn't pick
 * this up since its spacing is fixed in the layout file itself.
 */
object StylePrefs {

    private const val KEY_ACCENT = "accent_hue"
    private const val KEY_BACKGROUND = "background_hue"
    private const val KEY_DENSITY = "density_compact"
    private const val KEY_CUSTOM_ACCENT_RGB = "custom_accent_rgb"
    private const val KEY_CUSTOM_BACKGROUND_RGB = "custom_background_rgb"
    private const val KEY_CORNER_STYLE = "corner_style"
    private const val KEY_FONT_SCALE = "font_scale"
    private const val KEY_TYPEFACE = "typeface_family"
    private const val KEY_BACKGROUND_PATTERN = "background_pattern"
    private const val KEY_BUTTON_FEEDBACK = "button_feedback_style"

    const val ACCENT_BLUE = "blue"
    const val ACCENT_PURPLE = "purple"
    const val ACCENT_TEAL = "teal"
    const val ACCENT_CORAL = "coral"
    const val ACCENT_GREEN = "green"
    const val ACCENT_CUSTOM = "custom"

    const val BACKGROUND_BLUE = "blue"
    const val BACKGROUND_SLATE = "slate"
    const val BACKGROUND_WARM = "warm"
    const val BACKGROUND_CUSTOM = "custom"

    const val CORNER_ROUNDED = "rounded"
    const val CORNER_SHARP = "sharp"

    const val FONT_SCALE_SMALL = 0.9f
    const val FONT_SCALE_STANDARD = 1.0f
    const val FONT_SCALE_LARGE = 1.15f

    const val TYPEFACE_DEFAULT = "default"
    const val TYPEFACE_SERIF = "serif"
    const val TYPEFACE_MONOSPACE = "monospace"

    const val PATTERN_NONE = "none"
    const val PATTERN_DOTS = "dots"
    const val PATTERN_DIAGONAL = "diagonal"

    const val BUTTON_FEEDBACK_SCALE = "scale"
    const val BUTTON_FEEDBACK_RIPPLE_DELAYED = "ripple_delayed"
    const val BUTTON_FEEDBACK_FLASH = "flash"

    fun getAccentHue(context: Context): String =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_ACCENT, ACCENT_BLUE) ?: ACCENT_BLUE

    fun setAccentHue(context: Context, hue: String) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_ACCENT, hue)
            .apply()
        IconAliasManager.syncToAccent(context, hue)
    }

    fun getCustomAccentColor(context: Context): Int =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getInt(KEY_CUSTOM_ACCENT_RGB, android.graphics.Color.rgb(46, 92, 148)) // matches ACCENT_BLUE's light-mode value as a sane default

    fun setCustomAccentColor(context: Context, colorInt: Int) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putInt(KEY_CUSTOM_ACCENT_RGB, colorInt)
            .apply()
    }

    fun getBackgroundHue(context: Context): String =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_BACKGROUND, BACKGROUND_BLUE) ?: BACKGROUND_BLUE

    fun setBackgroundHue(context: Context, hue: String) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_BACKGROUND, hue)
            .apply()
    }

    fun getCustomBackgroundColor(context: Context): Int =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getInt(KEY_CUSTOM_BACKGROUND_RGB, android.graphics.Color.rgb(234, 242, 250)) // matches BACKGROUND_BLUE's light-mode value as a sane default

    fun setCustomBackgroundColor(context: Context, colorInt: Int) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putInt(KEY_CUSTOM_BACKGROUND_RGB, colorInt)
            .apply()
    }

    /**
     * Call before setContentView() in every Activity. Accent and
     * background are independent choices, so they're layered as two
     * separate ThemeOverlays rather than picking one pre-combined theme --
     * that would need a style per accent x background pairing.
     *
     * Custom RGB is a special case: Android has no supported way to inject
     * an arbitrary runtime int into a compiled theme attribute, so XML-
     * driven elements (?attr/colorAccent references) fall back to the blue
     * overlay here, and applyCustomAccentToViewTree() below retints the
     * specific views that can be reached programmatically instead.
     */
    fun applyAccentTheme(context: android.app.Activity) {
        val accentOverlay = when (getAccentHue(context)) {
            ACCENT_PURPLE -> R.style.ThemeOverlay_Accent_Purple
            ACCENT_TEAL -> R.style.ThemeOverlay_Accent_Teal
            ACCENT_CORAL -> R.style.ThemeOverlay_Accent_Coral
            ACCENT_GREEN -> R.style.ThemeOverlay_Accent_Green
            else -> R.style.ThemeOverlay_Accent_Blue // also the fallback base for ACCENT_CUSTOM
        }
        val backgroundOverlay = when (getBackgroundHue(context)) {
            BACKGROUND_SLATE -> R.style.ThemeOverlay_Background_Slate
            BACKGROUND_WARM -> R.style.ThemeOverlay_Background_Warm
            else -> R.style.ThemeOverlay_Background_Blue
        }
        context.theme.applyStyle(accentOverlay, true)
        context.theme.applyStyle(backgroundOverlay, true)
    }

    /** For the rare cases (OnboardingActivity dots, InfoActivity titles) set from Kotlin. */
    fun resolveAccentColor(context: Context): Int {
        if (getAccentHue(context) == ACCENT_CUSTOM) return getCustomAccentColor(context)
        val typedValue = TypedValue()
        context.theme.resolveAttribute(android.R.attr.colorAccent, typedValue, true)
        return typedValue.data
    }

    /** For screens (InfoActivity) that set a background color from Kotlin instead of XML. */
    fun resolveBackgroundColor(context: Context): Int {
        if (getBackgroundHue(context) == BACKGROUND_CUSTOM) return getCustomBackgroundColor(context)
        val typedValue = TypedValue()
        context.theme.resolveAttribute(android.R.attr.windowBackground, typedValue, true)
        return typedValue.data
    }

    /**
     * Every accent color int the 5 preset hues can resolve to, in both
     * light and dark mode -- used to recognize "this view is accent-
     * tinted" by comparing its current color, so custom-color retinting
     * needs no changes to any layout XML.
     */
    private fun knownPresetAccentColors(context: Context): Set<Int> = setOf(
        context.getColor(R.color.accent_blue),
        context.getColor(R.color.accent_purple),
        context.getColor(R.color.accent_teal),
        context.getColor(R.color.accent_coral),
        context.getColor(R.color.accent_green)
    )

    /**
     * Call after setContentView() in every Activity. A no-op unless
     * ACCENT_CUSTOM is active. Walks the view tree and retints anything
     * whose current color matches one of the 5 known preset accent
     * colors -- section headers, radio buttons, switches -- to the custom
     * RGB value instead.
     */
    fun applyCustomAccentToViewTree(context: Context, root: android.view.View) {
        if (getAccentHue(context) != ACCENT_CUSTOM) return
        val target = getCustomAccentColor(context)
        val known = knownPresetAccentColors(context)
        retintRecursive(root, known, target)
    }

    private fun retintRecursive(view: android.view.View, known: Set<Int>, target: Int) {
        when (view) {
            is android.widget.CompoundButton -> {
                // Covers RadioButton, Switch, CheckBox -- all use buttonTintList/thumbTintList.
                view.buttonTintList = android.content.res.ColorStateList.valueOf(target)
            }
            is android.widget.TextView -> {
                if (view.currentTextColor in known) view.setTextColor(target)
            }
        }
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                retintRecursive(view.getChildAt(i), known, target)
            }
        }
    }

    /** Recolors a rounded accent-filled button (e.g. Toepassen, Ja bewerken) for custom mode. */
    fun applyCustomAccentToButton(context: Context, button: android.widget.Button, cornerRadiusDp: Float) {
        if (getAccentHue(context) != ACCENT_CUSTOM) return
        val drawable = android.graphics.drawable.GradientDrawable()
        drawable.shape = android.graphics.drawable.GradientDrawable.RECTANGLE
        drawable.setColor(getCustomAccentColor(context))
        drawable.cornerRadius = if (isSharpCorners(context)) 0f else cornerRadiusDp * context.resources.displayMetrics.density
        button.background = drawable
    }

    fun getCornerStyle(context: Context): String =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_CORNER_STYLE, CORNER_ROUNDED) ?: CORNER_ROUNDED

    fun setCornerStyle(context: Context, style: String) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_CORNER_STYLE, style)
            .apply()
    }

    fun isSharpCorners(context: Context): Boolean = getCornerStyle(context) == CORNER_SHARP

    /**
     * Every rounded-corner drawable that has a sharp-corner counterpart,
     * mapped to that counterpart's resource id. Compared by constantState
     * (Android caches one ConstantState per drawable resource, so this
     * reliably identifies "this view's background is exactly this XML
     * drawable resource," not just a visually similar one) rather than by
     * walking layout XML, so this needs no changes to any layout file.
     */
    private fun cornerVariantMap(context: Context): Map<Any, Int> {
        fun state(resId: Int) = androidx.core.content.ContextCompat.getDrawable(context, resId)?.constantState
        val pairs = listOf(
            R.drawable.card_background to R.drawable.card_background_sharp,
            R.drawable.button_background to R.drawable.button_background_sharp,
            R.drawable.button_accent_background to R.drawable.button_accent_background_sharp,
            R.drawable.chip_selected to R.drawable.chip_selected_sharp,
            R.drawable.chip_unselected to R.drawable.chip_unselected_sharp,
            R.drawable.tile_background to R.drawable.tile_background_sharp,
            R.drawable.preview_tile_background to R.drawable.preview_tile_background_sharp
        )
        return pairs.mapNotNull { (rounded, sharp) -> state(rounded)?.let { it to sharp } }.toMap()
    }

    /**
     * Call after setContentView() in every Activity. A no-op unless
     * CORNER_SHARP is active. Walks the view tree and swaps any background
     * that's exactly one of the app's known rounded-corner drawables for
     * its sharp-corner counterpart.
     */
    fun applyCornerStyleToViewTree(context: Context, root: android.view.View) {
        if (!isSharpCorners(context)) return
        val variants = cornerVariantMap(context)
        if (variants.isEmpty()) return
        cornerRecursive(context, root, variants)
    }

    private fun cornerRecursive(context: Context, view: android.view.View, variants: Map<Any, Int>) {
        val bg = view.background
        val state = bg?.constantState
        if (state != null) {
            variants[state]?.let { sharpResId ->
                view.background = androidx.core.content.ContextCompat.getDrawable(context, sharpResId)
            }
        }
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                cornerRecursive(context, view.getChildAt(i), variants)
            }
        }
    }

    fun getFontScale(context: Context): Float =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getFloat(KEY_FONT_SCALE, FONT_SCALE_STANDARD)

    fun setFontScale(context: Context, scale: Float) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putFloat(KEY_FONT_SCALE, scale)
            .apply()
    }

    fun getBackgroundPattern(context: Context): String =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_BACKGROUND_PATTERN, PATTERN_NONE) ?: PATTERN_NONE

    fun setBackgroundPattern(context: Context, pattern: String) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_BACKGROUND_PATTERN, pattern)
            .apply()
    }

    /**
     * Call after setContentView()/onViewCreated() on every screen's root
     * view. A no-op unless a pattern other than "none" is chosen, OR a
     * custom background color is active (which, like custom accent, has
     * no theme-attribute equivalent and needs to be applied directly to
     * the root view instead). Draws a small repeating tile procedurally
     * (dots or diagonal lines, in a faint accent tint) rather than
     * needing bundled image assets, and layers it over the screen's
     * already-resolved background color.
     */
    fun applyBackgroundPattern(context: Context, rootView: android.view.View) {
        val pattern = getBackgroundPattern(context)
        val isCustomBackground = getBackgroundHue(context) == BACKGROUND_CUSTOM
        if (pattern == PATTERN_NONE && !isCustomBackground) return

        val baseColor = resolveBackgroundColor(context)
        if (pattern == PATTERN_NONE) {
            rootView.background = android.graphics.drawable.ColorDrawable(baseColor)
            return
        }

        val tile = generatePatternTile(context, pattern)
        val tileDrawable = android.graphics.drawable.BitmapDrawable(context.resources, tile)
        tileDrawable.tileModeX = android.graphics.Shader.TileMode.REPEAT
        tileDrawable.tileModeY = android.graphics.Shader.TileMode.REPEAT

        val composite = android.graphics.drawable.LayerDrawable(
            arrayOf(android.graphics.drawable.ColorDrawable(baseColor), tileDrawable)
        )
        rootView.background = composite
    }

    private fun generatePatternTile(context: Context, pattern: String): android.graphics.Bitmap {
        val density = context.resources.displayMetrics.density
        val size = (32 * density).toInt().coerceAtLeast(1)
        val bitmap = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.color = resolveAccentColor(context)
        paint.alpha = 22 // a faint tint -- meant to be textural, not a visible pattern from a normal viewing distance

        when (pattern) {
            PATTERN_DOTS -> {
                paint.style = android.graphics.Paint.Style.FILL
                canvas.drawCircle(size / 2f, size / 2f, 1.6f * density, paint)
            }
            PATTERN_DIAGONAL -> {
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = 1f * density
                canvas.drawLine(0f, size.toFloat(), size.toFloat(), 0f, paint)
            }
        }
        return bitmap
    }

    fun getTypeface(context: Context): String =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_TYPEFACE, TYPEFACE_DEFAULT) ?: TYPEFACE_DEFAULT

    fun setTypeface(context: Context, family: String) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_TYPEFACE, family)
            .apply()
    }

    /**
     * Call after setContentView() in every Activity, alongside the other
     * view-tree passes. A no-op unless a non-default typeface is chosen.
     * Android has no Configuration-level typeface override the way it
     * does for font scale, so this walks the tree and sets each text
     * view's typeface directly, preserving its existing bold/italic style.
     */
    fun applyTypefaceToViewTree(context: Context, root: android.view.View) {
        val family = getTypeface(context)
        if (family == TYPEFACE_DEFAULT) return
        val familyName = if (family == TYPEFACE_SERIF) "serif" else "monospace"
        typefaceRecursive(root, familyName)
    }

    private fun typefaceRecursive(view: android.view.View, familyName: String) {
        if (view is android.widget.TextView) {
            val style = view.typeface?.style ?: android.graphics.Typeface.NORMAL
            view.typeface = android.graphics.Typeface.create(familyName, style)
        }
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                typefaceRecursive(view.getChildAt(i), familyName)
            }
        }
    }

    fun isCompactDensity(context: Context): Boolean =
        PreferenceManager.getDefaultSharedPreferences(context).getBoolean(KEY_DENSITY, false)

    fun setCompactDensity(context: Context, compact: Boolean) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putBoolean(KEY_DENSITY, compact)
            .apply()
    }

    /** Scale factor for dp-based padding in programmatically-built screens. */
    fun densityScale(context: Context): Float = if (isCompactDensity(context)) 0.75f else 1.0f

    fun resetToDefaults(context: Context) {
        setAccentHue(context, ACCENT_BLUE)
        setBackgroundHue(context, BACKGROUND_BLUE)
        setCompactDensity(context, false)
        setCornerStyle(context, CORNER_ROUNDED)
        setFontScale(context, FONT_SCALE_STANDARD)
        setTypeface(context, TYPEFACE_DEFAULT)
        setBackgroundPattern(context, PATTERN_NONE)
        setButtonFeedbackStyle(context, BUTTON_FEEDBACK_SCALE)
        IconAliasManager.syncToAccent(context, ACCENT_BLUE)
    }

    fun randomize(context: Context) {
        val accents = listOf(ACCENT_BLUE, ACCENT_PURPLE, ACCENT_TEAL, ACCENT_CORAL, ACCENT_GREEN)
        val backgrounds = listOf(BACKGROUND_BLUE, BACKGROUND_SLATE, BACKGROUND_WARM)
        setAccentHue(context, accents.random())
        setBackgroundHue(context, backgrounds.random())
    }

    fun getButtonFeedbackStyle(context: Context): String =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_BUTTON_FEEDBACK, BUTTON_FEEDBACK_SCALE) ?: BUTTON_FEEDBACK_SCALE

    fun setButtonFeedbackStyle(context: Context, style: String) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_BUTTON_FEEDBACK, style)
            .apply()
    }

    /**
     * Call after setContentView()/onViewCreated() on every screen's root
     * view, alongside the other view-tree passes. Attaches a touch
     * listener to every clickable view matching the chosen feedback
     * style, without needing to touch any individual click handler:
     *
     * - SCALE (default): the pressed view visibly shrinks on touch-down
     *   and springs back on release -- immediate, visible even on a fast
     *   tap, since it's driven by the touch event itself rather than by
     *   how long the animation has to play before something else (like
     *   an Activity recreate()) interrupts it.
     * - RIPPLE_DELAYED: keeps the existing RippleDrawable, but delays
     *   actually firing the click by ~150ms so the ripple has time to
     *   render before the screen changes underneath it. This is why taps
     *   on Stijl's swatches/toggles (which call recreate() immediately)
     *   were only showing feedback on a slow press-and-hold before: the
     *   screen was being torn down and rebuilt faster than the ripple
     *   could animate.
     * - FLASH: a brief solid-color overlay flash on touch-down.
     */
    fun applyButtonFeedbackStyle(context: Context, root: android.view.View) {
        val style = getButtonFeedbackStyle(context)
        feedbackRecursive(context, root, style)
    }

    private fun feedbackRecursive(context: Context, view: android.view.View, style: String) {
        val skipsFeedback = view is android.widget.SeekBar || view is android.widget.EditText
        if (view.isClickable && !skipsFeedback) {
            attachFeedbackTouchListener(view, style)
        }
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                feedbackRecursive(context, view.getChildAt(i), style)
            }
        }
    }

    private fun attachFeedbackTouchListener(view: android.view.View, style: String) {
        when (style) {
            BUTTON_FEEDBACK_SCALE -> {
                view.setOnTouchListener { v, event ->
                    when (event.action) {
                        android.view.MotionEvent.ACTION_DOWN ->
                            v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).start()
                        android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    }
                    false // never consume -- the view's normal click handling still runs untouched
                }
            }
            BUTTON_FEEDBACK_FLASH -> {
                view.setOnTouchListener { v, event ->
                    when (event.action) {
                        android.view.MotionEvent.ACTION_DOWN -> v.alpha = 0.6f
                        android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                            v.animate().alpha(1f).setDuration(150).start()
                    }
                    false
                }
            }
            BUTTON_FEEDBACK_RIPPLE_DELAYED -> {
                val handler = android.os.Handler(android.os.Looper.getMainLooper())
                view.setOnTouchListener { v, event ->
                    if (event.action == android.view.MotionEvent.ACTION_UP && v.isPressed) {
                        handler.postDelayed({
                            v.isPressed = false
                            v.performClick()
                        }, 150)
                        true // consumed -- we're taking over firing the click ourselves, delayed
                    } else {
                        false // let ACTION_DOWN/CANCEL/MOVE flow through normally so the ripple still starts
                    }
                }
            }
        }
    }
}
