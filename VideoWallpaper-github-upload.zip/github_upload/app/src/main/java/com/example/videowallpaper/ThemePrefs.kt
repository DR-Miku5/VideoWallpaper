package com.example.videowallpaper

import android.content.Context
import android.preference.PreferenceManager
import androidx.appcompat.app.AppCompatDelegate

/**
 * AppCompatDelegate.setDefaultNightMode() isn't persisted across process
 * restarts by AndroidX itself -- it has to be re-applied on every app
 * start, before any Activity inflates its theme. VideoWallpaperApp does
 * that in Application.onCreate(); SettingsActivity calls setThemeMode() when
 * the user picks a new option so it takes effect immediately too.
 */
object ThemePrefs {

    private const val KEY_THEME_MODE = "theme_mode"
    const val MODE_SYSTEM = "system"
    const val MODE_LIGHT = "light"
    const val MODE_DARK = "dark"

    fun getThemeMode(context: Context): String =
        PreferenceManager.getDefaultSharedPreferences(context)
            .getString(KEY_THEME_MODE, MODE_SYSTEM) ?: MODE_SYSTEM

    fun setThemeMode(context: Context, mode: String) {
        PreferenceManager.getDefaultSharedPreferences(context)
            .edit()
            .putString(KEY_THEME_MODE, mode)
            .apply()
        applyNightMode(mode)
    }

    fun applyStoredNightMode(context: Context) {
        applyNightMode(getThemeMode(context))
    }

    private fun applyNightMode(mode: String) {
        val nightMode = when (mode) {
            MODE_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
            MODE_DARK -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(nightMode)
    }
}
