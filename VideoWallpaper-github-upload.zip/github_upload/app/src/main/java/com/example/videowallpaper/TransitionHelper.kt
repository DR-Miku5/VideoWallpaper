package com.example.videowallpaper

import android.app.Activity

/**
 * Centralizes the app's transition animations so every screen feels
 * consistent, instead of the default hard-cut activity switch.
 */
object TransitionHelper {

    /** For drilling into a sub-screen (e.g. a row in Meer, a nav tile push). */
    fun applyForward(activity: Activity) {
        @Suppress("DEPRECATION")
        activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    /** For moving to an earlier/previous tab (e.g. Meer -> Start) -- the mirror of applyForward. */
    fun applyBackward(activity: Activity) {
        @Suppress("DEPRECATION")
        activity.overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}
