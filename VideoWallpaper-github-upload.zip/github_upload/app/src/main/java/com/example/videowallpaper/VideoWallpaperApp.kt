package com.example.videowallpaper

import android.app.Application
import android.preference.PreferenceManager

class VideoWallpaperApp : Application() {

    companion object {
        private const val KEY_LAST_SEEN_VERSION_CODE = "last_seen_version_code"
        private const val KEY_LAST_SEEN_VERSION_NAME = "last_seen_version_name"
        const val KEY_SHOW_UPDATE_RESET_NOTICE = "show_update_reset_notice"
    }

    override fun onCreate() {
        super.onCreate()
        // Must happen before any Activity inflates, so it lives in
        // Application.onCreate() rather than each Activity's onCreate().
        ThemePrefs.applyStoredNightMode(this)
        clearActiveWallpaperOnVersionChange()
    }

    /**
     * After an app update, the wallpaper process restarts and there's no
     * reliable way for the app to confirm whether Android is still
     * actually showing the previously-applied video -- it might be, or
     * the OS might have quietly stopped rendering it. Rather than the
     * app's own UI claiming "this preset is active" when that can no
     * longer be verified, every version change resets to a clean,
     * honest "nothing applied" state and the person re-applies explicitly.
     *
     * KEY_LAST_SEEN_VERSION_CODE was introduced in v3.6.7, so it never
     * existed in any earlier version -- reading it back as -1 doesn't
     * distinguish "genuinely fresh install" from "upgrading from any
     * pre-3.6.7 version," and the earlier fix wrongly treated -1 as
     * always meaning the former, silently skipping the reset on exactly
     * the upgrade path it existed to handle. The real signal for "is
     * there actually anything to clear" is whether an active preset is
     * currently recorded at all, not whether this specific tracking key
     * happens to exist yet.
     */
    private fun clearActiveWallpaperOnVersionChange() {
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        val lastSeenVersionCode = prefs.getInt(KEY_LAST_SEEN_VERSION_CODE, -1)
        val currentVersionCode = BuildConfig.VERSION_CODE

        if (lastSeenVersionCode == currentVersionCode) return // already recorded this version, nothing to do

        val isFirstEverLaunch = !prefs.contains(KEY_LAST_SEEN_VERSION_CODE)
        if (!isFirstEverLaunch) {
            // Falls back to the version code if this predates the name being
            // stored -- a real version name is always available for the
            // "to" side (BuildConfig.VERSION_NAME), just not necessarily for
            // "from" on someone's very first update after this fix shipped.
            val lastSeenVersionName = prefs.getString(KEY_LAST_SEEN_VERSION_NAME, null) ?: "code $lastSeenVersionCode"
            DiagnosticLog.appendVersionMarker(this, lastSeenVersionName, BuildConfig.VERSION_NAME)
        }

        val hadActivePreset = PresetStore.activePreset(this) != null
        if (hadActivePreset) {
            PresetStore.clearActive(this)
            DiagnosticLog.appendAppEvent(this, "Active preset reset on version change")
        }

        prefs.edit()
            .putInt(KEY_LAST_SEEN_VERSION_CODE, currentVersionCode)
            .putString(KEY_LAST_SEEN_VERSION_NAME, BuildConfig.VERSION_NAME)
            .apply()
        if (hadActivePreset) {
            prefs.edit().putBoolean(KEY_SHOW_UPDATE_RESET_NOTICE, true).apply()
        }
    }
}
