package com.example.videowallpaper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.os.Build
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer

/**
 * Plays the already-compressed local clip produced by BewerkenFragment's
 * one-time Transformer pass, looped, as a live wallpaper. Runs in its own
 * ":wallpaper" process (see AndroidManifest.xml).
 */
class VideoWallpaperService : WallpaperService() {

    companion object {
        const val TAG = "VideoWallpaperService"
        const val KEY_VIDEO_URI = "video_uri"
        // The wallpaper engine runs in its own ":wallpaper" process (for
        // memory isolation, see the manifest), so SharedPreferences change
        // listeners never fire when the main process writes a new value --
        // those notifications don't cross process boundaries. This
        // broadcast is the actual cross-process signal; PresetStore sends
        // it every time it changes the active video.
        const val ACTION_ACTIVE_VIDEO_CHANGED = "com.example.videowallpaper.ACTION_ACTIVE_VIDEO_CHANGED"
        const val EXTRA_VIDEO_URI = "extra_video_uri"
        const val ACTION_PULSE = "com.example.videowallpaper.ACTION_PULSE"
        const val ACTION_MUTE_CHANGED = "com.example.videowallpaper.ACTION_MUTE_CHANGED"
        const val EXTRA_MUTED = "extra_muted"
        const val KEY_MUTED = "muted"

        // Buffers sized for a short, local, looping clip -- ExoPlayer's
        // defaults are built for network streaming (buffer up to 50s ahead),
        // which was the direct cause of the original OOM.
        private const val MIN_BUFFER_MS = 3_000
        private const val MAX_BUFFER_MS = 8_000
        private const val BUFFER_FOR_PLAYBACK_MS = 500
        private const val BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS = 1_000

        // Heap/heartbeat/proactive-refresh checks are cheap but not free,
        // and a few seconds of slack on those doesn't matter -- 10s is fine.
        private const val SLOW_WATCHDOG_INTERVAL_MS = 10_000L
        // Stall detection runs on its own, much faster loop. Reading
        // player.currentPosition is an in-process getter (no IPC, no
        // decoder call), so this is effectively free -- the freeze itself,
        // not this polling, was always the expensive part. Worst-case
        // detection: STALL_CHECK_INTERVAL_MS * STALL_THRESHOLD_CHECKS (~4s)
        // instead of the previous ~13-20s.
        private const val STALL_CHECK_INTERVAL_MS = 2_000L
        private const val STALL_THRESHOLD_CHECKS = 2
        private const val HEAP_WARNING_RATIO = 0.90
        // 360 checks * 10s = 1 hour. A periodic "everything's fine" line,
        // not just entries when something already went wrong -- without a
        // baseline, there's no way to tell "no rebuilds today" from "the
        // wallpaper wasn't even running today."
        private const val HEARTBEAT_INTERVAL_CHECKS = 360
        private const val PULSE_OVERLAY_ALPHA = 90 // out of 255 -- noticeable without fully obscuring the photo
        private const val PULSE_DURATION_MS = 400L
        private const val VISIBILITY_LOG_THRESHOLD_SEC = 60L
        // Comfortable margin ahead of both confirmed freeze onsets
        // (~3h07m, ~11h11m) -- proactively rebuilds the decoder well
        // before either has a chance to be reached.
        private const val PROACTIVE_REFRESH_INTERVAL_MS = 2 * 60 * 60 * 1000L
    }

    override fun onCreateEngine(): Engine = VideoEngine()

    inner class VideoEngine : Engine() {

        /** Distinguishes log lines from this Engine instance from any other
         *  -- the wallpaper process can outlive a single Engine (e.g.
         *  repeated visits to Android's own preview screen), so without
         *  this it's impossible to tell "same engine rebuilding" from
         *  "a whole new engine appeared" just by reading the log. */
        private val instanceId = java.util.UUID.randomUUID().toString().take(6)

        private var player: ExoPlayer? = null
        private var currentHolder: SurfaceHolder? = null
        private var prefs: SharedPreferences? = null
        private var isVisible = false
        // Updated the instant a broadcast arrives, regardless of whether a
        // player currently exists. preparePlayerIfNeeded() and
        // swapMediaItem() both prefer this over reading `prefs` directly,
        // since a value written from the main process can be stale in this
        // process's cached SharedPreferences until something forces a
        // fresh reload -- this variable never has that problem, because
        // the broadcast Intent itself carried the fresh value.
        private var lastKnownVideoUri: String? = null

        private val watchdogHandler = Handler(Looper.getMainLooper())
        private var lastKnownPositionMs = -1L
        private var stalledChecksInARow = 0
        private var stallSuspectedAtMs = 0L
        private var playerInitializedAtMs = 0L
        private var currentVideoUri: String? = null
        private var checksSinceHeartbeat = 0
        private var lastRebuildAtMs = 0L
        private var lastLoopAtMs = 0L
        private var becameInvisibleAtMs = 0L
        private var pendingResumePositionMs: Long? = null
        private var isShowingPhoto = false
        private var photoBitmap: android.graphics.Bitmap? = null
        // Guards every rebuild path (stall/heap/proactive/error-recovery) so
        // two can never fire back-to-back -- e.g. a stall-triggered rebuild
        // starting while a proactive refresh is still tearing the old
        // player down. Reset once preparePlayerIfNeeded() finishes (success
        // or failure).
        private var isRebuilding = false
        // Whether the resolution/codec/bitrate of the *current* player has
        // already been logged -- onTracksChanged can fire more than once
        // per player, and this should only be logged the first time.
        private var formatLogged = false

        private val stallCheckRunnable = object : Runnable {
            override fun run() {
                checkForStall()
                watchdogHandler.postDelayed(this, STALL_CHECK_INTERVAL_MS)
            }
        }

        private val slowWatchdogRunnable = object : Runnable {
            override fun run() {
                checkHeapPressure()
                checkHeartbeat()
                checkProactiveRefresh()
                watchdogHandler.postDelayed(this, SLOW_WATCHDOG_INTERVAL_MS)
            }
        }

        /**
         * Fires when the active preset changes while this wallpaper is
         * already running -- e.g. Slideshow rotating to the next favorite,
         * or the user tapping "Gebruiken" on a different Library entry
         * without leaving/re-entering the wallpaper. Swaps the media item
         * on the existing player rather than waiting for a full rebuild.
         *
         * A BroadcastReceiver, not a SharedPreferences listener -- this
         * service runs in a separate process, and preference-change
         * notifications don't cross process boundaries.
         */
        private val activeVideoChangedReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val uriString = intent.getStringExtra(EXTRA_VIDEO_URI)
                if (uriString != null) lastKnownVideoUri = uriString
                Log.i(TAG, "Active preset changed while running -- hot-swapping media item")
                swapMediaItem(uriString)
            }
        }

        /**
         * Only has a visible effect while showing a photo -- there's no
         * safe way to overlay this on live ExoPlayer video without a much
         * larger surface-compositing rework (see PulsePrefs).
         */
        private val pulseReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                pulsePhoto()
            }
        }

        /**
         * Live volume change without a rebuild -- KEY_MUTED was previously
         * only ever read once, at player-build time, so toggling it
         * elsewhere had no effect on an already-running player until the
         * next full rebuild happened to occur. Setting player.volume
         * directly here applies immediately.
         */
        private val muteChangedReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val muted = intent.getBooleanExtra(EXTRA_MUTED, true)
                player?.volume = if (muted) 0f else 1f
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs = PreferenceManager.getDefaultSharedPreferences(this@VideoWallpaperService)
            // ActiveVideoFile is always fresh, unlike prefs which can be a
            // stale cached object if this process stayed alive across an
            // earlier Engine instance.
            lastKnownVideoUri = ActiveVideoFile.read(this@VideoWallpaperService)
                ?: prefs?.getString(KEY_VIDEO_URI, null)
            logEvent("Engine created")
            val filter = IntentFilter(ACTION_ACTIVE_VIDEO_CHANGED)
            val pulseFilter = IntentFilter(ACTION_PULSE)
            val muteFilter = IntentFilter(ACTION_MUTE_CHANGED)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                this@VideoWallpaperService.registerReceiver(
                    activeVideoChangedReceiver, filter, Context.RECEIVER_NOT_EXPORTED
                )
                this@VideoWallpaperService.registerReceiver(
                    pulseReceiver, pulseFilter, Context.RECEIVER_NOT_EXPORTED
                )
                this@VideoWallpaperService.registerReceiver(
                    muteChangedReceiver, muteFilter, Context.RECEIVER_NOT_EXPORTED
                )
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                this@VideoWallpaperService.registerReceiver(activeVideoChangedReceiver, filter)
                @Suppress("UnspecifiedRegisterReceiverFlag")
                this@VideoWallpaperService.registerReceiver(pulseReceiver, pulseFilter)
                @Suppress("UnspecifiedRegisterReceiverFlag")
                this@VideoWallpaperService.registerReceiver(muteChangedReceiver, muteFilter)
            }
            watchdogHandler.postDelayed(stallCheckRunnable, STALL_CHECK_INTERVAL_MS)
            watchdogHandler.postDelayed(slowWatchdogRunnable, SLOW_WATCHDOG_INTERVAL_MS)
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            currentHolder = holder
            preparePlayerIfNeeded(holder)
        }

        override fun onSurfaceChanged(
            holder: SurfaceHolder,
            format: Int,
            width: Int,
            height: Int
        ) {
            super.onSurfaceChanged(holder, format, width, height)
            // Re-attach rather than assume the old surface is still valid --
            // this was the most common crash source for live wallpapers.
            currentHolder = holder
            if (isShowingPhoto) {
                drawPhotoToSurface(holder)
            } else {
                player?.setVideoSurfaceHolder(holder)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            currentHolder = null
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            isVisible = visible

            if (visible && becameInvisibleAtMs != 0L) {
                val hiddenForSec = (System.currentTimeMillis() - becameInvisibleAtMs) / 1000
                // Only log meaningful gaps (screen off overnight, phone left
                // untouched for a while) -- a quick app-switch flicker of a
                // few seconds isn't diagnostically interesting and would
                // otherwise flood the log on every normal phone interaction.
                if (hiddenForSec >= VISIBILITY_LOG_THRESHOLD_SEC) {
                    val video = currentVideoUri?.let { videoLabel(it) } ?: "unknown"
                    logEvent("Became visible again after ~${hiddenForSec}s hidden -- video=$video")
                }
                becameInvisibleAtMs = 0L
            } else if (!visible) {
                becameInvisibleAtMs = System.currentTimeMillis()
            }

            val p = player
            if (p == null) {
                // Becoming visible again is exactly the moment to rebuild,
                // rather than staying blank until the next surface event.
                // Skipped while a rebuild is already in flight (isRebuilding)
                // -- that in-progress call already re-reads ActiveVideoFile
                // fresh and will land on the correct video once it finishes;
                // calling preparePlayerIfNeeded() again here on top of it
                // would just be a second, redundant/conflicting attempt at
                // the same rebuild, since player may currently be null
                // *because* a rebuild is mid-teardown, not because none
                // exists yet.
                if (visible && !isRebuilding) currentHolder?.let { preparePlayerIfNeeded(it) }
                return
            }
            if (visible && !isRebuilding) {
                // Safety net independent of the broadcast: re-check whether
                // the active video has changed since this player was built,
                // every time the wallpaper becomes visible again. Without
                // this, the player only ever finds out about a new active
                // video via activeVideoChangedReceiver -- if that broadcast
                // is ever missed (receiver not registered at the right
                // moment, some post-update timing edge case, etc.), the
                // player would just keep resuming the same stale video
                // forever, with no way to notice or self-correct. This is
                // what "tapped Gebruiken, app shows Actief, but the actual
                // wallpaper never changes" traces back to -- setActive()
                // writing the new state correctly is not the same thing as
                // this specific Engine having heard about it.
                //
                // Guarded by !isRebuilding -- every other function that
                // touches the player (checkForStall, checkHeapPressure,
                // checkProactiveRefresh, recoverFromPlayerError) already
                // checks this before acting; this path was the one
                // exception, meaning returning to the wallpaper at the
                // exact moment a proactive refresh or stall-rebuild was
                // already mid-flight could have this code race against it
                // instead of letting it finish.
                val latestUri = ActiveVideoFile.read(this@VideoWallpaperService)
                if (latestUri != null && latestUri != currentVideoUri) {
                    logEvent("Active video changed while not visible -- catching up on resume")
                    swapMediaItem(latestUri)
                } else {
                    p.play()
                }
                stalledChecksInARow = 0
            } else if (!visible) {
                // Pause instead of destroying anything while merely hidden
                // (swiped to another home screen page, screen off, etc).
                // Decoding stops entirely while paused, which also keeps
                // battery use near zero when the wallpaper isn't seen.
                p.pause()
            }
        }

        override fun onDestroy() {
            super.onDestroy()
            logEvent("Engine destroyed")
            try {
                this@VideoWallpaperService.unregisterReceiver(activeVideoChangedReceiver)
            } catch (e: Exception) {
                // Already unregistered or never successfully registered -- harmless.
            }
            try {
                this@VideoWallpaperService.unregisterReceiver(pulseReceiver)
            } catch (e: Exception) {
                // Already unregistered or never successfully registered -- harmless.
            }
            try {
                this@VideoWallpaperService.unregisterReceiver(muteChangedReceiver)
            } catch (e: Exception) {
                // Already unregistered or never successfully registered -- harmless.
            }
            watchdogHandler.removeCallbacks(stallCheckRunnable)
            watchdogHandler.removeCallbacks(slowWatchdogRunnable)
            releasePlayer()
        }

        /** Swaps the active media on the live wallpaper without a full rebuild where possible. */
        private fun swapMediaItem(uriFromBroadcast: String? = null) {
            val uriString = uriFromBroadcast
                ?: ActiveVideoFile.read(this@VideoWallpaperService)
                ?: lastKnownVideoUri
                ?: prefs?.getString(KEY_VIDEO_URI, null)
                ?: return

            val mediaType = ActiveVideoFile.readType(this@VideoWallpaperService)
            if (mediaType == ActiveVideoFile.TYPE_PHOTO) {
                val holder = currentHolder
                if (holder != null) {
                    showPhoto(holder, uriString)
                } else {
                    // Not currently visible/no surface -- next
                    // preparePlayerIfNeeded() will pick this exact value
                    // up via ActiveVideoFile. Also release any existing
                    // video player right now rather than leaving it
                    // dangling: without this, `player` stays non-null
                    // while the on-disk type marker already says "photo",
                    // a state mismatch that let a later stall/heap/
                    // proactive check rebuild the stale video player, walk
                    // into preparePlayerIfNeeded()'s photo branch, and
                    // return without ever clearing isRebuilding -- which
                    // permanently disabled the watchdog for the rest of
                    // this Engine's lifetime. Releasing here means that
                    // state mismatch can never exist in the first place.
                    if (player != null) releasePlayer() else isShowingPhoto = false
                }
                return
            }

            if (isShowingPhoto) {
                // Switching from a photo to a video while visible -- there's
                // no existing ExoPlayer to "swap," since none was ever built
                // while showing a photo. Tear down photo state and do a
                // fresh build instead.
                isShowingPhoto = false
                photoBitmap?.recycle()
                photoBitmap = null
                currentHolder?.let { preparePlayerIfNeeded(it) }
                return
            }

            val p = player
            if (p == null) {
                // No player yet (e.g. not visible). lastKnownVideoUri is
                // already updated above regardless, so whenever
                // preparePlayerIfNeeded() runs next it picks up this exact
                // value -- it no longer depends on a fresh prefs read.
                return
            }
            try {
                p.setMediaItem(MediaItem.fromUri(uriString))
                p.prepare()
                if (isVisible) p.play()
                lastKnownPositionMs = -1L
                stalledChecksInARow = 0
                playerInitializedAtMs = System.currentTimeMillis()
                lastLoopAtMs = 0L
                currentVideoUri = uriString
                logEvent("Media item hot-swapped (${videoLabel(uriString)})")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to hot-swap media item, rebuilding instead", e)
                logEvent("Hot-swap failed (${e.javaClass.simpleName}: ${e.message}), rebuilding")
                releasePlayer()
                currentHolder?.let { preparePlayerIfNeeded(it) }
            }
        }

        /**
         * The freeze-on-last-frame symptom doesn't throw any exception --
         * the process and Player object stay alive, but the decoder has
         * silently stopped advancing. The only reliable way to catch that
         * is to periodically check whether playback position is actually
         * moving while we believe we're visible and playing, and force a
         * rebuild if it isn't.
         */
        private fun checkForStall() {
            if (!isVisible || isRebuilding) return
            val p = player ?: return
            if (!p.isPlaying) return

            val position = p.currentPosition
            if (position == lastKnownPositionMs) {
                if (stalledChecksInARow == 0) {
                    stallSuspectedAtMs = System.currentTimeMillis()
                }
                stalledChecksInARow++
                Log.w(TAG, "Watchdog: position hasn't advanced ($stalledChecksInARow checks in a row)")
                if (stalledChecksInARow >= STALL_THRESHOLD_CHECKS) {
                    Log.w(TAG, "Watchdog: treating as stalled decoder, rebuilding player")
                    val stalledForSec = (System.currentTimeMillis() - stallSuspectedAtMs) / 1000
                    val uptimeSec = (System.currentTimeMillis() - playerInitializedAtMs) / 1000
                    val video = currentVideoUri?.let { videoLabel(it) } ?: "unknown"
                    logEvent(
                        "Rebuilt player: stalled decoder -- video=$video, " +
                            "frozen ~${stalledForSec}s before detected, " +
                            "player state was ${playbackStateLabel(p)}, " +
                            "was playing ~${uptimeSec}s, heap at ${heapUsagePercent()}%, " +
                            "battery ${batteryStatus()}, thermal ${thermalStatus()}, " +
                            "last rebuild ${timeSinceLastRebuild()}, last loop ${timeSinceLastLoop()}"
                    )
                    DiagnosticLog.incrementStallRebuilds(this@VideoWallpaperService)
                    stalledChecksInARow = 0
                    stallSuspectedAtMs = 0L
                    lastRebuildAtMs = System.currentTimeMillis()
                    isRebuilding = true
                    releasePlayer()
                    currentHolder?.let { preparePlayerIfNeeded(it) }
                }
            } else {
                stalledChecksInARow = 0
                stallSuspectedAtMs = 0L
            }
            lastKnownPositionMs = position
        }

        /**
         * Preventive check: rebuild the player before a crash, not just
         * after one. Tearing down and recreating the player releases all
         * buffered video data it was holding -- a cheap, near-instant
         * "reset button" run automatically when needed.
         */
        private fun checkHeapPressure() {
            if (isRebuilding) return
            val p = player ?: return
            val ratioPercent = heapUsagePercent()
            if (ratioPercent >= (HEAP_WARNING_RATIO * 100).toInt()) {
                Log.w(TAG, "Watchdog: heap at $ratioPercent% of max, rebuilding preventively")
                val uptimeSec = (System.currentTimeMillis() - playerInitializedAtMs) / 1000
                val video = currentVideoUri?.let { videoLabel(it) } ?: "unknown"
                logEvent(
                    "Rebuilt player: heap at $ratioPercent% -- video=$video, " +
                        "player state was ${playbackStateLabel(p)}, was playing ~${uptimeSec}s, " +
                        "battery ${batteryStatus()}, thermal ${thermalStatus()}, " +
                        "last rebuild ${timeSinceLastRebuild()}"
                )
                DiagnosticLog.incrementHeapRebuilds(this@VideoWallpaperService)
                lastRebuildAtMs = System.currentTimeMillis()
                isRebuilding = true
                releasePlayer()
                currentHolder?.let { preparePlayerIfNeeded(it) }
            }
        }

        /**
         * Logs an "everything's fine" line roughly once an hour while the
         * wallpaper is active, regardless of whether anything went wrong.
         * Without this, the log only ever shows entries for problems --
         * there's no baseline to tell "quiet day, nothing happened" apart
         * from "the wallpaper wasn't running," and no way to see normal
         * heap/battery levels to compare a rebuild's numbers against.
         */
        private fun checkHeartbeat() {
            if (player == null || !isVisible) return
            checksSinceHeartbeat++
            if (checksSinceHeartbeat < HEARTBEAT_INTERVAL_CHECKS) return
            checksSinceHeartbeat = 0

            val uptimeSec = (System.currentTimeMillis() - playerInitializedAtMs) / 1000
            val video = currentVideoUri?.let { videoLabel(it) } ?: "unknown"
            logEvent("Heartbeat: video=$video, playing ~${uptimeSec}s, heap at ${heapUsagePercent()}%, battery ${batteryStatus()}, thermal ${thermalStatus()}")
        }

        /**
         * A defensive layer alongside v4.9.2's async-decoder fix, not a
         * substitute for it: proactively rebuilds the decoder well before
         * the confirmed ~3h07m/~11h11m freeze onset, so whatever internal
         * decoder state causes the known Pixel 10 stall never gets the
         * chance to accumulate that far. Deliberately a *full* rebuild
         * (fresh ExoPlayer instance), not a hot-swap via setMediaItem() on
         * the same player -- a hot-swap can end up reusing the same
         * underlying MediaCodec session if the format hasn't changed,
         * which wouldn't actually reset whatever state this is trying to
         * avoid. The current playback position is captured and restored
         * after the rebuild so this is invisible to the person watching --
         * without that, every refresh would visibly jump the video back
         * to 0:00 mid-playback. Logged and counted separately from
         * stall/heap rebuilds (a healthy, scheduled rebuild isn't a
         * problem event, and mixing it into those counts would skew the
         * battery-correlation analysis meant to track real failures).
         */
        private fun checkProactiveRefresh() {
            if (isShowingPhoto || isRebuilding) return // no decoder session to refresh for a static photo
            val p = player ?: return
            val uptimeMs = System.currentTimeMillis() - playerInitializedAtMs
            if (uptimeMs < PROACTIVE_REFRESH_INTERVAL_MS) return

            val resumePositionMs = p.currentPosition
            val video = currentVideoUri?.let { videoLabel(it) } ?: "unknown"
            logEvent(
                "Proactive refresh: rebuilding decoder after ~${uptimeMs / 1000}s uptime " +
                    "(ahead of the known long-uptime stall), resuming at ${resumePositionMs / 1000}s -- video=$video"
            )
            DiagnosticLog.incrementProactiveRefreshes(this@VideoWallpaperService)
            lastRebuildAtMs = System.currentTimeMillis()
            pendingResumePositionMs = resumePositionMs
            isRebuilding = true
            releasePlayer()
            currentHolder?.let { preparePlayerIfNeeded(it) }
        }

        private fun batteryStatus(): String {
            return try {
                val batteryManager = getSystemService(BATTERY_SERVICE) as android.os.BatteryManager
                val level = batteryManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
                val isCharging = batteryManager.isCharging
                "$level% (${if (isCharging) "charging" else "not charging"})"
            } catch (e: Exception) {
                "unknown"
            }
        }

        /**
         * Android's own thermal throttling status (API 29+; older devices
         * report "n/a"). A hot, throttled device is a real candidate for
         * decoder stalls that show no memory pressure at all -- the one
         * confirmed freeze so far had heap at just 2%, which ruled out
         * memory as the cause but left thermal state as an untested one.
         */
        private fun thermalStatus(): String {
            return try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val powerManager = getSystemService(POWER_SERVICE) as android.os.PowerManager
                    when (powerManager.currentThermalStatus) {
                        android.os.PowerManager.THERMAL_STATUS_NONE -> "normal"
                        android.os.PowerManager.THERMAL_STATUS_LIGHT -> "light throttling"
                        android.os.PowerManager.THERMAL_STATUS_MODERATE -> "moderate throttling"
                        android.os.PowerManager.THERMAL_STATUS_SEVERE -> "severe throttling"
                        android.os.PowerManager.THERMAL_STATUS_CRITICAL -> "critical"
                        android.os.PowerManager.THERMAL_STATUS_EMERGENCY -> "emergency"
                        android.os.PowerManager.THERMAL_STATUS_SHUTDOWN -> "shutdown imminent"
                        else -> "unknown"
                    }
                } else {
                    "n/a (Android < 10)"
                }
            } catch (e: Exception) {
                "unknown"
            }
        }

        /**
         * ExoPlayer's own playback state at the moment a stall/heap
         * rebuild is triggered -- distinguishes "it was already playing
         * smoothly and then froze" (STATE_READY) from "it was stuck
         * rebuffering" (STATE_BUFFERING), which point at different causes
         * and were previously indistinguishable from the log alone.
         */
        private fun playbackStateLabel(p: ExoPlayer): String = when (p.playbackState) {
            Player.STATE_IDLE -> "idle"
            Player.STATE_BUFFERING -> "buffering"
            Player.STATE_READY -> "ready"
            Player.STATE_ENDED -> "ended"
            else -> "unknown"
        }

        /** How long it's been since the previous rebuild of any kind -- reveals clustering/frequency that a single timestamp can't. */
        private fun timeSinceLastRebuild(): String {
            if (lastRebuildAtMs == 0L) return "n/a (first this session)"
            val sec = (System.currentTimeMillis() - lastRebuildAtMs) / 1000
            return "${sec}s ago"
        }

        private fun heapUsagePercent(): Int {
            val runtime = Runtime.getRuntime()
            val used = runtime.totalMemory() - runtime.freeMemory()
            return ((used.toDouble() / runtime.maxMemory().toDouble()) * 100).toInt()
        }

        private fun preparePlayerIfNeeded(holder: SurfaceHolder) {
            val mediaType = ActiveVideoFile.readType(this@VideoWallpaperService)
            if (mediaType == ActiveVideoFile.TYPE_PHOTO) {
                val uriString = ActiveVideoFile.read(this@VideoWallpaperService) ?: lastKnownVideoUri
                if (uriString.isNullOrEmpty()) {
                    Log.w(TAG, "No photo selected yet; nothing to show.")
                    isRebuilding = false
                    return
                }
                // Avoid redundant re-decoding if this exact photo is
                // already showing -- e.g. onVisibilityChanged() calling
                // this again on every resume shouldn't reload the same
                // bitmap from disk each time.
                if (isShowingPhoto && currentVideoUri == uriString && photoBitmap != null) {
                    drawPhotoToSurface(holder)
                    isRebuilding = false
                    return
                }
                showPhoto(holder, uriString)
                isRebuilding = false
                return
            }

            // Switching (back) to video -- tear down any photo state first,
            // since a photo and an ExoPlayer instance never coexist.
            if (isShowingPhoto) {
                isShowingPhoto = false
                photoBitmap?.recycle()
                photoBitmap = null
            }

            if (player != null) {
                player?.setVideoSurfaceHolder(holder)
                isRebuilding = false
                return
            }

            val uriString = ActiveVideoFile.read(this@VideoWallpaperService)
                ?: lastKnownVideoUri
                ?: prefs?.getString(KEY_VIDEO_URI, null)
            if (uriString.isNullOrEmpty()) {
                Log.w(TAG, "No video selected yet; nothing to play.")
                isRebuilding = false
                return
            }

            try {
                val loadControl = DefaultLoadControl.Builder()
                    .setBufferDurationsMs(
                        MIN_BUFFER_MS,
                        MAX_BUFFER_MS,
                        BUFFER_FOR_PLAYBACK_MS,
                        BUFFER_FOR_PLAYBACK_AFTER_REBUFFER_MS
                    )
                    .build()

                // Forces MediaCodec to run in asynchronous callback mode
                // rather than ExoPlayer's default synchronous polling --
                // changes which thread drives decoder I/O. Kept as a
                // defensive measure, but NOT treated as a confirmed fix:
                // the Media3 tracker report this was originally linked to
                // (Pixel 10 playback freezing within seconds on DRM'd live
                // DASH streams) has a different symptom profile than our
                // confirmed issue (local file, freezes after hours), so the
                // link is plausible at best, not verified. The watchdog
                // stays the actual safety net regardless.
                val renderersFactory = DefaultRenderersFactory(this@VideoWallpaperService)
                    .forceEnableMediaCodecAsynchronousQueueing()

                val exoPlayer = ExoPlayer.Builder(this@VideoWallpaperService, renderersFactory)
                    .setLoadControl(loadControl)
                    .build()

                exoPlayer.setVideoSurfaceHolder(holder)
                exoPlayer.setMediaItem(MediaItem.fromUri(uriString))
                exoPlayer.repeatMode = Player.REPEAT_MODE_ONE
                exoPlayer.volume = if (prefs?.getBoolean(KEY_MUTED, true) == true) 0f else 1f
                exoPlayer.addListener(playerErrorListener)
                formatLogged = false
                exoPlayer.prepare()
                pendingResumePositionMs?.let { exoPlayer.seekTo(it) }
                pendingResumePositionMs = null
                if (isVisible) exoPlayer.play()

                player = exoPlayer
                lastKnownPositionMs = -1L
                stalledChecksInARow = 0
                playerInitializedAtMs = System.currentTimeMillis()
                lastLoopAtMs = 0L
                currentVideoUri = uriString
                logEvent("Player initialized (${videoLabel(uriString)})")
            } catch (e: Exception) {
                // Never let construction-time failures propagate out of a
                // WallpaperService -- that's how you get a system-wide crash
                // loop instead of just "no wallpaper today."
                Log.e(TAG, "Failed to initialize player", e)
                logEvent("Player init failed (${videoLabel(uriString)}): ${e.message}")
                player = null
            } finally {
                isRebuilding = false
            }
        }

        /**
         * Renders a static photo directly to the surface's Canvas instead
         * of going through ExoPlayer at all -- there's nothing to decode
         * frame-by-frame for a still image. Any existing video player is
         * released first, since a photo and an ExoPlayer instance never
         * coexist.
         */
        private fun showPhoto(holder: SurfaceHolder, uriString: String) {
            releasePlayer()
            try {
                val path = android.net.Uri.parse(uriString).path
                if (path.isNullOrEmpty()) {
                    logEvent("Failed to show photo: no file path in URI")
                    return
                }
                val bitmap = android.graphics.BitmapFactory.decodeFile(path)
                if (bitmap == null) {
                    logEvent("Failed to show photo (${videoLabel(uriString)}): could not decode")
                    return
                }
                photoBitmap?.recycle()
                photoBitmap = bitmap
                isShowingPhoto = true
                currentVideoUri = uriString
                playerInitializedAtMs = System.currentTimeMillis()
                drawPhotoToSurface(holder)
                logEvent("Showing photo (${videoLabel(uriString)})")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to show photo", e)
                logEvent("Failed to show photo (${videoLabel(uriString)}): ${e.message}")
            }
        }

        /** Center-crop fill, matching how the video pipeline fills the screen -- scales up to cover, cropping any overflow. */
        private fun drawPhotoToSurface(holder: SurfaceHolder, overlayAlpha: Int = 0) {
            val bitmap = photoBitmap ?: return
            var canvas: android.graphics.Canvas? = null
            try {
                canvas = holder.lockCanvas() ?: return
                val canvasWidth = canvas.width.toFloat()
                val canvasHeight = canvas.height.toFloat()
                val bitmapWidth = bitmap.width.toFloat()
                val bitmapHeight = bitmap.height.toFloat()
                if (canvasWidth <= 0f || canvasHeight <= 0f || bitmapWidth <= 0f || bitmapHeight <= 0f) return

                val scale = maxOf(canvasWidth / bitmapWidth, canvasHeight / bitmapHeight)
                val scaledWidth = bitmapWidth * scale
                val scaledHeight = bitmapHeight * scale
                val left = (canvasWidth - scaledWidth) / 2f
                val top = (canvasHeight - scaledHeight) / 2f

                canvas.drawColor(android.graphics.Color.BLACK)
                val destRect = android.graphics.RectF(left, top, left + scaledWidth, top + scaledHeight)
                canvas.drawBitmap(bitmap, null, destRect, null)

                if (overlayAlpha > 0) {
                    val overlayColor = StylePrefs.resolveAccentColor(this@VideoWallpaperService)
                    val paint = android.graphics.Paint()
                    paint.color = overlayColor
                    paint.alpha = overlayAlpha
                    canvas.drawRect(0f, 0f, canvasWidth, canvasHeight, paint)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to draw photo to surface", e)
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                        // Surface may have been destroyed mid-draw -- non-fatal.
                    }
                }
            }
        }

        /**
         * A brief accent-colored flash over the photo, triggered by an
         * incoming notification (see NotificationPulseListenerService).
         * Only meaningful while a photo is showing and visible -- silently
         * does nothing for video (see the class doc on PulsePrefs) or
         * while the wallpaper isn't currently on screen.
         */
        private fun pulsePhoto() {
            if (!isShowingPhoto || !isVisible) return
            val holder = currentHolder ?: return
            drawPhotoToSurface(holder, overlayAlpha = PULSE_OVERLAY_ALPHA)
            watchdogHandler.postDelayed({
                currentHolder?.let { if (isShowingPhoto) drawPhotoToSurface(it) }
            }, PULSE_DURATION_MS)
        }

        /**
         * Measures native heap immediately before and after releasing the
         * player, on every single release regardless of which of the many
         * call sites triggered it (stall/heap/error recovery, proactive
         * refresh, video<->photo swaps) -- added to investigate whether
         * release() is fully reclaiming native memory each time, or
         * whether something is quietly not being freed. JVM heap
         * (checkHeapPressure()) has been checked all along; native heap
         * never has been, and a leak there would be completely invisible
         * to everything this app already logs.
         *
         * One real caveat, stated plainly rather than glossed over:
         * player.release() can hand cleanup off to ExoPlayer's own
         * internal threads, so it's not guaranteed every byte is freed by
         * the instant this function returns -- a small lag here isn't a
         * blind spot though, since the next heartbeat or rebuild's own
         * "before" reading would still catch memory that was freed a
         * moment late.
         *
         * Guarded to only measure and log when there's an actual player
         * to release -- several call sites can invoke this when player is
         * already null, and logging a meaningless "before equals after,
         * nothing happened" line every time would just add noise.
         */
        private fun releasePlayer() {
            val hadPlayer = player != null
            val nativeBeforeMb = if (hadPlayer) Debug.getNativeHeapAllocatedSize() / (1024 * 1024) else 0L

            try {
                player?.removeListener(playerErrorListener)
                player?.release()
            } catch (e: Exception) {
                Log.e(TAG, "Error releasing player", e)
            } finally {
                player = null
            }
            photoBitmap?.recycle()
            photoBitmap = null
            isShowingPhoto = false

            if (hadPlayer) {
                val nativeAfterMb = Debug.getNativeHeapAllocatedSize() / (1024 * 1024)
                logEvent("Player released: native heap ${nativeBeforeMb}MB -> ${nativeAfterMb}MB")
            }
        }

        /**
         * ExoPlayer reports its own playback errors (decoder failures,
         * frame-processing issues, etc.) through this callback immediately
         * -- no need to wait for the polling watchdog to notice the
         * position stopped advancing. This is the systemic fix: previously
         * the wallpaper had zero visibility into *why* something failed
         * and always did the heaviest possible recovery (full teardown +
         * new ExoPlayer instance) regardless of what actually went wrong.
         */
        private val playerErrorListener = object : Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                val video = currentVideoUri?.let { videoLabel(it) } ?: "unknown"
                Log.e(TAG, "Player error (${error.errorCodeName}) on $video", error)
                logEvent(
                    "Player error: ${error.errorCodeName} -- ${error.message}, video=$video, " +
                        "battery ${batteryStatus()}, thermal ${thermalStatus()}, last rebuild ${timeSinceLastRebuild()}"
                )
                recoverFromPlayerError()
            }

            /**
             * Fires once real track info is available (and again on any
             * later track change, which onTracksChanged can do more than
             * once per player -- formatLogged guards against re-logging
             * the same info every time). Captures resolution/codec/bitrate
             * at player-init time so a future stall/rebuild log line can
             * be correlated with what quality was actually playing --
             * previously this was known only via BewerkenFragment's export
             * settings, not from what ExoPlayer itself was decoding.
             */
            override fun onTracksChanged(tracks: Tracks) {
                if (formatLogged) return
                val videoFormat = tracks.groups
                    .firstOrNull { it.type == C.TRACK_TYPE_VIDEO }
                    ?.let { group -> (0 until group.length).firstOrNull { group.isTrackSelected(it) } }
                    ?.let { index ->
                        tracks.groups.first { it.type == C.TRACK_TYPE_VIDEO }.getTrackFormat(index)
                    }
                if (videoFormat != null) {
                    formatLogged = true
                    val video = currentVideoUri?.let { videoLabel(it) } ?: "unknown"
                    val bitrateLabel = if (videoFormat.bitrate > 0) {
                        "${videoFormat.bitrate / 1_000_000}Mbps"
                    } else {
                        "unknown"
                    }
                    logEvent(
                        "Player format: video=$video, res=${videoFormat.width}x${videoFormat.height}, " +
                            "codec=${videoFormat.sampleMimeType}, bitrate=$bitrateLabel, fps=${videoFormat.frameRate}"
                    )
                }
            }

            /**
             * Fires every time REPEAT_MODE_ONE loops the video back to the
             * start. Deliberately NOT logged as its own line -- a short
             * video can loop hundreds of times an hour, which would
             * dominate the 200-line log within minutes and defeat its own
             * purpose. Instead this just tracks timing, surfaced only
             * where it's actually diagnostically useful: in stall-rebuild
             * log lines, to test whether stalls cluster around loop
             * boundaries (the brief re-seek a loop involves is a
             * plausible stall trigger that hadn't been checked before).
             */
            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) {
                    lastLoopAtMs = System.currentTimeMillis()
                    DiagnosticLog.incrementLoopCount(this@VideoWallpaperService)
                }
            }
        }

        private fun timeSinceLastLoop(): String {
            if (lastLoopAtMs == 0L) return "n/a (no loop yet this session)"
            val sec = (System.currentTimeMillis() - lastLoopAtMs) / 1000
            return "${sec}s ago"
        }

        /**
         * Try the lightweight recovery ExoPlayer itself supports first --
         * re-preparing the existing instance -- before falling back to a
         * full rebuild. Re-preparing keeps the same ExoPlayer object and
         * surface binding, so it's meaningfully cheaper (less codec
         * re-allocation, less battery cost per recovery) than tearing
         * everything down, and it's the officially supported way to
         * recover from a reported PlaybackException.
         */
        private fun recoverFromPlayerError() {
            if (isRebuilding) return
            val p = player
            if (p == null) {
                isRebuilding = true
                currentHolder?.let { preparePlayerIfNeeded(it) }
                return
            }
            try {
                p.prepare()
                if (isVisible) p.play()
                lastKnownPositionMs = -1L
                stalledChecksInARow = 0
                DiagnosticLog.incrementErrorRecoveries(this@VideoWallpaperService)
                lastRebuildAtMs = System.currentTimeMillis()
                logEvent("Recovered via re-prepare (no full rebuild needed)")
            } catch (e: Exception) {
                Log.e(TAG, "Lightweight recovery failed, doing a full rebuild instead", e)
                logEvent("Lightweight recovery failed (${e.message}), doing full rebuild")
                lastRebuildAtMs = System.currentTimeMillis()
                isRebuilding = true
                releasePlayer()
                currentHolder?.let { preparePlayerIfNeeded(it) }
            }
        }

        /** Short, stable label identifying which video a log line is about, without dumping the full path/URI. */
        private fun videoLabel(uriString: String): String =
            uriString.substringAfterLast('/').substringBefore('.').take(8).ifBlank { "unknown" }

        /**
         * Appends one line to the rolling event log (see DiagnosticLog),
         * so Diagnostiek can show what the watchdog has been doing without
         * needing the (separate-process) service running at the same time.
         */
        private fun logEvent(message: String) {
            DiagnosticLog.append(this@VideoWallpaperService, instanceId, message)
        }
    }
}
